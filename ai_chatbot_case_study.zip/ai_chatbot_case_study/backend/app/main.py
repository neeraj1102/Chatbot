"""
FastAPI Main Application
Entry point for the AI Chatbot Support API
"""
 
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import time
 
from app.config.settings import settings
from app.database.session import init_db
from app.utils.logger import get_logger
from app.api.routes import chat, orders, tickets, rag
 
logger = get_logger()
 
 
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events."""
    # Startup
    logger.info("Starting AI Chatbot Support API...")
    logger.info(f"Environment: {settings.ENVIRONMENT}")
    logger.info(f"Debug mode: {settings.DEBUG}")
   
    # Initialize database
    try:
        init_db()
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
   
    yield
   
    # Shutdown
    logger.info("Shutting down AI Chatbot Support API...")
 
 
# Create FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="AI-powered customer support chatbot with RAG and intelligent guardrails",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)
 
 
# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=settings.CORS_ALLOW_CREDENTIALS,
    allow_methods=["*"],
    allow_headers=["*"],
)
 
 
# Request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log all requests."""
    start_time = time.time()
   
    # Process request
    response = await call_next(request)
   
    # Calculate duration
    duration = time.time() - start_time
   
    # Log request
    logger.info(
        f"{request.method} {request.url.path} - "
        f"Status: {response.status_code} - "
        f"Duration: {duration:.3f}s"
    )
   
    return response
 
 
# Exception handlers
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler."""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
   
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": {
                "code": "INTERNAL_ERROR",
                "message": "An unexpected error occurred. Please try again later.",
                "details": str(exc) if settings.DEBUG else None
            }
        }
    )
 
 
# Include routers
app.include_router(chat.router, prefix=settings.API_PREFIX)
app.include_router(orders.router, prefix=settings.API_PREFIX)
app.include_router(tickets.router, prefix=settings.API_PREFIX)
app.include_router(rag.router, prefix=settings.API_PREFIX)
 
 
# Root endpoint
@app.get("/")
def root():
    """Root endpoint."""
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running",
        "environment": settings.ENVIRONMENT,
        "docs": "/docs",
        "api_prefix": settings.API_PREFIX
    }
 
 
# Health check endpoint
@app.get("/health")
def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": time.time(),
        "services": {
            "api": "up",
            "database": "up",  # TODO: Add actual DB health check
            "llm": "up"  # TODO: Add actual LLM health check
        }
    }
 
 
# API info endpoint
@app.get(f"{settings.API_PREFIX}/info")
def api_info():
    """API information endpoint."""
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "endpoints": {
            "chat": f"{settings.API_PREFIX}/chat",
            "orders": f"{settings.API_PREFIX}/orders",
            "tickets": f"{settings.API_PREFIX}/tickets",
            "rag": f"{settings.API_PREFIX}/rag"
        },
        "features": {
            "rag": "enabled",
            "guardrails": "enabled",
            "escalation": "enabled",
            "order_integration": "enabled"
        },
        "limits": {
            "max_message_length": 1000,
            "max_conversation_history": settings.MAX_CONVERSATION_HISTORY,
            "max_clarification_attempts": settings.MAX_CLARIFICATION_ATTEMPTS
        }
    }
 
 
if __name__ == "__main__":
    import uvicorn
   
    uvicorn.run(
        "app.main:app",
        host=settings.API_HOST,
        port=settings.API_PORT,
        reload=settings.DEBUG,
        log_level=settings.LOG_LEVEL.lower()
    )
 
 