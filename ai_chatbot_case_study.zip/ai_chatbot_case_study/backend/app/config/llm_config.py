"""
LLM Configuration
Configures OpenAI, OpenRouter, and Gemini LLMs with LangChain
"""
 
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from app.config.settings import settings
from typing import Optional
import os
 
 
class LLMConfig:
    """LLM configuration and initialization with OpenRouter support."""
   
    def __init__(self):
        self.primary_llm: Optional[ChatOpenAI] = None
        self.fallback_llm: Optional[ChatGoogleGenerativeAI] = None
        self.embeddings: Optional[OpenAIEmbeddings] = None
        self._initialize()
   
    def _initialize(self):
        """Initialize LLM instances."""
       
        # Check if using OpenRouter
        if settings.USE_OPENROUTER and settings.OPENROUTER_API_KEY:
            # Primary LLM - OpenRouter (compatible with OpenAI API)
            self.primary_llm = ChatOpenAI(
                model=settings.OPENROUTER_MODEL,
                temperature=settings.OPENAI_TEMPERATURE,
                max_tokens=settings.OPENAI_MAX_TOKENS,
                openai_api_key=settings.OPENROUTER_API_KEY,
                openai_api_base=settings.OPENROUTER_BASE_URL,
                default_headers={
                    "HTTP-Referer": "http://localhost:8000",  # Optional
                    "X-Title": "AI Chatbot Support"  # Optional
                }
            )
           
            # Embeddings via OpenRouter
            self.embeddings = OpenAIEmbeddings(
                model=settings.OPENROUTER_EMBEDDING_MODEL,
                openai_api_key=settings.OPENROUTER_API_KEY,
                openai_api_base=settings.OPENROUTER_BASE_URL
            )
       
        # Otherwise use standard OpenAI
        elif settings.OPENAI_API_KEY:
            # Primary LLM - OpenAI GPT-4
            self.primary_llm = ChatOpenAI(
                model=settings.OPENAI_MODEL,
                temperature=settings.OPENAI_TEMPERATURE,
                max_tokens=settings.OPENAI_MAX_TOKENS,
                openai_api_key=settings.OPENAI_API_KEY
            )
           
            # Embeddings
            self.embeddings = OpenAIEmbeddings(
                model=settings.OPENAI_EMBEDDING_MODEL,
                openai_api_key=settings.OPENAI_API_KEY
            )
       
        # Fallback LLM - Google Gemini
        if settings.GOOGLE_API_KEY:
            self.fallback_llm = ChatGoogleGenerativeAI(
                model=settings.GEMINI_MODEL,
                temperature=settings.OPENAI_TEMPERATURE,
                google_api_key=settings.GOOGLE_API_KEY
            )
   
    def get_llm(self, use_fallback: bool = False):
        """Get LLM instance with fallback support."""
        if use_fallback and self.fallback_llm:
            return self.fallback_llm
       
        if self.primary_llm:
            return self.primary_llm
       
        if self.fallback_llm:
            return self.fallback_llm
       
        raise ValueError(
            "No LLM configured. Please set OPENAI_API_KEY or OPENROUTER_API_KEY or GOOGLE_API_KEY"
        )
   
    def get_embeddings(self):
        """Get embeddings model."""
        if not self.embeddings:
            raise ValueError(
                "Embeddings not configured. Please set OPENAI_API_KEY or OPENROUTER_API_KEY"
            )
        return self.embeddings
   
    def create_chain(self, prompt_template: str, use_fallback: bool = False) -> LLMChain:
        """Create LLM chain with prompt template."""
        llm = self.get_llm(use_fallback)
        prompt = PromptTemplate.from_template(prompt_template)
        return LLMChain(llm=llm, prompt=prompt)
 
 
# Global LLM config instance
llm_config = LLMConfig()
 
 
def get_llm_config() -> LLMConfig:
    """Get LLM configuration instance."""
    return llm_config
 
 