"""
Application Settings
Manages all configuration using Pydantic Settings
"""

from pydantic_settings import BaseSettings
from typing import List
from functools import lru_cache


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # Application
    APP_NAME: str = "AI Chatbot Support"
    APP_VERSION: str = "1.0.0"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    LOG_LEVEL: str = "INFO"

    # API Settings
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
    API_PREFIX: str = "/api/v1"

    # OpenAI Configuration
    OPENAI_API_KEY: str = ""
    OPENAI_MODEL: str = "gpt-4-turbo-preview"
    OPENAI_EMBEDDING_MODEL: str = "text-embedding-ada-002"
    OPENAI_TEMPERATURE: float = 0.7
    OPENAI_MAX_TOKENS: int = 1000

    # OpenRouter Configuration (Alternative to OpenAI)
    USE_OPENROUTER: bool = False
    OPENROUTER_API_KEY: str = ""
    OPENROUTER_BASE_URL: str = "https://openrouter.ai/api/v1"
    OPENROUTER_MODEL: str = "openai/gpt-4o-mini"
    OPENROUTER_EMBEDDING_MODEL: str = "openai/text-embedding-3-small"

    # Google Gemini Configuration (Fallback)
    GOOGLE_API_KEY: str = ""
    GEMINI_MODEL: str = "gemini-pro"

    # LangChain Settings
    LANGCHAIN_TRACING_V2: bool = False
    LANGCHAIN_API_KEY: str = ""

    # Database Configuration
    DATABASE_URL: str = "postgresql://postgres:postgres@localhost:5435/chatbot_db"
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 20

    # Redis Configuration
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    REDIS_PASSWORD: str = ""
    REDIS_TTL: int = 3600

    # Vector Store Configuration
    VECTOR_STORE_TYPE: str = "chromadb"
    CHROMA_PERSIST_DIRECTORY: str = "./knowledge_base/embeddings"
    CHROMA_COLLECTION_NAME: str = "support_knowledge"
    EMBEDDING_DIMENSION: int = 1536

    # RAG Configuration
    RAG_TOP_K: int = 5
    RAG_SIMILARITY_THRESHOLD: float = 0.7
    RAG_CHUNK_SIZE: int = 500
    RAG_CHUNK_OVERLAP: int = 50

    # Guardrails Configuration
    CONFIDENCE_THRESHOLD: float = 0.7
    HIGH_CONFIDENCE_THRESHOLD: float = 0.9
    MAX_CLARIFICATION_ATTEMPTS: int = 2
    ENABLE_CONTENT_SAFETY: bool = True

    # Conversation Settings
    MAX_CONVERSATION_HISTORY: int = 10
    SESSION_TIMEOUT: int = 1800

    # Ticket System
    TICKET_API_URL: str = "http://localhost:9000/api/tickets"
    TICKET_API_KEY: str = ""

    # Order System
    ORDER_API_URL: str = "http://localhost:9001/api/orders"
    ORDER_API_KEY: str = ""

    # CORS Settings
    CORS_ORIGINS: List[str] = ["http://localhost:8501", "http://localhost:3000"]
    CORS_ALLOW_CREDENTIALS: bool = True

    # Security
    SECRET_KEY: str = "your_secret_key_here_change_in_production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30

    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()


# Global settings instance
settings = get_settings()
