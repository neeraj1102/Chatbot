"""
Ticket Models
Pydantic models for support ticket data
"""
 
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any, Literal
from datetime import datetime
 
 
class TicketCategory(str):
    """Ticket category constants."""
    DELIVERY_ISSUE = "delivery_issue"
    PAYMENT_ISSUE = "payment_issue"
    QUALITY_ISSUE = "quality_issue"
    REFUND_REQUEST = "refund_request"
    OTHER = "other"
 
 
class TicketPriority(str):
    """Ticket priority constants."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
 
 
class TicketStatus(str):
    """Ticket status constants."""
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    CLOSED = "closed"
 
 
class ConversationMessage(BaseModel):
    """Conversation message for ticket."""
    role: str
    message: str
    timestamp: datetime
 
 
class CreateTicketRequest(BaseModel):
    """Request to create a support ticket."""
    user_id: str = Field(..., description="User identifier")
    order_id: Optional[str] = Field(None, description="Related order ID")
    category: str = Field(..., description="Ticket category")
    priority: Literal["low", "medium", "high"] = Field("medium", description="Ticket priority")
    description: str = Field(..., min_length=10, max_length=2000, description="Issue description")
    conversation_history: List[ConversationMessage] = Field(default_factory=list)
   
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "USER001",
                "order_id": "ORD123456",
                "category": "delivery_issue",
                "priority": "high",
                "description": "My order is delayed by 2 hours and the delivery partner is not responding.",
                "conversation_history": [
                    {
                        "role": "user",
                        "message": "Where is my order?",
                        "timestamp": "2026-01-21T17:00:00"
                    },
                    {
                        "role": "assistant",
                        "message": "Your order is out for delivery...",
                        "timestamp": "2026-01-21T17:00:05"
                    }
                ]
            }
        }
 
 
class Ticket(BaseModel):
    """Support ticket model."""
    ticket_id: str
    user_id: str
    order_id: Optional[str] = None
    category: str
    priority: str
    description: str
    conversation_history: List[ConversationMessage] = []
    status: str
    assigned_to: Optional[str] = None
    created_at: datetime
    resolved_at: Optional[datetime] = None
   
    class Config:
        json_schema_extra = {
            "example": {
                "ticket_id": "TKT123456",
                "user_id": "USER001",
                "order_id": "ORD123456",
                "category": "delivery_issue",
                "priority": "high",
                "description": "Order delayed by 2 hours",
                "status": "open",
                "created_at": "2026-01-21T17:30:00"
            }
        }
 
 
class CreateTicketResponse(BaseModel):
    """Response after creating ticket."""
    ticket_id: str
    status: str
    created_at: datetime
    estimated_response_time: str = "Within 2 hours"
 
 
class TicketListResponse(BaseModel):
    """Response for list of tickets."""
    tickets: List[Ticket]
    total: int
 
 