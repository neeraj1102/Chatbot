"""
Order Models
Pydantic models for order-related data
"""
 
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
from enum import Enum
 
 
class OrderStatus(str, Enum):
    """Order status enumeration."""
    PENDING = "pending"
    CONFIRMED = "confirmed"
    PREPARING = "preparing"
    OUT_FOR_DELIVERY = "out_for_delivery"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"
 
 
class OrderItem(BaseModel):
    """Order item model."""
    item_id: str
    name: str
    quantity: int = Field(..., gt=0)
    price: float = Field(..., gt=0)
   
    class Config:
        json_schema_extra = {
            "example": {
                "item_id": "ITEM123",
                "name": "Margherita Pizza",
                "quantity": 2,
                "price": 12.99
            }
        }
 
 
class Order(BaseModel):
    """Order model."""
    order_id: str
    user_id: str
    status: OrderStatus
    items: List[OrderItem]
    total_amount: float = Field(..., gt=0)
    delivery_address: str
    estimated_delivery: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
   
    class Config:
        json_schema_extra = {
            "example": {
                "order_id": "ORD123456",
                "user_id": "USER001",
                "status": "out_for_delivery",
                "items": [
                    {
                        "item_id": "ITEM123",
                        "name": "Margherita Pizza",
                        "quantity": 2,
                        "price": 12.99
                    }
                ],
                "total_amount": 25.98,
                "delivery_address": "123 Main St, Apt 4B",
                "estimated_delivery": "2026-01-21T18:30:00",
                "created_at": "2026-01-21T17:00:00",
                "updated_at": "2026-01-21T17:15:00"
            }
        }
 
 
class OrderListResponse(BaseModel):
    """Response for list of orders."""
    orders: List[Order]
    total: int
 
 