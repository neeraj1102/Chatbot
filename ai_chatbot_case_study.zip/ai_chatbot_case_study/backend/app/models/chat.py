"""
Chat Models
Pydantic models for chat-related requests and responses
"""
 
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any, Literal
from datetime import datetime
 
 
class ChatMessage(BaseModel):
    """Chat message model."""
    id: Optional[str] = None
    session_id: str
    user_id: str
    message: str
    role: Literal["user", "assistant", "system"] = "user"
    timestamp: Optional[datetime] = None
    metadata: Optional[Dict[str, Any]] = {}
 
 
class ChatRequest(BaseModel):
    """Chat request from user."""
    session_id: str = Field(..., description="Unique session identifier")
    user_id: str = Field(..., description="User identifier")
    message: str = Field(..., min_length=1, max_length=1000, description="User message")
    order_id: Optional[str] = Field(None, description="Optional order ID for context")
 
 
class OrderContext(BaseModel):
    """Order context for chat response."""
    order_id: str
    status: str
    estimated_delivery: Optional[datetime] = None
    total_amount: Optional[float] = None
    items_count: Optional[int] = None
 
 
class ChatResponse(BaseModel):
    """Chat response to user."""
    message: str = Field(..., description="AI response message")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Confidence score")
    intent: str = Field(..., description="Detected intent")
    requires_escalation: bool = Field(False, description="Whether escalation is needed")
    suggested_actions: List[str] = Field(default_factory=list, description="Suggested next actions")
    order_context: Optional[OrderContext] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
 
 
class ConversationHistory(BaseModel):
    """Conversation history response."""
    session_id: str
    messages: List[ChatMessage]
    total_messages: int
    clarification_count: int = 0
    current_intent: Optional[str] = None
 
 
class ClearSessionRequest(BaseModel):
    """Request to clear a session."""
    session_id: str
 
 
class ClearSessionResponse(BaseModel):
    """Response after clearing session."""
    success: bool
    message: str
 
 