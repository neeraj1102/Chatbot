"""
User Models
Pydantic models for user data
"""
 
from pydantic import BaseModel, EmailStr, Field
from typing import Optional
from datetime import datetime
 
 
class User(BaseModel):
    """User model."""
    user_id: str
    name: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    phone: Optional[str] = Field(None, max_length=20)
    created_at: datetime
   
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "USER001",
                "name": "John Doe",
                "email": "john.doe@example.com",
                "phone": "+1234567890",
                "created_at": "2026-01-01T00:00:00"
            }
        }
 
 
class CreateUserRequest(BaseModel):
    """Request to create a user."""
    user_id: str = Field(..., min_length=1, max_length=50)
    name: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    phone: Optional[str] = Field(None, max_length=20)
 
 