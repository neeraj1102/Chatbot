"""
Validators
Input validation utilities
"""
 
import re
from typing import Optional
 
 
def validate_session_id(session_id: str) -> bool:
    """Validate session ID format (UUID)."""
    uuid_pattern = r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    return bool(re.match(uuid_pattern, session_id, re.IGNORECASE))
 
 
def validate_user_id(user_id: str) -> bool:
    """Validate user ID format."""
    if not user_id or len(user_id) > 50:
        return False
    # Alphanumeric and underscore only
    return bool(re.match(r'^[a-zA-Z0-9_]+$', user_id))
 
 
def validate_order_id(order_id: str) -> bool:
    """Validate order ID format."""
    if not order_id or len(order_id) > 50:
        return False
    # Alphanumeric and dash/underscore
    return bool(re.match(r'^[a-zA-Z0-9_-]+$', order_id))
 
 
def validate_message(message: str) -> tuple[bool, Optional[str]]:
    """
    Validate chat message.
    Returns (is_valid, error_message)
    """
    if not message or not message.strip():
        return False, "Message cannot be empty"
   
    if len(message) > 1000:
        return False, "Message too long (max 1000 characters)"
   
    # Check for suspicious patterns (basic XSS prevention)
    suspicious_patterns = [
        r'<script',
        r'javascript:',
        r'onerror=',
        r'onclick='
    ]
   
    for pattern in suspicious_patterns:
        if re.search(pattern, message, re.IGNORECASE):
            return False, "Message contains invalid content"
   
    return True, None
 
 
def sanitize_message(message: str) -> str:
    """Sanitize user message."""
    # Remove leading/trailing whitespace
    message = message.strip()
   
    # Remove multiple spaces
    message = re.sub(r'\s+', ' ', message)
   
    return message
 
 