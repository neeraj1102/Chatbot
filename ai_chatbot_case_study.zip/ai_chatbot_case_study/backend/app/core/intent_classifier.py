"""
Intent Classifier
Classifies user intent using LLM
"""
 
from typing import Tuple, Dict, Any
from app.config.llm_config import get_llm_config
from app.utils.logger import get_logger
import json
import re
 
logger = get_logger()
 
 
class IntentClassifier:
    """Classifies user intent from messages."""
   
    # Supported intents
    INTENTS = [
        "order_status",
        "payment_issue",
        "refund_request",
        "delivery_problem",
        "cancellation",
        "quality_complaint",
        "general_faq",
        "out_of_scope"
    ]
   
    # Intent descriptions for better classification
    INTENT_DESCRIPTIONS = {
        "order_status": "User wants to know the status of their order, track delivery, or check estimated arrival time",
        "payment_issue": "User has problems with payment, transaction failed, or payment not processed",
        "refund_request": "User wants a refund or asking about refund status",
        "delivery_problem": "Issues with delivery like delay, wrong address, or delivery partner not responding",
        "cancellation": "User wants to cancel an order or asking about cancellation policy",
        "quality_complaint": "Complaint about food quality, wrong items, or damaged products",
        "general_faq": "General questions about platform, policies, or how things work",
        "out_of_scope": "Query not related to orders, delivery, or platform support"
    }
   
    def __init__(self):
        self.llm_config = get_llm_config()
   
    async def classify(
        self,
        message: str,
        conversation_history: list = None
    ) -> Tuple[str, float, Dict[str, Any]]:
        """
        Classify user intent.
       
        Args:
            message: User message
            conversation_history: Optional conversation history for context
       
        Returns:
            Tuple of (intent, confidence, metadata)
        """
        try:
            # Build classification prompt
            prompt = self._build_classification_prompt(message, conversation_history)
           
            # Get LLM
            llm = self.llm_config.get_llm()
           
            # Classify
            result = await llm.ainvoke(prompt)
            response = result.content if hasattr(result, 'content') else str(result)
           
            # Parse response
            intent, confidence, metadata = self._parse_classification_response(response)
           
            logger.info(f"Classified intent: {intent} (confidence: {confidence:.2f})")
           
            return intent, confidence, metadata
       
        except Exception as e:
            logger.error(f"Error classifying intent: {e}")
            return "general_faq", 0.5, {"error": str(e)}
   
    def _build_classification_prompt(
        self,
        message: str,
        conversation_history: list = None
    ) -> str:
        """Build prompt for intent classification."""
       
        # Build intent list with descriptions
        intent_list = "\n".join([
            f"- {intent}: {self.INTENT_DESCRIPTIONS[intent]}"
            for intent in self.INTENTS
        ])
       
        # Add conversation history if available
        history_text = ""
        if conversation_history:
            history_text = "\n\nCONVERSATION HISTORY:\n"
            for msg in conversation_history[-3:]:  # Last 3 messages
                history_text += f"{msg.role.upper()}: {msg.message}\n"
       
        prompt = f"""Classify the user's intent from the following message.
 
AVAILABLE INTENTS:
{intent_list}
 
{history_text}
 
USER MESSAGE: {message}
 
Analyze the message and respond in this exact JSON format:
{{
  "intent": "<one of the intents above>",
  "confidence": <number between 0 and 1>,
  "reasoning": "<brief explanation>"
}}
 
Be precise and consider the context. If the query is not related to order support, classify as "out_of_scope".
"""
       
        return prompt
   
    def _parse_classification_response(self, response: str) -> Tuple[str, float, Dict[str, Any]]:
        """Parse LLM classification response."""
        try:
            # Try to extract JSON
            json_match = re.search(r'\{[^}]+\}', response, re.DOTALL)
            if json_match:
                data = json.loads(json_match.group())
                intent = data.get('intent', 'general_faq')
                confidence = float(data.get('confidence', 0.7))
                reasoning = data.get('reasoning', '')
               
                # Validate intent
                if intent not in self.INTENTS:
                    intent = 'general_faq'
               
                # Ensure confidence is in valid range
                confidence = max(0.0, min(1.0, confidence))
               
                return intent, confidence, {"reasoning": reasoning}
       
        except Exception as e:
            logger.warning(f"Error parsing classification response: {e}")
       
        # Fallback: try to find intent in response
        response_lower = response.lower()
        for intent in self.INTENTS:
            if intent.replace('_', ' ') in response_lower:
                return intent, 0.7, {"reasoning": "Fallback classification"}
       
        return "general_faq", 0.5, {"reasoning": "Default classification"}
   
    def classify_simple(self, message: str) -> str:
        """
        Simple rule-based classification (fallback).
       
        Args:
            message: User message
       
        Returns:
            Intent string
        """
        message_lower = message.lower()
       
        # Order status keywords
        if any(word in message_lower for word in ['where', 'track', 'status', 'order', 'delivery']):
            if any(word in message_lower for word in ['when', 'time', 'arrive', 'eta']):
                return "order_status"
       
        # Payment keywords
        if any(word in message_lower for word in ['payment', 'paid', 'charge', 'transaction']):
            if any(word in message_lower for word in ['fail', 'error', 'problem', 'issue']):
                return "payment_issue"
       
        # Refund keywords
        if any(word in message_lower for word in ['refund', 'money back', 'return']):
            return "refund_request"
       
        # Delivery problem keywords
        if any(word in message_lower for word in ['delay', 'late', 'slow', 'waiting']):
            return "delivery_problem"
       
        # Cancellation keywords
        if any(word in message_lower for word in ['cancel', 'cancellation']):
            return "cancellation"
       
        # Quality keywords
        if any(word in message_lower for word in ['wrong', 'quality', 'bad', 'cold', 'damaged']):
            return "quality_complaint"
       
        return "general_faq"
 
 
# Global intent classifier instance
_intent_classifier = None
 
 
def get_intent_classifier() -> IntentClassifier:
    """Get or create intent classifier instance."""
    global _intent_classifier
    if _intent_classifier is None:
        _intent_classifier = IntentClassifier()
    return _intent_classifier
 
 