"""
Confidence Calculator
Calculates confidence scores for AI responses
"""
 
from typing import Dict, Any, List
from app.utils.logger import get_logger
import re
 
logger = get_logger()
 
 
class ConfidenceCalculator:
    """Calculates confidence scores for chatbot responses."""
   
    def __init__(self):
        self.weights = {
            "context_relevance": 0.35,
            "response_completeness": 0.25,
            "factual_grounding": 0.25,
            "intent_confidence": 0.15
        }
   
    def calculate(
        self,
        response: str,
        query: str,
        context: str,
        intent_confidence: float = 0.8,
        retrieved_docs: List[Dict[str, Any]] = None
    ) -> float:
        """
        Calculate overall confidence score.
       
        Args:
            response: Generated response
            query: User query
            context: Context used for generation
            intent_confidence: Confidence from intent classification
            retrieved_docs: Documents retrieved from RAG
       
        Returns:
            Confidence score between 0 and 1
        """
        try:
            scores = {}
           
            # 1. Context relevance (35%)
            scores['context_relevance'] = self._calculate_context_relevance(
                response, context, retrieved_docs
            )
           
            # 2. Response completeness (25%)
            scores['response_completeness'] = self._calculate_completeness(
                response, query
            )
           
            # 3. Factual grounding (25%)
            scores['factual_grounding'] = self._calculate_grounding(
                response, context
            )
           
            # 4. Intent confidence (15%)
            scores['intent_confidence'] = intent_confidence
           
            # Calculate weighted average
            total_score = sum(
                scores[key] * self.weights[key]
                for key in self.weights.keys()
            )
           
            # Ensure score is between 0 and 1
            total_score = max(0.0, min(1.0, total_score))
           
            logger.debug(f"Confidence breakdown: {scores} -> {total_score:.2f}")
           
            return total_score
       
        except Exception as e:
            logger.error(f"Error calculating confidence: {e}")
            return 0.5  # Default medium confidence
   
    def _calculate_context_relevance(
        self,
        response: str,
        context: str,
        retrieved_docs: List[Dict[str, Any]] = None
    ) -> float:
        """Calculate how relevant the context is to the response."""
        if not context:
            return 0.3  # Low confidence without context
       
        score = 0.5  # Base score
       
        # Check if retrieved documents have good similarity scores
        if retrieved_docs:
            avg_distance = sum(doc.get('distance', 1.0) for doc in retrieved_docs) / len(retrieved_docs)
            # Convert distance to similarity (lower distance = higher similarity)
            similarity_score = 1 - avg_distance
            score += similarity_score * 0.3
       
        # Check if response references context
        context_words = set(context.lower().split())
        response_words = set(response.lower().split())
        overlap = len(context_words & response_words)
       
        if overlap > 10:
            score += 0.2
        elif overlap > 5:
            score += 0.1
       
        return min(1.0, score)
   
    def _calculate_completeness(self, response: str, query: str) -> float:
        """Calculate response completeness."""
        score = 0.5  # Base score
       
        # Check response length
        if len(response) < 20:
            score -= 0.3  # Too short
        elif len(response) > 50:
            score += 0.2  # Good length
       
        # Check if response addresses the query
        query_words = set(query.lower().split())
        response_words = set(response.lower().split())
        overlap = len(query_words & response_words)
       
        if overlap >= len(query_words) * 0.5:
            score += 0.2
       
        # Check for actionable information
        actionable_patterns = [
            r'\d+',  # Numbers (order IDs, times, etc.)
            r'(click|go to|visit|check)',  # Action verbs
            r'(will|can|should)',  # Modal verbs
        ]
       
        for pattern in actionable_patterns:
            if re.search(pattern, response.lower()):
                score += 0.1
                break
       
        return min(1.0, score)
   
    def _calculate_grounding(self, response: str, context: str) -> float:
        """Calculate how well the response is grounded in context."""
        if not context:
            return 0.4  # Lower score without context
       
        score = 0.5  # Base score
       
        # Check for speculative language (reduces confidence)
        speculative_words = [
            'maybe', 'perhaps', 'possibly', 'might', 'could be',
            'i think', 'probably', 'seems like', 'appears'
        ]
       
        response_lower = response.lower()
        speculative_count = sum(1 for word in speculative_words if word in response_lower)
       
        if speculative_count > 0:
            score -= 0.2 * min(speculative_count, 2)
       
        # Check for definitive language (increases confidence)
        definitive_words = [
            'is', 'will', 'has', 'confirmed', 'verified',
            'according to', 'based on', 'shows that'
        ]
       
        definitive_count = sum(1 for word in definitive_words if word in response_lower)
       
        if definitive_count > 0:
            score += 0.2
       
        # Check if response contains specific information from context
        # Extract potential facts (sentences with numbers, dates, specific terms)
        fact_patterns = [
            r'\d+\s*(minutes|hours|days)',  # Time references
            r'\$\d+',  # Money
            r'order\s*#?\w+',  # Order IDs
        ]
       
        for pattern in fact_patterns:
            if re.search(pattern, response_lower) and re.search(pattern, context.lower()):
                score += 0.15
                break
       
        return min(1.0, max(0.0, score))
   
    def should_escalate(
        self,
        confidence: float,
        intent: str,
        clarification_count: int,
        threshold: float = 0.7
    ) -> bool:
        """
        Determine if the query should be escalated.
       
        Args:
            confidence: Confidence score
            intent: Classified intent
            clarification_count: Number of clarification attempts
            threshold: Confidence threshold
       
        Returns:
            True if should escalate, False otherwise
        """
        # Low confidence
        if confidence < threshold:
            return True
       
        # Max clarifications reached
        if clarification_count >= 2:
            return True
       
        # Certain intents always escalate
        escalation_intents = [
            "quality_complaint",
            "refund_request",
            "payment_issue"
        ]
       
        if intent in escalation_intents and confidence < 0.9:
            return True
       
        return False
   
    def get_confidence_level(self, confidence: float) -> str:
        """
        Get confidence level label.
       
        Args:
            confidence: Confidence score
       
        Returns:
            Confidence level: 'high', 'medium', or 'low'
        """
        if confidence >= 0.9:
            return "high"
        elif confidence >= 0.7:
            return "medium"
        else:
            return "low"
 
 
# Global confidence calculator instance
_confidence_calculator = None
 
 
def get_confidence_calculator() -> ConfidenceCalculator:
    """Get or create confidence calculator instance."""
    global _confidence_calculator
    if _confidence_calculator is None:
        _confidence_calculator = ConfidenceCalculator()
    return _confidence_calculator
 
 