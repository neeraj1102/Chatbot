"""
Vector Store
Manages ChromaDB vector store for RAG
"""
 
import chromadb
from chromadb.config import Settings
from typing import List, Dict, Any, Optional
from pathlib import Path
from app.config.settings import settings
from app.config.llm_config import get_llm_config
from app.utils.logger import get_logger
 
logger = get_logger()
 
 
class VectorStore:
    """Vector store for knowledge base embeddings."""
   
    def __init__(self):
        self.client = None
        self.collection = None
        self.embeddings = None
        self._initialize()
   
    def _initialize(self):
        """Initialize ChromaDB client and collection."""
        try:
            # Create persist directory if it doesn't exist
            persist_dir = Path(settings.CHROMA_PERSIST_DIRECTORY)
            persist_dir.mkdir(parents=True, exist_ok=True)
           
            # Initialize ChromaDB client
            self.client = chromadb.PersistentClient(
                path=str(persist_dir),
                settings=Settings(
                    anonymized_telemetry=False,
                    allow_reset=True
                )
            )
           
            # Get embeddings model
            llm_config = get_llm_config()
            self.embeddings = llm_config.get_embeddings()
           
            # Get or create collection
            try:
                self.collection = self.client.get_collection(
                    name=settings.CHROMA_COLLECTION_NAME
                )
                logger.info(f"Loaded existing collection: {settings.CHROMA_COLLECTION_NAME}")
            except:
                self.collection = self.client.create_collection(
                    name=settings.CHROMA_COLLECTION_NAME,
                    metadata={"description": "Support knowledge base"}
                )
                logger.info(f"Created new collection: {settings.CHROMA_COLLECTION_NAME}")
       
        except Exception as e:
            logger.error(f"Error initializing vector store: {e}")
            raise
   
    def add_documents(
        self,
        documents: List[str],
        metadatas: List[Dict[str, Any]],
        ids: List[str]
    ):
        """
        Add documents to the vector store.
       
        Args:
            documents: List of text documents
            metadatas: List of metadata dicts for each document
            ids: List of unique IDs for each document
        """
        try:
            # Generate embeddings
            embeddings = [
                self.embeddings.embed_query(doc) for doc in documents
            ]
           
            # Add to collection
            self.collection.add(
                documents=documents,
                embeddings=embeddings,
                metadatas=metadatas,
                ids=ids
            )
           
            logger.info(f"Added {len(documents)} documents to vector store")
       
        except Exception as e:
            logger.error(f"Error adding documents to vector store: {e}")
            raise
   
    def similarity_search(
        self,
        query: str,
        k: int = None,
        filter_dict: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        Search for similar documents.
       
        Args:
            query: Search query
            k: Number of results to return
            filter_dict: Optional metadata filter
       
        Returns:
            List of documents with metadata and scores
        """
        try:
            k = k or settings.RAG_TOP_K
           
            # Generate query embedding
            query_embedding = self.embeddings.embed_query(query)
           
            # Search
            results = self.collection.query(
                query_embeddings=[query_embedding],
                n_results=k,
                where=filter_dict
            )
           
            # Format results
            documents = []
            if results['documents'] and results['documents'][0]:
                for i, doc in enumerate(results['documents'][0]):
                    documents.append({
                        'content': doc,
                        'metadata': results['metadatas'][0][i] if results['metadatas'] else {},
                        'distance': results['distances'][0][i] if results['distances'] else 0,
                        'id': results['ids'][0][i] if results['ids'] else None
                    })
           
            logger.info(f"Found {len(documents)} similar documents for query")
            return documents
       
        except Exception as e:
            logger.error(f"Error in similarity search: {e}")
            return []
   
    def get_collection_count(self) -> int:
        """Get number of documents in collection."""
        try:
            return self.collection.count()
        except:
            return 0
   
    def clear_collection(self):
        """Clear all documents from collection."""
        try:
            self.client.delete_collection(settings.CHROMA_COLLECTION_NAME)
            self.collection = self.client.create_collection(
                name=settings.CHROMA_COLLECTION_NAME,
                metadata={"description": "Support knowledge base"}
            )
            logger.info("Cleared vector store collection")
        except Exception as e:
            logger.error(f"Error clearing collection: {e}")
 
 
# Global vector store instance
_vector_store = None
 
 
def get_vector_store() -> VectorStore:
    """Get or create vector store instance."""
    global _vector_store
    if _vector_store is None:
        _vector_store = VectorStore()
    return _vector_store
 
 