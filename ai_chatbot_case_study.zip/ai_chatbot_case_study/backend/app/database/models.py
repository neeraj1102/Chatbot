"""
Database Models
SQLAlchemy ORM models for database tables
"""
 
from sqlalchemy import Column, String, Integer, Float, DateTime, Text, ForeignKey, JSON, Boolean
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database.session import Base
 
 
class User(Base):
    """User model."""
    __tablename__ = "users"
   
    user_id = Column(String(50), primary_key=True, index=True)
    name = Column(String(100))
    email = Column(String(100), unique=True, index=True)
    phone = Column(String(20))
    created_at = Column(DateTime, default=datetime.utcnow)
   
    # Relationships
    orders = relationship("Order", back_populates="user")
    conversations = relationship("Conversation", back_populates="user")
    tickets = relationship("Ticket", back_populates="user")
 
 
class Order(Base):
    """Order model."""
    __tablename__ = "orders"
   
    order_id = Column(String(50), primary_key=True, index=True)
    user_id = Column(String(50), ForeignKey("users.user_id"), index=True)
    status = Column(String(20), index=True)  # pending, confirmed, preparing, out_for_delivery, delivered, cancelled
    items = Column(JSON)  # List of order items
    total_amount = Column(Float)
    delivery_address = Column(Text)
    estimated_delivery = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
   
    # Relationships
    user = relationship("User", back_populates="orders")
    tickets = relationship("Ticket", back_populates="order")
 
 
class Conversation(Base):
    """Conversation message model."""
    __tablename__ = "conversations"
   
    conversation_id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String(50), index=True)
    user_id = Column(String(50), ForeignKey("users.user_id"), index=True)
    message = Column(Text)
    role = Column(String(20))  # user, assistant, system
    intent = Column(String(50))
    confidence = Column(Float)
    extra_data = Column(JSON)  # Changed from 'metadata' (reserved word in SQLAlchemy)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
   
    # Relationships
    user = relationship("User", back_populates="conversations")
 
 
class Ticket(Base):
    """Support ticket model."""
    __tablename__ = "tickets"
   
    ticket_id = Column(String(50), primary_key=True, index=True)
    user_id = Column(String(50), ForeignKey("users.user_id"), index=True)
    order_id = Column(String(50), ForeignKey("orders.order_id"), nullable=True, index=True)
    category = Column(String(50), index=True)  # delivery_issue, payment_issue, quality_issue, refund_request, other
    priority = Column(String(20))  # low, medium, high
    description = Column(Text)
    conversation_history = Column(JSON)  # Stored conversation messages
    status = Column(String(20), index=True)  # open, in_progress, resolved, closed
    assigned_to = Column(String(50), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    resolved_at = Column(DateTime, nullable=True)
   
    # Relationships
    user = relationship("User", back_populates="tickets")
    order = relationship("Order", back_populates="tickets")
 
 
class ConversationSession(Base):
    """Conversation session tracking."""
    __tablename__ = "conversation_sessions"
   
    session_id = Column(String(50), primary_key=True, index=True)
    user_id = Column(String(50), ForeignKey("users.user_id"), index=True)
    clarification_count = Column(Integer, default=0)
    current_intent = Column(String(50), nullable=True)
    order_id = Column(String(50), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    extra_data = Column(JSON)  # Changed from 'metadata' (reserved word in SQLAlchemy)
 
 