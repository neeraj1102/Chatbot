"""
RAG Service
Retrieval-Augmented Generation service for knowledge base queries
"""
 
from typing import List, Dict, Any, Optional
from app.core.vector_store import get_vector_store
from app.config.settings import settings
from app.utils.logger import get_logger
import json
from pathlib import Path
 
logger = get_logger()
 
 
class RAGService:
    """Service for Retrieval-Augmented Generation."""
   
    def __init__(self):
        self.vector_store = get_vector_store()
        self.knowledge_base_path = Path(__file__).parent.parent.parent / "knowledge_base"
   
    def retrieve_context(
        self,
        query: str,
        top_k: int = None,
        category: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Retrieve relevant context from knowledge base.
       
        Args:
            query: User query
            top_k: Number of documents to retrieve
            category: Optional category filter
       
        Returns:
            List of relevant documents with metadata
        """
        try:
            top_k = top_k or settings.RAG_TOP_K
           
            # Build filter - disabled to allow all documents
            # Category filtering was causing issues (plural vs singular mismatch)
            filter_dict = None
            # if category:
            #     filter_dict = {"category": category}
           
            # Search vector store
            results = self.vector_store.similarity_search(
                query=query,
                k=top_k,
                filter_dict=filter_dict
            )
           
            # Filter by similarity threshold
            # ChromaDB distance: lower is better (0 = identical, 2 = very different)
            # Accept documents with distance < 1.5 (fairly similar)
            filtered_results = [
                doc for doc in results
                if doc['distance'] < 1.5
            ]
           
            logger.info(
                f"Retrieved {len(filtered_results)} relevant documents "
                f"(from {len(results)} total)"
            )
           
            return filtered_results
       
        except Exception as e:
            logger.error(f"Error retrieving context: {e}")
            return []
   
    def build_context_string(
        self,
        documents: List[Dict[str, Any]],
        max_length: int = 2000
    ) -> str:
        """
        Build context string from retrieved documents.
       
        Args:
            documents: List of retrieved documents
            max_length: Maximum length of context string
       
        Returns:
            Formatted context string
        """
        if not documents:
            return ""
       
        context_parts = []
        current_length = 0
       
        for i, doc in enumerate(documents, 1):
            content = doc['content']
            metadata = doc.get('metadata', {})
           
            # Format document
            doc_text = f"\n[Document {i}]"
            if metadata.get('category'):
                doc_text += f" (Category: {metadata['category']})"
            doc_text += f"\n{content}\n"
           
            # Check length
            if current_length + len(doc_text) > max_length:
                break
           
            context_parts.append(doc_text)
            current_length += len(doc_text)
       
        return "\n".join(context_parts)
   
    def get_relevant_faqs(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        """Get relevant FAQs for a query."""
        return self.retrieve_context(query, top_k=top_k, category="faq")
   
    def get_relevant_policies(self, query: str, top_k: int = 2) -> List[Dict[str, Any]]:
        """Get relevant policies for a query."""
        return self.retrieve_context(query, top_k=top_k, category="policy")
   
    def get_troubleshooting_steps(self, query: str, top_k: int = 2) -> List[Dict[str, Any]]:
        """Get relevant troubleshooting steps for a query."""
        return self.retrieve_context(query, top_k=top_k, category="troubleshooting")
   
    def load_knowledge_base(self) -> Dict[str, int]:
        """
        Load knowledge base files into vector store.
       
        Returns:
            Dictionary with counts of loaded documents by type
        """
        try:
            counts = {
                "faqs": 0,
                "policies": 0,
                "troubleshooting": 0
            }
           
            # Load FAQs
            faqs_path = self.knowledge_base_path / "faqs.json"
            if faqs_path.exists():
                counts["faqs"] = self._load_faqs(faqs_path)
           
            # Load Policies
            policies_path = self.knowledge_base_path / "policies.json"
            if policies_path.exists():
                counts["policies"] = self._load_policies(policies_path)
           
            # Load Troubleshooting
            troubleshooting_path = self.knowledge_base_path / "troubleshooting.json"
            if troubleshooting_path.exists():
                counts["troubleshooting"] = self._load_troubleshooting(troubleshooting_path)
           
            logger.info(f"Loaded knowledge base: {counts}")
            return counts
       
        except Exception as e:
            logger.error(f"Error loading knowledge base: {e}")
            return {"error": str(e)}
   
    def _load_faqs(self, file_path: Path) -> int:
        """Load FAQs into vector store."""
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
       
        faqs = data.get('faqs', [])
        documents = []
        metadatas = []
        ids = []
       
        for faq in faqs:
            # Combine question and answer
            doc_text = f"Q: {faq['question']}\nA: {faq['answer']}"
            documents.append(doc_text)
           
            metadatas.append({
                "category": "faq",
                "subcategory": faq.get('category', 'general'),
                "keywords": ",".join(faq.get('keywords', [])),
                "source": "faqs.json"
            })
           
            ids.append(f"faq_{faq['id']}")
       
        if documents:
            self.vector_store.add_documents(documents, metadatas, ids)
       
        return len(documents)
   
    def _load_policies(self, file_path: Path) -> int:
        """Load policies into vector store."""
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
       
        policies = data.get('policies', [])
        documents = []
        metadatas = []
        ids = []
       
        for policy in policies:
            doc_text = f"{policy['title']}\n\n{policy['content']}"
            documents.append(doc_text)
           
            metadatas.append({
                "category": "policy",
                "subcategory": policy.get('category', 'general'),
                "title": policy['title'],
                "source": "policies.json"
            })
           
            ids.append(f"policy_{policy['id']}")
       
        if documents:
            self.vector_store.add_documents(documents, metadatas, ids)
       
        return len(documents)
   
    def _load_troubleshooting(self, file_path: Path) -> int:
        """Load troubleshooting guides into vector store."""
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
       
        guides = data.get('troubleshooting', [])
        documents = []
        metadatas = []
        ids = []
       
        for guide in guides:
            # Format steps
            steps_text = "\n".join([f"{i+1}. {step}" for i, step in enumerate(guide['steps'])])
            doc_text = f"Issue: {guide['issue']}\n\nSteps to resolve:\n{steps_text}"
            documents.append(doc_text)
           
            metadatas.append({
                "category": "troubleshooting",
                "subcategory": guide.get('category', 'general'),
                "issue": guide['issue'],
                "source": "troubleshooting.json"
            })
           
            ids.append(f"troubleshooting_{guide['id']}")
       
        if documents:
            self.vector_store.add_documents(documents, metadatas, ids)
       
        return len(documents)
   
    def get_knowledge_base_stats(self) -> Dict[str, Any]:
        """Get statistics about the knowledge base."""
        return {
            "total_documents": self.vector_store.get_collection_count(),
            "collection_name": settings.CHROMA_COLLECTION_NAME,
            "embedding_model": settings.OPENAI_EMBEDDING_MODEL,
            "top_k": settings.RAG_TOP_K,
            "similarity_threshold": settings.RAG_SIMILARITY_THRESHOLD
        }
 
 