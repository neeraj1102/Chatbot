"""
Order Service
Handles order-related operations
"""
 
from typing import Optional, List
from sqlalchemy.orm import Session
from app.database.models import Order as DBOrder
from app.models.order import Order, OrderStatus, OrderItem, OrderListResponse
from app.utils.logger import get_logger
from datetime import datetime, timedelta
import random
 
logger = get_logger()
 
 
class OrderService:
    """Service for managing orders."""
   
    def __init__(self, db: Session):
        self.db = db
   
    def get_order(self, order_id: str) -> Optional[Order]:
        """Get order by ID."""
        try:
            db_order = self.db.query(DBOrder).filter(DBOrder.order_id == order_id).first()
           
            if not db_order:
                logger.warning(f"Order not found: {order_id}")
                return None
           
            return self._db_to_pydantic(db_order)
       
        except Exception as e:
            logger.error(f"Error fetching order {order_id}: {e}")
            return None
   
    def get_user_orders(
        self,
        user_id: str,
        status: Optional[str] = None,
        limit: int = 10
    ) -> OrderListResponse:
        """Get orders for a user."""
        try:
            query = self.db.query(DBOrder).filter(DBOrder.user_id == user_id)
           
            if status:
                query = query.filter(DBOrder.status == status)
           
            query = query.order_by(DBOrder.created_at.desc()).limit(limit)
            db_orders = query.all()
           
            orders = [self._db_to_pydantic(order) for order in db_orders]
           
            return OrderListResponse(orders=orders, total=len(orders))
       
        except Exception as e:
            logger.error(f"Error fetching orders for user {user_id}: {e}")
            return OrderListResponse(orders=[], total=0)
   
    def get_active_order(self, user_id: str) -> Optional[Order]:
        """Get user's most recent active order."""
        try:
            db_order = (
                self.db.query(DBOrder)
                .filter(
                    DBOrder.user_id == user_id,
                    DBOrder.status.in_([
                        OrderStatus.PENDING,
                        OrderStatus.CONFIRMED,
                        OrderStatus.PREPARING,
                        OrderStatus.OUT_FOR_DELIVERY
                    ])
                )
                .order_by(DBOrder.created_at.desc())
                .first()
            )
           
            if db_order:
                return self._db_to_pydantic(db_order)
           
            return None
       
        except Exception as e:
            logger.error(f"Error fetching active order for user {user_id}: {e}")
            return None
   
    def get_latest_order(self, user_id: str) -> Optional[Order]:
        """
        Get the most recent order for a user (regardless of status).
        This is better for chatbot context than just active orders.
        """
        try:
            db_order = (
                self.db.query(DBOrder)
                .filter(DBOrder.user_id == user_id)
                .order_by(DBOrder.created_at.desc())
                .first()
            )
           
            if db_order:
                logger.info(f"Found latest order for user {user_id}: {db_order.order_id} (status: {db_order.status})")
                return self._db_to_pydantic(db_order)
           
            logger.info(f"No orders found for user {user_id}")
            return None
       
        except Exception as e:
            logger.error(f"Error fetching latest order for user {user_id}: {e}")
            return None
   
    def get_all_active_orders(self, user_id: str) -> List[Order]:
        """
        Get ALL active orders for a user, sorted by priority.
        Priority order: OUT_FOR_DELIVERY > PREPARING > CONFIRMED > PENDING
        """
        try:
            # Define status priority (lower number = higher priority)
            status_priority = {
                'out_for_delivery': 1,
                'preparing': 2,
                'confirmed': 3,
                'pending': 4
            }
           
            db_orders = (
                self.db.query(DBOrder)
                .filter(
                    DBOrder.user_id == user_id,
                    DBOrder.status.in_([
                        OrderStatus.PENDING,
                        OrderStatus.CONFIRMED,
                        OrderStatus.PREPARING,
                        OrderStatus.OUT_FOR_DELIVERY
                    ])
                )
                .all()
            )
           
            if db_orders:
                # Convert to Pydantic models
                orders = [self._db_to_pydantic(order) for order in db_orders]
               
                # Sort by status priority, then by creation time (newest first)
                orders.sort(key=lambda x: (
                    status_priority.get(x.status.value, 99),
                    -x.created_at.timestamp()
                ))
               
                logger.info(f"Found {len(orders)} active order(s) for user {user_id}")
                return orders
           
            logger.info(f"No active orders found for user {user_id}")
            return []
       
        except Exception as e:
            logger.error(f"Error fetching active orders for user {user_id}: {e}")
            return []
   
    def _db_to_pydantic(self, db_order: DBOrder) -> Order:
        """Convert database model to Pydantic model."""
        return Order(
            order_id=db_order.order_id,
            user_id=db_order.user_id,
            status=OrderStatus(db_order.status),
            items=[OrderItem(**item) for item in db_order.items],
            total_amount=db_order.total_amount,
            delivery_address=db_order.delivery_address,
            estimated_delivery=db_order.estimated_delivery,
            created_at=db_order.created_at,
            updated_at=db_order.updated_at
        )
   
    @staticmethod
    def create_mock_order(user_id: str, order_id: str) -> Order:
        """Create a mock order for testing (when no DB order exists)."""
        statuses = [
            OrderStatus.CONFIRMED,
            OrderStatus.PREPARING,
            OrderStatus.OUT_FOR_DELIVERY
        ]
       
        status = random.choice(statuses)
       
        # Calculate estimated delivery based on status
        now = datetime.utcnow()
        if status == OrderStatus.CONFIRMED:
            eta = now + timedelta(minutes=45)
        elif status == OrderStatus.PREPARING:
            eta = now + timedelta(minutes=30)
        else:  # OUT_FOR_DELIVERY
            eta = now + timedelta(minutes=15)
       
        return Order(
            order_id=order_id,
            user_id=user_id,
            status=status,
            items=[
                OrderItem(
                    item_id="ITEM001",
                    name="Margherita Pizza",
                    quantity=1,
                    price=12.99
                ),
                OrderItem(
                    item_id="ITEM002",
                    name="Garlic Bread",
                    quantity=2,
                    price=4.99
                )
            ],
            total_amount=22.97,
            delivery_address="123 Main Street, Apt 4B, New York, NY 10001",
            estimated_delivery=eta,
            created_at=now - timedelta(minutes=20),
            updated_at=now - timedelta(minutes=5)
        )
 
 