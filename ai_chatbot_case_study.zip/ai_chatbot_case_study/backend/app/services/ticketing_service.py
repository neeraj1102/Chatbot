"""
Ticketing Service
Handles support ticket creation and management
"""
 
from typing import Optional, List
from sqlalchemy.orm import Session
from app.database.models import Ticket as DBTicket
from app.models.ticket import (
    Ticket, CreateTicketRequest, CreateTicketResponse,
    TicketListResponse, ConversationMessage
)
from app.utils.logger import get_logger
from datetime import datetime
import uuid
import json
 
logger = get_logger()
 
 
class TicketingService:
    """Service for managing support tickets."""
   
    def __init__(self, db: Session):
        self.db = db
   
    def create_ticket(self, request: CreateTicketRequest) -> CreateTicketResponse:
        """Create a new support ticket."""
        try:
            ticket_id = f"TKT{uuid.uuid4().hex[:8].upper()}"
           
            # Convert conversation history to JSON-serializable dict
            # Use mode='json' to ensure datetime objects are serialized to ISO strings
            conversation_dict = [msg.model_dump(mode='json') for msg in request.conversation_history]
           
            db_ticket = DBTicket(
                ticket_id=ticket_id,
                user_id=request.user_id,
                order_id=request.order_id,
                category=request.category,
                priority=request.priority,
                description=request.description,
                conversation_history=conversation_dict,
                status="open",
                created_at=datetime.utcnow()
            )
           
            self.db.add(db_ticket)
            self.db.commit()
            self.db.refresh(db_ticket)
           
            logger.info(f"Created ticket {ticket_id} for user {request.user_id}")
           
            # Determine estimated response time based on priority
            eta_map = {
                "high": "Within 1 hour",
                "medium": "Within 2 hours",
                "low": "Within 4 hours"
            }
           
            return CreateTicketResponse(
                ticket_id=ticket_id,
                status="open",
                created_at=db_ticket.created_at,
                estimated_response_time=eta_map.get(request.priority, "Within 2 hours")
            )
       
        except Exception as e:
            logger.error(f"Error creating ticket: {e}")
            self.db.rollback()
            raise
   
    def get_ticket(self, ticket_id: str) -> Optional[Ticket]:
        """Get ticket by ID."""
        try:
            db_ticket = self.db.query(DBTicket).filter(DBTicket.ticket_id == ticket_id).first()
           
            if not db_ticket:
                logger.warning(f"Ticket not found: {ticket_id}")
                return None
           
            return self._db_to_pydantic(db_ticket)
       
        except Exception as e:
            logger.error(f"Error fetching ticket {ticket_id}: {e}")
            return None
   
    def get_user_tickets(self, user_id: str, limit: int = 10) -> TicketListResponse:
        """Get tickets for a user."""
        try:
            db_tickets = (
                self.db.query(DBTicket)
                .filter(DBTicket.user_id == user_id)
                .order_by(DBTicket.created_at.desc())
                .limit(limit)
                .all()
            )
           
            tickets = [self._db_to_pydantic(ticket) for ticket in db_tickets]
           
            return TicketListResponse(tickets=tickets, total=len(tickets))
       
        except Exception as e:
            logger.error(f"Error fetching tickets for user {user_id}: {e}")
            return TicketListResponse(tickets=[], total=0)
   
    def update_ticket_status(self, ticket_id: str, status: str) -> bool:
        """Update ticket status."""
        try:
            db_ticket = self.db.query(DBTicket).filter(DBTicket.ticket_id == ticket_id).first()
           
            if not db_ticket:
                return False
           
            db_ticket.status = status
           
            if status in ["resolved", "closed"]:
                db_ticket.resolved_at = datetime.utcnow()
           
            self.db.commit()
            logger.info(f"Updated ticket {ticket_id} status to {status}")
           
            return True
       
        except Exception as e:
            logger.error(f"Error updating ticket {ticket_id}: {e}")
            self.db.rollback()
            return False
   
    def _db_to_pydantic(self, db_ticket: DBTicket) -> Ticket:
        """Convert database model to Pydantic model."""
        conversation_history = [
            ConversationMessage(**msg) for msg in (db_ticket.conversation_history or [])
        ]
       
        return Ticket(
            ticket_id=db_ticket.ticket_id,
            user_id=db_ticket.user_id,
            order_id=db_ticket.order_id,
            category=db_ticket.category,
            priority=db_ticket.priority,
            description=db_ticket.description,
            conversation_history=conversation_history,
            status=db_ticket.status,
            assigned_to=db_ticket.assigned_to,
            created_at=db_ticket.created_at,
            resolved_at=db_ticket.resolved_at
        )
 
 