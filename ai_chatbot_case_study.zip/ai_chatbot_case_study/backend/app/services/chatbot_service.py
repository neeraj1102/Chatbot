"""
Chatbot Service
Main orchestration service for chatbot interactions
"""
 
from typing import Optional
from sqlalchemy.orm import Session
from app.models.chat import ChatRequest, ChatResponse, OrderContext
from app.models.ticket import CreateTicketRequest, ConversationMessage
from app.services.conversation_service import ConversationService
from app.services.order_service import OrderService
from app.services.rag_service import RAGService
from app.services.guardrail_service import GuardrailService
from app.services.ticketing_service import TicketingService
from app.core.confidence_calculator import get_confidence_calculator
from app.config.llm_config import get_llm_config
from app.config.settings import settings
from app.utils.logger import get_logger
from pathlib import Path
import re
 
logger = get_logger()
 
 
class ChatbotService:
    """Main chatbot orchestration service."""
   
    def __init__(self, db: Session):
        self.db = db
        self.conversation_service = ConversationService(db)
        self.order_service = OrderService(db)
        self.rag_service = RAGService()
        self.guardrail_service = GuardrailService()
        self.ticketing_service = TicketingService(db)
        self.confidence_calculator = get_confidence_calculator()
        self.llm_config = get_llm_config()
        self.system_prompt = self._load_system_prompt()
   
    def _load_system_prompt(self) -> str:
        """Load system prompt from file."""
        try:
            prompt_path = Path(__file__).parent.parent.parent / "prompts" / "system_prompt.txt"
            with open(prompt_path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            logger.error(f"Error loading system prompt: {e}")
            return "You are a helpful customer support assistant."
   
    async def process_message(self, request: ChatRequest) -> ChatResponse:
        """
        Process incoming chat message and generate response.
        Main orchestration method.
        """
        try:
            logger.info(f"Processing message for session {request.session_id}")
           
            # 1. Save user message
            self.conversation_service.save_message(
                session_id=request.session_id,
                user_id=request.user_id,
                message=request.message,
                role="user"
            )
           
            # 2. Get conversation history
            history = self.conversation_service.get_conversation_history(request.session_id)
           
            # 3. Check clarification count (guardrail)
            if history.clarification_count >= settings.MAX_CLARIFICATION_ATTEMPTS:
                return self._create_escalation_response(
                    "I've asked for clarification a few times, but I want to make sure you get the best help. Let me connect you with our support team who can assist you better.",
                    request.session_id,
                    request.user_id
                )
           
            # 4. Apply guardrails (topic relevance, intent classification)
            guardrail_results = await self.guardrail_service.apply_guardrails(
                message=request.message,
                conversation_history=history.messages
            )
           
            # 5. Check if message is out of scope
            if not guardrail_results["should_proceed"]:
                out_of_scope_response = self.guardrail_service.get_out_of_scope_response()
               
                self.conversation_service.save_message(
                    session_id=request.session_id,
                    user_id=request.user_id,
                    message=out_of_scope_response,
                    role="assistant",
                    intent="out_of_scope",
                    confidence=0.9
                )
               
                return ChatResponse(
                    message=out_of_scope_response,
                    confidence=0.9,
                    intent="out_of_scope",
                    requires_escalation=False,
                    suggested_actions=[],
                    metadata={"rejection_reason": guardrail_results.get("rejection_reason")}
                )
           
            # 6. Check if clarification is needed
            if guardrail_results.get("needs_clarification"):
                clarification_msg = guardrail_results["clarification_question"]
               
                self.conversation_service.save_message(
                    session_id=request.session_id,
                    user_id=request.user_id,
                    message=clarification_msg,
                    role="assistant",
                    intent=guardrail_results["intent"],
                    confidence=guardrail_results["intent_confidence"]
                )
               
                # Increment clarification count
                self.conversation_service.increment_clarification_count(request.session_id)
               
                return ChatResponse(
                    message=clarification_msg,
                    confidence=guardrail_results["intent_confidence"],
                    intent=guardrail_results["intent"],
                    requires_escalation=False,
                    suggested_actions=[],
                    metadata={"needs_clarification": True}
                )
           
            # 7. Get order context if available
            order_context = None
            order = None
            all_orders = []
           
            if request.order_id:
                order = self.order_service.get_order(request.order_id)
                if order:
                    all_orders = [order]
            else:
                # Get ALL active orders (sorted by priority)
                all_orders = self.order_service.get_all_active_orders(request.user_id)
                if all_orders:
                    order = all_orders[0]  # Use first (highest priority) for context
           
            if order:
                order_context = OrderContext(
                    order_id=order.order_id,
                    status=order.status.value,
                    estimated_delivery=order.estimated_delivery,
                    total_amount=order.total_amount,
                    items_count=len(order.items)
                )
           
            # 8. Retrieve relevant context from knowledge base using RAG
            rag_documents = self.rag_service.retrieve_context(
                query=request.message,
                category=guardrail_results.get("category")
            )
            rag_context = self.rag_service.build_context_string(rag_documents)
           
            # 9. Build full context for LLM
            context = self._build_context(
                message=request.message,
                history=history,
                order=order,
                rag_context=rag_context,
                all_orders=all_orders
            )
           
            # 10. Generate response using LLM
            response_text, confidence, intent = await self._generate_response(
                message=request.message,
                context=context,
                intent_hint=guardrail_results["intent"]
            )
           
            # 10.5. If asking about order status and we have order data, ensure we use it
            if intent == "order_status" and all_orders:
                status_keywords = ['where', 'status', 'track', 'when', 'delivery', 'eta']
                if any(kw in request.message.lower() for kw in status_keywords):
                    # Show ALL active orders
                    if len(all_orders) > 1:
                        response_text = f"You have **{len(all_orders)} active orders**:\n\n"
                        for idx, ord in enumerate(all_orders, 1):
                            response_text += f"""**Order #{idx}: {ord.order_id}**
- **Status:** {ord.status.value.replace('_', ' ').title()}
- **Estimated Delivery:** {ord.estimated_delivery.strftime('%I:%M %p, %B %d, %Y')}
- **Delivery Address:** {ord.delivery_address}
- **Total Amount:** ${ord.total_amount:.2f}
- **Items:** {len(ord.items)} item(s)
 
"""
                        response_text += "\nAll your orders are being processed. If you have any concerns about a specific order, please let me know!"
                    else:
                        # Single order
                        ord = all_orders[0]
                        response_text = f"""Your order **{ord.order_id}** is currently **{ord.status.value.replace('_', ' ').title()}**.
 
📦 **Order Details:**
- **Status:** {ord.status.value.replace('_', ' ').title()}
- **Estimated Delivery:** {ord.estimated_delivery.strftime('%I:%M %p, %B %d, %Y')}
- **Delivery Address:** {ord.delivery_address}
- **Total Amount:** ${ord.total_amount:.2f}
- **Items:** {len(ord.items)} item(s)
 
Your order is on track and will be delivered soon. If you have any concerns, feel free to ask!"""
           
            # 11. Check if ticket should be auto-created
            ticket_id = None
            ticket_eta = None
            should_auto_create = self._should_auto_create_ticket(
                message=request.message,
                intent=intent,
                confidence=confidence
            )
           
            if should_auto_create:
                ticket_result = self._create_ticket(
                    user_id=request.user_id,
                    order_id=order.order_id if order else None,
                    intent=intent,
                    message=request.message,
                    conversation_history=history.messages
                )
               
                if ticket_result:
                    ticket_id = ticket_result["ticket_id"]
                    ticket_eta = ticket_result["estimated_response_time"]
                   
                    # Update response to include ticket confirmation
                    response_text = f"✓ Support ticket #{ticket_id} has been created for your issue.\n\n{response_text}\n\nOur support team will respond {ticket_eta.lower()}."
           
            # 12. Determine if escalation is needed
            requires_escalation = self._should_escalate(
                confidence=confidence,
                intent=intent,
                clarification_count=history.clarification_count
            )
           
            # 13. Generate suggested actions
            suggested_actions = self._get_suggested_actions(intent, order, confidence)
           
            # 14. Save assistant message
            self.conversation_service.save_message(
                session_id=request.session_id,
                user_id=request.user_id,
                message=response_text,
                role="assistant",
                intent=intent,
                confidence=confidence,
                extra_data={
                    "requires_escalation": requires_escalation,
                    "order_id": order.order_id if order else None,
                    "rag_documents_used": len(rag_documents),
                    "ticket_id": ticket_id
                }
            )
           
            # 15. Update session
            self.conversation_service.create_or_update_session(
                session_id=request.session_id,
                user_id=request.user_id,
                current_intent=intent,
                order_id=order.order_id if order else None
            )
           
            # 16. Create response
            return ChatResponse(
                message=response_text,
                confidence=confidence,
                intent=intent,
                requires_escalation=requires_escalation,
                suggested_actions=suggested_actions,
                order_context=order_context,
                metadata={
                    "clarification_count": history.clarification_count,
                    "has_order_context": order is not None,
                    "rag_documents_used": len(rag_documents),
                    "category": guardrail_results.get("category"),
                    "ticket_id": ticket_id,
                    "ticket_eta": ticket_eta
                }
            )
       
        except Exception as e:
            logger.error(f"Error processing message: {e}")
            return self._create_error_response()
   
    def _build_context(self, message: str, history, order, rag_context: str = "", all_orders: list = None) -> str:
        """Build context string for LLM."""
        context_parts = []
       
        # Add RAG context first (most important)
        if rag_context:
            context_parts.append("KNOWLEDGE BASE INFORMATION:")
            context_parts.append(rag_context)
       
        # Add conversation history
        if history.messages:
            context_parts.append("\nCONVERSATION HISTORY:")
            for msg in history.messages[-5:]:  # Last 5 messages
                context_parts.append(f"{msg.role.upper()}: {msg.message}")
       
        # Add ALL orders context if multiple orders exist
        if all_orders and len(all_orders) > 1:
            context_parts.append(f"\nALL ACTIVE ORDERS ({len(all_orders)} orders):")
            for idx, ord in enumerate(all_orders, 1):
                context_parts.append(f"\nOrder #{idx}:")
                context_parts.append(f"  Order ID: {ord.order_id}")
                context_parts.append(f"  Status: {ord.status.value}")
                context_parts.append(f"  Estimated Delivery: {ord.estimated_delivery}")
                context_parts.append(f"  Total Amount: ${ord.total_amount:.2f}")
                context_parts.append(f"  Delivery Address: {ord.delivery_address}")
        # Add single order context
        elif order:
            context_parts.append("\nORDER INFORMATION:")
            context_parts.append(f"Order ID: {order.order_id}")
            context_parts.append(f"Status: {order.status.value}")
            context_parts.append(f"Estimated Delivery: {order.estimated_delivery}")
            context_parts.append(f"Total Amount: ${order.total_amount:.2f}")
            context_parts.append(f"Delivery Address: {order.delivery_address}")
       
        return "\n".join(context_parts)
   
    async def _generate_response(
        self,
        message: str,
        context: str,
        intent_hint: str = None
    ) -> tuple[str, float, str]:
        """
        Generate response using LLM.
        Returns (response_text, confidence, intent)
        """
        try:
            # Build prompt with RAG context
            prompt = f"""{self.system_prompt}
 
{context}
 
USER QUERY: {message}
 
IMPORTANT INSTRUCTIONS:
- If ORDER INFORMATION is provided above, you MUST use the EXACT details (Order ID, Status, Estimated Delivery, Total Amount, Delivery Address) in your response
- DO NOT use placeholders like [insert address here] or generic statements
- DO NOT say "approximately" when you have the exact delivery time
- Use the actual data provided in the ORDER INFORMATION section
 
Based on the knowledge base information provided above, give a helpful and accurate response. If the knowledge base contains relevant information, use it to answer the question. Be specific and cite the information provided.
 
Classify the intent as one of: order_status, payment_issue, refund_request, delivery_problem, cancellation, quality_complaint, general_faq, out_of_scope
 
Response format:
INTENT: <intent>
RESPONSE: <your response>
"""
           
            # Get LLM
            llm = self.llm_config.get_llm()
           
            # Generate response
            result = await llm.ainvoke(prompt)
            response_content = result.content if hasattr(result, 'content') else str(result)
           
            # Parse response
            intent, response_text = self._parse_llm_response(response_content)
           
            # Use intent hint from guardrails if LLM didn't classify properly
            if intent == "general_faq" and intent_hint and intent_hint != "general_faq":
                intent = intent_hint
           
            # Calculate confidence
            confidence = self._calculate_confidence(response_text, context)
           
            return response_text, confidence, intent
       
        except Exception as e:
            logger.error(f"Error generating LLM response: {e}")
            return (
                "I apologize, but I'm having trouble processing your request right now. Would you like me to create a support ticket for you?",
                0.3,
                "error"
            )
   
    def _parse_llm_response(self, response: str) -> tuple[str, str]:
        """Parse LLM response to extract intent and message."""
        try:
            lines = response.strip().split('\n')
            intent = "general_faq"
            response_text = response
           
            for i, line in enumerate(lines):
                if line.startswith("INTENT:"):
                    intent = line.replace("INTENT:", "").strip()
                elif line.startswith("RESPONSE:"):
                    response_text = '\n'.join(lines[i:]).replace("RESPONSE:", "").strip()
                    break
           
            return intent, response_text
       
        except Exception as e:
            logger.error(f"Error parsing LLM response: {e}")
            return "general_faq", response
   
    def _calculate_confidence(self, response: str, context: str) -> float:
        """Calculate confidence score (simplified version)."""
        # This is a simplified version. In Phase 3, we'll implement proper confidence calculation
        confidence = 0.8
       
        # Lower confidence if response is too short
        if len(response) < 50:
            confidence -= 0.2
       
        # Lower confidence if no context available
        if not context or len(context) < 100:
            confidence -= 0.1
       
        # Ensure confidence is between 0 and 1
        return max(0.0, min(1.0, confidence))
   
    def _should_auto_create_ticket(
        self,
        message: str,
        intent: str,
        confidence: float
    ) -> bool:
        """
        Determine if a ticket should be automatically created.
       
        Auto-create tickets ONLY for:
        1. Quality complaints with specific details
        2. Specific issues mentioned (NOT generic 'raise a ticket')
        """
        message_lower = message.lower().strip()
       
        # Check if it's a GENERIC ticket request WITHOUT specific issue details
        generic_patterns = [
            r'^(raise|create|open|file)\s+(a\s+)?(ticket|complaint)\.?$',
            r'^(i\s+)?(want|need)\s+(to\s+)?(raise|create)\s+(a\s+)?ticket\.?$',
            r'^(talk|speak)\s+(to|with)\s+(support|agent)\.?$'
        ]
       
        # If generic request, DON'T auto-create
        for pattern in generic_patterns:
            if re.match(pattern, message_lower):
                logger.info(f"Generic ticket request - will NOT auto-create")
                return False
       
        # Auto-create for quality complaints with details
        if intent == "quality_complaint" and len(message.split()) > 3:
            logger.info(f"Auto-creating ticket: Quality complaint with details")
            return True
       
        # Auto-create if specific issue mentioned
        issue_keywords = ['cold', 'wrong', 'damaged', 'missing', 'late', 'broken', 'bad']
        if any(kw in message_lower for kw in issue_keywords):
            logger.info(f"Auto-creating ticket: Specific issue detected")
            return True
       
        return False
   
    def _create_ticket(
        self,
        user_id: str,
        order_id: Optional[str],
        intent: str,
        message: str,
        conversation_history: list
    ) -> Optional[dict]:
        """
        Create a support ticket.
       
        Returns dict with ticket_id and estimated_response_time, or None if failed.
        """
        try:
            # Map intent to ticket category
            category_map = {
                "quality_complaint": "quality_issue",
                "delivery_problem": "delivery_issue",
                "payment_issue": "payment_issue",
                "refund_request": "refund_request",
                "cancellation": "other"
            }
           
            category = category_map.get(intent, "other")
           
            # Determine priority based on intent
            priority_map = {
                "quality_complaint": "high",
                "delivery_problem": "high",
                "payment_issue": "medium",
                "refund_request": "medium",
                "cancellation": "medium"
            }
           
            priority = priority_map.get(intent, "medium")
           
            # Build description from message
            description = f"User message: {message}"
           
            # Convert conversation history to ConversationMessage objects
            conv_messages = []
            for msg in conversation_history[-5:]:  # Last 5 messages
                conv_messages.append(
                    ConversationMessage(
                        role=msg.role,
                        message=msg.message,
                        timestamp=msg.timestamp
                    )
                )
           
            # Create ticket request
            ticket_request = CreateTicketRequest(
                user_id=user_id,
                order_id=order_id,
                category=category,
                priority=priority,
                description=description,
                conversation_history=conv_messages
            )
           
            # Call ticketing service
            ticket_response = self.ticketing_service.create_ticket(ticket_request)
           
            logger.info(f"Ticket created successfully: {ticket_response.ticket_id}")
           
            return {
                "ticket_id": ticket_response.ticket_id,
                "estimated_response_time": ticket_response.estimated_response_time
            }
       
        except Exception as e:
            logger.error(f"Error creating ticket: {e}")
            return None
   
    def _should_escalate(
        self,
        confidence: float,
        intent: str,
        clarification_count: int
    ) -> bool:
        """Determine if escalation is needed."""
        # Low confidence
        if confidence < settings.CONFIDENCE_THRESHOLD:
            return True
       
        # Max clarifications reached
        if clarification_count >= settings.MAX_CLARIFICATION_ATTEMPTS:
            return True
       
        # Certain intents always escalate
        escalation_intents = ["quality_complaint", "refund_request"]
        if intent in escalation_intents:
            return True
       
        return False
   
    def _get_suggested_actions(self, intent: str, order, confidence: float = 0.8) -> list[str]:
        """Get suggested actions based on intent and confidence."""
        actions = []
       
        if intent == "order_status" and order:
            actions.append("track_order")
            if order.status.value in ["pending", "confirmed", "preparing"]:
                actions.append("cancel_order")
       
        elif intent == "delivery_problem":
            actions.append("contact_delivery_partner")
            actions.append("raise_ticket")
       
        elif intent in ["payment_issue", "refund_request"]:
            actions.append("raise_ticket")
            actions.append("view_refund_policy")
       
        elif intent == "cancellation" and order:
            if order.status.value in ["pending", "confirmed"]:
                actions.append("cancel_order")
            else:
                actions.append("raise_ticket")
       
        # Add "Create Ticket" button for low confidence responses
        elif confidence < settings.CONFIDENCE_THRESHOLD:
            actions.append("raise_ticket")
       
        return actions
   
    def _create_escalation_response(
        self,
        message: str,
        session_id: str,
        user_id: str
    ) -> ChatResponse:
        """Create an escalation response."""
        self.conversation_service.save_message(
            session_id=session_id,
            user_id=user_id,
            message=message,
            role="assistant",
            intent="escalation",
            confidence=1.0
        )
       
        return ChatResponse(
            message=message,
            confidence=1.0,
            intent="escalation",
            requires_escalation=True,
            suggested_actions=["create_ticket"],
            metadata={"escalation_reason": "max_clarifications"}
        )
   
    def _create_error_response(self) -> ChatResponse:
        """Create error response."""
        return ChatResponse(
            message="I apologize, but I'm experiencing technical difficulties. Please try again or create a support ticket.",
            confidence=0.0,
            intent="error",
            requires_escalation=True,
            suggested_actions=["create_ticket"],
            metadata={"error": True}
        )
 
 
 
 
 