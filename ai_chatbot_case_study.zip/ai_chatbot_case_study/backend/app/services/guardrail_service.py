"""
Guardrail Service
Advanced guardrails for chatbot safety and quality
"""
 
from typing import Tuple, Dict, Any, Optional
from app.core.intent_classifier import get_intent_classifier
from app.core.confidence_calculator import get_confidence_calculator
from app.config.llm_config import get_llm_config
from app.config.settings import settings
from app.utils.logger import get_logger
import re
import json
 
logger = get_logger()
 
 
class GuardrailService:
    """Service for implementing chatbot guardrails."""
   
    # Supported topics
    SUPPORTED_TOPICS = [
        "orders",
        "delivery",
        "payment",
        "refund",
        "cancellation",
        "quality",
        "account",
        "policies",
        "support"
    ]
   
    # Out-of-scope patterns
    OUT_OF_SCOPE_PATTERNS = [
        r'\b(weather|news|sports|politics|election)\b',
        r'\b(joke|story|game|play)\b',
        r'\b(recipe|cook|ingredient)\b',
        r'\b(movie|music|song|video)\b',
        # Removed problematic "what is" pattern - keyword matching handles valid queries
    ]
   
    def __init__(self):
        self.intent_classifier = get_intent_classifier()
        self.confidence_calculator = get_confidence_calculator()
        self.llm_config = get_llm_config()
   
    async def check_topic_relevance(self, message: str) -> Tuple[bool, str, float]:
        """
        Check if the message is relevant to supported topics.
       
        Args:
            message: User message
       
        Returns:
            Tuple of (is_relevant, category, confidence)
        """
        try:
            # Quick pattern-based check first
            message_lower = message.lower()
           
            # Check for obvious out-of-scope patterns
            for pattern in self.OUT_OF_SCOPE_PATTERNS:
                if re.search(pattern, message_lower, re.IGNORECASE):
                    logger.info(f"Message flagged as out-of-scope by pattern: {pattern}")
                    return False, "out_of_scope", 0.9
           
            # Check for supported topic keywords
            topic_keywords = {
                "orders": ["order", "purchase", "buy", "bought"],
                "delivery": ["deliver", "delivery", "arrive", "shipping", "track", "ship", "timing", "timings", "how long", "when will", "eta"],
                "payment": ["pay", "payment", "charge", "transaction", "card"],
                "refund": ["refund", "money back", "return"],
                "cancellation": ["cancel", "cancellation"],
                "quality": ["quality", "wrong", "damaged", "cold", "bad"],
                "account": ["account", "profile", "login", "password"],
                "policies": ["policy", "terms", "conditions", "how to", "how do", "what is", "what are"],
                "support": ["ticket", "support", "help", "agent", "human", "representative", "complaint", "issue", "problem", "raise", "create", "open", "file"]
            }
           
            for category, keywords in topic_keywords.items():
                if any(keyword in message_lower for keyword in keywords):
                    return True, category, 0.8
           
            # Use LLM for more nuanced check
            is_relevant, category, confidence = await self._llm_relevance_check(message)
           
            return is_relevant, category, confidence
       
        except Exception as e:
            logger.error(f"Error checking topic relevance: {e}")
            return True, "general", 0.5  # Default to allowing the message
   
    async def _llm_relevance_check(self, message: str) -> Tuple[bool, str, float]:
        """Use LLM to check topic relevance."""
        try:
            # Simplified, shorter prompt to avoid 413 errors
            prompt = f"""Is this query relevant to order support? Answer in JSON.
 
Topics: orders, delivery, payment, refunds, cancellations, quality, account, policies, support
 
Query: {message}
 
JSON: {{"is_relevant": true/false, "category": "order_status|delivery|payment|refund|cancellation|quality|account|policies|support|out_of_scope", "confidence": 0.0-1.0}}"""
           
            llm = self.llm_config.get_llm()
            result = await llm.ainvoke(prompt)
            response = result.content if hasattr(result, 'content') else str(result)
           
            # Parse response
            json_match = re.search(r'\{[^}]+\}', response, re.DOTALL)
            if json_match:
                data = json.loads(json_match.group())
                is_relevant = data.get('is_relevant', True)
                category = data.get('category', 'general')
                confidence = float(data.get('confidence', 0.7))
               
                return is_relevant, category, confidence
       
        except Exception as e:
            logger.warning(f"LLM relevance check failed: {e}")
            # On error, default to ALLOWING the message (not rejecting)
       
        return True, "general", 0.5
   
    def validate_response(
        self,
        response: str,
        context: str,
        query: str
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate AI response for safety and quality.
       
        Args:
            response: Generated response
            context: Context used
            query: User query
       
        Returns:
            Tuple of (is_valid, error_message)
        """
        # Check for empty response
        if not response or len(response.strip()) < 10:
            return False, "Response too short or empty"
       
        # Check for harmful content patterns
        harmful_patterns = [
            r'<script',
            r'javascript:',
            r'eval\(',
            r'exec\(',
        ]
       
        for pattern in harmful_patterns:
            if re.search(pattern, response, re.IGNORECASE):
                return False, "Response contains potentially harmful content"
       
        # Check for excessive speculation
        speculative_words = ['maybe', 'perhaps', 'possibly', 'might', 'could be', 'i think']
        speculative_count = sum(1 for word in speculative_words if word in response.lower())
       
        if speculative_count > 3:
            return False, "Response contains too much speculation"
       
        # Check if response is grounded in context
        if context and len(context) > 50:
            # Response should have some overlap with context
            context_words = set(context.lower().split())
            response_words = set(response.lower().split())
            overlap = len(context_words & response_words)
           
            if overlap < 3:
                logger.warning("Response may not be grounded in context")
                # Don't reject, but log warning
       
        return True, None
   
    def get_out_of_scope_response(self, category: str = None) -> str:
        """Get response for out-of-scope queries."""
        base_response = "I'm here to help with order-related queries. I can assist you with:\n\n"
       
        topics = [
            "• Order status and tracking",
            "• Payment and refund issues",
            "• Delivery problems",
            "• Order cancellations",
            "• Quality complaints",
            "• Account-related queries"
        ]
       
        return base_response + "\n".join(topics) + "\n\nHow can I help you with your order today?"
   
    def check_clarification_needed(
        self,
        query: str,
        intent: str,
        confidence: float
    ) -> Tuple[bool, Optional[str]]:
        """
        Check if clarification is needed.
       
        Args:
            query: User query
            intent: Classified intent
            confidence: Intent confidence
       
        Returns:
            Tuple of (needs_clarification, clarification_question)
        """
        # If confidence is low, ask for clarification
        if confidence < 0.6:
            return True, "I want to make sure I understand correctly. Could you please provide more details about your issue?"
       
        # Check for ambiguous queries
        if len(query.split()) < 3:
            if intent == "order_status":
                return True, "Could you please provide your order ID or tell me more about which order you're asking about?"
            elif intent == "delivery_problem":
                return True, "Could you please describe the delivery issue you're experiencing?"
       
        # Check for missing critical information
        if intent == "order_status" and not re.search(r'(order|ord|#)\s*\w+', query, re.IGNORECASE):
            # No order ID mentioned
            return True, "To check your order status, could you please provide your order ID?"
       
        return False, None
   
    def sanitize_response(self, response: str) -> str:
        """Sanitize response before sending to user."""
        # Remove any potential HTML/script tags
        response = re.sub(r'<[^>]+>', '', response)
       
        # Remove excessive whitespace
        response = re.sub(r'\s+', ' ', response)
       
        # Trim
        response = response.strip()
       
        return response
   
    async def apply_guardrails(
        self,
        message: str,
        conversation_history: list = None
    ) -> Dict[str, Any]:
        """
        Apply all guardrails to a message.
       
        Args:
            message: User message
            conversation_history: Optional conversation history
       
        Returns:
            Dictionary with guardrail results
        """
        results = {
            "is_relevant": True,
            "category": "general",
            "intent": "general_faq",
            "intent_confidence": 0.7,
            "needs_clarification": False,
            "clarification_question": None,
            "should_proceed": True,
            "rejection_reason": None
        }
       
        try:
            # 1. Check topic relevance
            is_relevant, category, relevance_confidence = await self.check_topic_relevance(message)
            results["is_relevant"] = is_relevant
            results["category"] = category
           
            if not is_relevant:
                results["should_proceed"] = False
                results["rejection_reason"] = "out_of_scope"
                return results
           
            # 2. Classify intent
            intent, intent_confidence, metadata = await self.intent_classifier.classify(
                message, conversation_history
            )
            results["intent"] = intent
            results["intent_confidence"] = intent_confidence
            results["intent_metadata"] = metadata
           
            # 3. Check if clarification needed
            needs_clarification, clarification_q = self.check_clarification_needed(
                message, intent, intent_confidence
            )
            results["needs_clarification"] = needs_clarification
            results["clarification_question"] = clarification_q
           
            return results
       
        except Exception as e:
            logger.error(f"Error applying guardrails: {e}")
            results["error"] = str(e)
            return results
 
 