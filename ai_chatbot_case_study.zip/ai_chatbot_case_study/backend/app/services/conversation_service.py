"""
Conversation Service
Manages conversation history and session state
"""
 
from typing import List, Optional
from sqlalchemy.orm import Session
from app.database.models import Conversation as DBConversation, ConversationSession as DBSession
from app.models.chat import ChatMessage, ConversationHistory
from app.config.settings import settings
from app.utils.logger import get_logger
from datetime import datetime
 
logger = get_logger()
 
 
class ConversationService:
    """Service for managing conversations."""
   
    def __init__(self, db: Session):
        self.db = db
   
    def save_message(
        self,
        session_id: str,
        user_id: str,
        message: str,
        role: str,
        intent: Optional[str] = None,
        confidence: Optional[float] = None,
        extra_data: Optional[dict] = None
    ) -> ChatMessage:
        """Save a conversation message."""
        try:
            db_message = DBConversation(
                session_id=session_id,
                user_id=user_id,
                message=message,
                role=role,
                intent=intent,
                confidence=confidence,
                extra_data=extra_data or {},
                timestamp=datetime.utcnow()
            )
           
            self.db.add(db_message)
            self.db.commit()
            self.db.refresh(db_message)
           
            return ChatMessage(
                id=str(db_message.conversation_id),
                session_id=session_id,
                user_id=user_id,
                message=message,
                role=role,
                timestamp=db_message.timestamp,
                metadata=extra_data or {}
            )
       
        except Exception as e:
            logger.error(f"Error saving message: {e}")
            self.db.rollback()
            raise
   
    def get_conversation_history(
        self,
        session_id: str,
        limit: Optional[int] = None
    ) -> ConversationHistory:
        """Get conversation history for a session."""
        try:
            limit = limit or settings.MAX_CONVERSATION_HISTORY
           
            db_messages = (
                self.db.query(DBConversation)
                .filter(DBConversation.session_id == session_id)
                .order_by(DBConversation.timestamp.desc())
                .limit(limit)
                .all()
            )
           
            # Reverse to get chronological order
            db_messages = list(reversed(db_messages))
           
            messages = [
                ChatMessage(
                    id=str(msg.conversation_id),
                    session_id=msg.session_id,
                    user_id=msg.user_id,
                    message=msg.message,
                    role=msg.role,
                    timestamp=msg.timestamp,
                    metadata=msg.extra_data or {}
                )
                for msg in db_messages
            ]
           
            # Get session info
            session_info = self.get_session(session_id)
            clarification_count = session_info.clarification_count if session_info else 0
            current_intent = session_info.current_intent if session_info else None
           
            return ConversationHistory(
                session_id=session_id,
                messages=messages,
                total_messages=len(messages),
                clarification_count=clarification_count,
                current_intent=current_intent
            )
       
        except Exception as e:
            logger.error(f"Error fetching conversation history: {e}")
            return ConversationHistory(
                session_id=session_id,
                messages=[],
                total_messages=0
            )
   
    def get_session(self, session_id: str) -> Optional[DBSession]:
        """Get or create conversation session."""
        try:
            session = self.db.query(DBSession).filter(DBSession.session_id == session_id).first()
            return session
        except Exception as e:
            logger.error(f"Error fetching session: {e}")
            return None
   
    def create_or_update_session(
        self,
        session_id: str,
        user_id: str,
        current_intent: Optional[str] = None,
        order_id: Optional[str] = None,
        extra_data: Optional[dict] = None
    ) -> DBSession:
        """Create or update conversation session."""
        try:
            session = self.get_session(session_id)
           
            if session:
                # Update existing session
                if current_intent:
                    session.current_intent = current_intent
                if order_id:
                    session.order_id = order_id
                if extra_data:
                    session.extra_data = extra_data
                session.updated_at = datetime.utcnow()
            else:
                # Create new session
                session = DBSession(
                    session_id=session_id,
                    user_id=user_id,
                    clarification_count=0,
                    current_intent=current_intent,
                    order_id=order_id,
                    is_active=True,
                    extra_data=extra_data or {},
                    created_at=datetime.utcnow(),
                    updated_at=datetime.utcnow()
                )
                self.db.add(session)
           
            self.db.commit()
            self.db.refresh(session)
           
            return session
       
        except Exception as e:
            logger.error(f"Error creating/updating session: {e}")
            self.db.rollback()
            raise
   
    def increment_clarification_count(self, session_id: str) -> int:
        """Increment clarification count for a session."""
        try:
            session = self.get_session(session_id)
           
            if session:
                session.clarification_count += 1
                session.updated_at = datetime.utcnow()
                self.db.commit()
                return session.clarification_count
           
            return 0
       
        except Exception as e:
            logger.error(f"Error incrementing clarification count: {e}")
            self.db.rollback()
            return 0
   
    def reset_clarification_count(self, session_id: str):
        """Reset clarification count for a session."""
        try:
            session = self.get_session(session_id)
           
            if session:
                session.clarification_count = 0
                session.updated_at = datetime.utcnow()
                self.db.commit()
       
        except Exception as e:
            logger.error(f"Error resetting clarification count: {e}")
            self.db.rollback()
   
    def clear_session(self, session_id: str) -> bool:
        """Clear a conversation session."""
        try:
            # Delete messages
            self.db.query(DBConversation).filter(
                DBConversation.session_id == session_id
            ).delete()
           
            # Delete session
            self.db.query(DBSession).filter(
                DBSession.session_id == session_id
            ).delete()
           
            self.db.commit()
            logger.info(f"Cleared session {session_id}")
           
            return True
       
        except Exception as e:
            logger.error(f"Error clearing session: {e}")
            self.db.rollback()
            return False
 
 