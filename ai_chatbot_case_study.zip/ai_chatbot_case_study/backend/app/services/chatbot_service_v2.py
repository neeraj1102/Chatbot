"""
Chatbot Service V2 - Enhanced with RAG and Advanced Guardrails
Main orchestration service for chatbot interactions
"""
 
from typing import Optional, List, Dict, Any
from sqlalchemy.orm import Session
from app.models.chat import ChatRequest, ChatResponse, OrderContext
from app.services.conversation_service import ConversationService
from app.services.order_service import OrderService
from app.services.rag_service import RAGService
from app.services.guardrail_service import GuardrailService
from app.core.confidence_calculator import get_confidence_calculator
from app.config.llm_config import get_llm_config
from app.config.settings import settings
from app.utils.logger import get_logger
from pathlib import Path
 
logger = get_logger()
 
 
class ChatbotServiceV2:
    """Enhanced chatbot orchestration service with RAG and advanced guardrails."""
   
    def __init__(self, db: Session):
        self.db = db
        self.conversation_service = ConversationService(db)
        self.order_service = OrderService(db)
        self.rag_service = RAGService()
        self.guardrail_service = GuardrailService()
        self.confidence_calculator = get_confidence_calculator()
        self.llm_config = get_llm_config()
        self.system_prompt = self._load_system_prompt()
   
    def _load_system_prompt(self) -> str:
        """Load system prompt from file."""
        try:
            prompt_path = Path(__file__).parent.parent.parent / "prompts" / "system_prompt.txt"
            with open(prompt_path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            logger.error(f"Error loading system prompt: {e}")
            return "You are a helpful customer support assistant."
   
    async def process_message(self, request: ChatRequest) -> ChatResponse:
        """
        Process incoming chat message and generate response.
        Enhanced with RAG and advanced guardrails.
        """
        try:
            logger.info(f"Processing message for session {request.session_id}")
           
            # 1. Save user message
            self.conversation_service.save_message(
                session_id=request.session_id,
                user_id=request.user_id,
                message=request.message,
                role="user"
            )
           
            # 2. Get conversation history
            history = self.conversation_service.get_conversation_history(request.session_id)
           
            # 3. Apply guardrails
            guardrail_results = await self.guardrail_service.apply_guardrails(
                request.message,
                history.messages
            )
           
            # Check if query is out of scope
            if not guardrail_results["should_proceed"]:
                out_of_scope_msg = self.guardrail_service.get_out_of_scope_response(
                    guardrail_results.get("category")
                )
                self.conversation_service.save_message(
                    session_id=request.session_id,
                    user_id=request.user_id,
                    message=out_of_scope_msg,
                    role="assistant",
                    intent="out_of_scope",
                    confidence=1.0
                )
                return ChatResponse(
                    message=out_of_scope_msg,
                    confidence=1.0,
                    intent="out_of_scope",
                    requires_escalation=False,
                    suggested_actions=[],
                    metadata={"reason": "out_of_scope"}
                )
           
            # Check clarification count
            if history.clarification_count >= settings.MAX_CLARIFICATION_ATTEMPTS:
                return self._create_escalation_response(
                    "I've asked for clarification a few times, but I want to make sure you get the best help. Let me connect you with our support team who can assist you better.",
                    request.session_id,
                    request.user_id
                )
           
            # Check if clarification is needed
            if guardrail_results.get("needs_clarification") and history.clarification_count < settings.MAX_CLARIFICATION_ATTEMPTS:
                clarification_msg = guardrail_results["clarification_question"]
                self.conversation_service.save_message(
                    session_id=request.session_id,
                    user_id=request.user_id,
                    message=clarification_msg,
                    role="assistant",
                    intent=guardrail_results["intent"],
                    confidence=guardrail_results["intent_confidence"]
                )
                self.conversation_service.increment_clarification_count(request.session_id)
               
                return ChatResponse(
                    message=clarification_msg,
                    confidence=guardrail_results["intent_confidence"],
                    intent=guardrail_results["intent"],
                    requires_escalation=False,
                    suggested_actions=[],
                    metadata={"needs_clarification": True}
                )
           
            # 4. Get order context if available
            order_context = None
            order = None
           
            if request.order_id:
                order = self.order_service.get_order(request.order_id)
            else:
                order = self.order_service.get_active_order(request.user_id)
           
            if order:
                order_context = OrderContext(
                    order_id=order.order_id,
                    status=order.status.value,
                    estimated_delivery=order.estimated_delivery,
                    total_amount=order.total_amount,
                    items_count=len(order.items)
                )
           
            # 5. Retrieve relevant context from knowledge base (RAG)
            retrieved_docs = self.rag_service.retrieve_context(
                query=request.message,
                top_k=settings.RAG_TOP_K
            )
           
            kb_context = self.rag_service.build_context_string(retrieved_docs)
           
            # 6. Build full context for LLM
            full_context = self._build_context(
                message=request.message,
                history=history,
                order=order,
                kb_context=kb_context
            )
           
            # 7. Generate response using LLM
            response_text = await self._generate_response(
                message=request.message,
                context=full_context,
                intent=guardrail_results["intent"]
            )
           
            # 8. Validate response
            is_valid, error_msg = self.guardrail_service.validate_response(
                response_text, full_context, request.message
            )
           
            if not is_valid:
                logger.warning(f"Response validation failed: {error_msg}")
                response_text = "I want to make sure I give you accurate information. Let me connect you with our support team."
                guardrail_results["intent_confidence"] = 0.3
           
            # 9. Calculate confidence score
            confidence = self.confidence_calculator.calculate(
                response=response_text,
                query=request.message,
                context=full_context,
                intent_confidence=guardrail_results["intent_confidence"],
                retrieved_docs=retrieved_docs
            )
           
            # 10. Determine if escalation is needed
            requires_escalation = self.confidence_calculator.should_escalate(
                confidence=confidence,
                intent=guardrail_results["intent"],
                clarification_count=history.clarification_count
            )
           
            # 11. Generate suggested actions
            suggested_actions = self._get_suggested_actions(guardrail_results["intent"], order)
           
            # 12. Sanitize response
            response_text = self.guardrail_service.sanitize_response(response_text)
           
            # 13. Save assistant message
            self.conversation_service.save_message(
                session_id=request.session_id,
                user_id=request.user_id,
                message=response_text,
                role="assistant",
                intent=guardrail_results["intent"],
                confidence=confidence,
                metadata={
                    "requires_escalation": requires_escalation,
                    "order_id": order.order_id if order else None,
                    "rag_docs_count": len(retrieved_docs),
                    "confidence_level": self.confidence_calculator.get_confidence_level(confidence)
                }
            )
           
            # 14. Update session
            self.conversation_service.create_or_update_session(
                session_id=request.session_id,
                user_id=request.user_id,
                current_intent=guardrail_results["intent"],
                order_id=order.order_id if order else None
            )
           
            # Reset clarification count if successful
            if confidence >= settings.CONFIDENCE_THRESHOLD:
                self.conversation_service.reset_clarification_count(request.session_id)
           
            # 15. Create response
            return ChatResponse(
                message=response_text,
                confidence=confidence,
                intent=guardrail_results["intent"],
                requires_escalation=requires_escalation,
                suggested_actions=suggested_actions,
                order_context=order_context,
                metadata={
                    "clarification_count": history.clarification_count,
                    "has_order_context": order is not None,
                    "rag_enabled": len(retrieved_docs) > 0,
                    "confidence_level": self.confidence_calculator.get_confidence_level(confidence)
                }
            )
       
        except Exception as e:
            logger.error(f"Error processing message: {e}", exc_info=True)
            return self._create_error_response()
   
    def _build_context(
        self,
        message: str,
        history,
        order,
        kb_context: str
    ) -> str:
        """Build comprehensive context string for LLM."""
        context_parts = []
       
        # Add knowledge base context (RAG)
        if kb_context:
            context_parts.append("KNOWLEDGE BASE CONTEXT:")
            context_parts.append(kb_context)
       
        # Add conversation history
        if history.messages:
            context_parts.append("\nCONVERSATION HISTORY:")
            for msg in history.messages[-5:]:  # Last 5 messages
                context_parts.append(f"{msg.role.upper()}: {msg.message}")
       
        # Add order context
        if order:
            context_parts.append("\nORDER INFORMATION:")
            context_parts.append(f"Order ID: {order.order_id}")
            context_parts.append(f"Status: {order.status.value}")
            context_parts.append(f"Estimated Delivery: {order.estimated_delivery}")
            context_parts.append(f"Total Amount: ${order.total_amount:.2f}")
            context_parts.append(f"Delivery Address: {order.delivery_address}")
       
        return "\n".join(context_parts)
   
    async def _generate_response(
        self,
        message: str,
        context: str,
        intent: str
    ) -> str:
        """Generate response using LLM with context."""
        try:
            # Build prompt
            prompt = f"""{self.system_prompt}
 
{context}
 
USER QUERY: {message}
DETECTED INTENT: {intent}
 
Based on the context above, provide a helpful, accurate response. Be specific and reference the information from the context when possible.
"""
           
            # Get LLM
            llm = self.llm_config.get_llm()
           
            # Generate response
            result = await llm.ainvoke(prompt)
            response_text = result.content if hasattr(result, 'content') else str(result)
           
            return response_text.strip()
       
        except Exception as e:
            logger.error(f"Error generating LLM response: {e}")
            return "I apologize, but I'm having trouble processing your request right now. Would you like me to create a support ticket for you?"
   
    def _get_suggested_actions(self, intent: str, order) -> List[str]:
        """Get suggested actions based on intent."""
        actions = []
       
        if intent == "order_status" and order:
            actions.append("track_order")
            if order.status.value in ["pending", "confirmed", "preparing"]:
                actions.append("cancel_order")
       
        elif intent == "delivery_problem":
            actions.append("contact_delivery_partner")
            actions.append("raise_ticket")
       
        elif intent in ["payment_issue", "refund_request"]:
            actions.append("raise_ticket")
            actions.append("view_refund_policy")
       
        elif intent == "cancellation" and order:
            if order.status.value in ["pending", "confirmed"]:
                actions.append("cancel_order")
            else:
                actions.append("raise_ticket")
       
        elif intent == "quality_complaint":
            actions.append("raise_ticket")
            actions.append("view_quality_policy")
       
        return actions
   
    def _create_escalation_response(
        self,
        message: str,
        session_id: str,
        user_id: str
    ) -> ChatResponse:
        """Create an escalation response."""
        self.conversation_service.save_message(
            session_id=session_id,
            user_id=user_id,
            message=message,
            role="assistant",
            intent="escalation",
            confidence=1.0
        )
       
        return ChatResponse(
            message=message,
            confidence=1.0,
            intent="escalation",
            requires_escalation=True,
            suggested_actions=["create_ticket"],
            metadata={"escalation_reason": "max_clarifications"}
        )
   
    def _create_error_response(self) -> ChatResponse:
        """Create error response."""
        return ChatResponse(
            message="I apologize, but I'm experiencing technical difficulties. Please try again or create a support ticket.",
            confidence=0.0,
            intent="error",
            requires_escalation=True,
            suggested_actions=["create_ticket"],
            metadata={"error": True}
        )
 
 