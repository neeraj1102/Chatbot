"""
API Dependencies
Shared dependencies for API routes
"""
 
from fastapi import Header, HTTPException, status
from typing import Optional
from app.config.settings import settings
 
 
async def verify_api_key(x_api_key: Optional[str] = Header(None)) -> str:
    """
    Verify API key from request header.
    For production, implement proper API key validation.
    """
    # In development, allow requests without API key
    if settings.ENVIRONMENT == "development":
        return "dev_key"
   
    if not x_api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key is required. Please provide X-API-Key header."
        )
   
    # TODO: Implement proper API key validation against database
    # For now, just check if it's not empty
    if len(x_api_key) < 10:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API key."
        )
   
    return x_api_key
 
 
def get_current_user_id(x_user_id: Optional[str] = Header(None)) -> Optional[str]:
    """
    Get current user ID from header (optional).
    For future authentication implementation.
    """
    return x_user_id
 
 