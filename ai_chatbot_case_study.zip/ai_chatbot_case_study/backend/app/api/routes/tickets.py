"""
Tickets API Routes
Endpoints for support ticket operations
"""
 
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models.ticket import (
    CreateTicketRequest, CreateTicketResponse,
    Ticket, TicketListResponse
)
from app.services.ticketing_service import TicketingService
from app.utils.validators import validate_user_id
from app.utils.logger import get_logger
 
logger = get_logger()
router = APIRouter(prefix="/tickets", tags=["tickets"])
 
 
@router.post("/create", response_model=CreateTicketResponse, status_code=status.HTTP_201_CREATED)
def create_ticket(
    request: CreateTicketRequest,
    db: Session = Depends(get_db)
):
    """
    Create a new support ticket.
   
    - **user_id**: User identifier
    - **order_id**: Optional related order ID
    - **category**: Ticket category (delivery_issue, payment_issue, quality_issue, refund_request, other)
    - **priority**: Ticket priority (low, medium, high)
    - **description**: Detailed description of the issue
    - **conversation_history**: Optional conversation history leading to ticket creation
    """
    if not validate_user_id(request.user_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid user_id format."
        )
   
    try:
        ticketing_service = TicketingService(db)
        response = ticketing_service.create_ticket(request)
       
        logger.info(f"Ticket created: {response.ticket_id} for user {request.user_id}")
       
        return response
   
    except Exception as e:
        logger.error(f"Error creating ticket: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error creating support ticket. Please try again."
        )
 
 
@router.get("/{ticket_id}", response_model=Ticket)
def get_ticket(
    ticket_id: str,
    db: Session = Depends(get_db)
):
    """
    Get ticket details by ticket ID.
   
    - **ticket_id**: Ticket identifier
    """
    try:
        ticketing_service = TicketingService(db)
        ticket = ticketing_service.get_ticket(ticket_id)
       
        if not ticket:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Ticket {ticket_id} not found."
            )
       
        return ticket
   
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching ticket {ticket_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error fetching ticket details."
        )
 
 
@router.get("/user/{user_id}", response_model=TicketListResponse)
def get_user_tickets(
    user_id: str,
    limit: int = Query(10, ge=1, le=100, description="Number of tickets to return"),
    db: Session = Depends(get_db)
):
    """
    Get all tickets for a user.
   
    - **user_id**: User identifier
    - **limit**: Maximum number of tickets to return (1-100, default: 10)
    """
    if not validate_user_id(user_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid user_id format."
        )
   
    try:
        ticketing_service = TicketingService(db)
        tickets = ticketing_service.get_user_tickets(user_id, limit)
       
        return tickets
   
    except Exception as e:
        logger.error(f"Error fetching tickets for user {user_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error fetching user tickets."
        )
 
 
@router.patch("/{ticket_id}/status")
def update_ticket_status(
    ticket_id: str,
    status: str = Query(..., description="New ticket status"),
    db: Session = Depends(get_db)
):
    """
    Update ticket status.
   
    - **ticket_id**: Ticket identifier
    - **status**: New status (open, in_progress, resolved, closed)
    """
    valid_statuses = ["open", "in_progress", "resolved", "closed"]
    if status not in valid_statuses:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid status. Must be one of: {', '.join(valid_statuses)}"
        )
   
    try:
        ticketing_service = TicketingService(db)
        success = ticketing_service.update_ticket_status(ticket_id, status)
       
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Ticket {ticket_id} not found."
            )
       
        return {"success": True, "message": f"Ticket {ticket_id} status updated to {status}"}
   
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating ticket {ticket_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error updating ticket status."
        )
 
 