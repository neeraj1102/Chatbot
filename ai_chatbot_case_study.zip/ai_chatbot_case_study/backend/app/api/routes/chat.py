"""
Chat API Routes
Endpoints for chat interactions
"""
 
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models.chat import (
    ChatRequest, ChatResponse, ConversationHistory,
    ClearSessionRequest, ClearSessionResponse
)
from app.services.chatbot_service import ChatbotService
from app.services.conversation_service import ConversationService
from app.utils.validators import validate_session_id, validate_user_id, validate_message
from app.utils.logger import get_logger
 
logger = get_logger()
router = APIRouter(prefix="/chat", tags=["chat"])
 
 
@router.post("/message", response_model=ChatResponse)
async def send_message(
    request: ChatRequest,
    db: Session = Depends(get_db)
):
    """
    Send a message to the chatbot and receive a response.
   
    - **session_id**: Unique session identifier (UUID format)
    - **user_id**: User identifier
    - **message**: User message (1-1000 characters)
    - **order_id**: Optional order ID for context
    """
    # Validate inputs
    if not validate_session_id(request.session_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid session_id format. Must be a valid UUID."
        )
   
    if not validate_user_id(request.user_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid user_id format."
        )
   
    is_valid, error_msg = validate_message(request.message)
    if not is_valid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=error_msg
        )
   
    try:
        # Process message
        chatbot_service = ChatbotService(db)
        response = await chatbot_service.process_message(request)
       
        logger.info(
            f"Message processed - Session: {request.session_id}, "
            f"Intent: {response.intent}, Confidence: {response.confidence:.2f}"
        )
       
        return response
   
    except Exception as e:
        logger.error(f"Error in send_message endpoint: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An error occurred while processing your message. Please try again."
        )
 
 
@router.get("/history/{session_id}", response_model=ConversationHistory)
def get_conversation_history(
    session_id: str,
    limit: int = 50,
    db: Session = Depends(get_db)
):
    """
    Get conversation history for a session.
   
    - **session_id**: Session identifier
    - **limit**: Maximum number of messages to retrieve (default: 50)
    """
    if not validate_session_id(session_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid session_id format."
        )
   
    try:
        conversation_service = ConversationService(db)
        history = conversation_service.get_conversation_history(session_id, limit)
       
        return history
   
    except Exception as e:
        logger.error(f"Error fetching conversation history: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error fetching conversation history."
        )
 
 
@router.delete("/session/{session_id}", response_model=ClearSessionResponse)
def clear_session(
    session_id: str,
    db: Session = Depends(get_db)
):
    """
    Clear a conversation session and its history.
   
    - **session_id**: Session identifier to clear
    """
    if not validate_session_id(session_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid session_id format."
        )
   
    try:
        conversation_service = ConversationService(db)
        success = conversation_service.clear_session(session_id)
       
        if success:
            return ClearSessionResponse(
                success=True,
                message=f"Session {session_id} cleared successfully."
            )
        else:
            return ClearSessionResponse(
                success=False,
                message="Session not found or already cleared."
            )
   
    except Exception as e:
        logger.error(f"Error clearing session: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error clearing session."
        )
 
 