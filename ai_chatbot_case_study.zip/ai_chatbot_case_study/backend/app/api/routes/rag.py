"""
RAG API Routes
Endpoints for RAG and knowledge base management
"""
 
from fastapi import APIRouter, HTTPException, status
from app.services.rag_service import RAGService
from app.core.vector_store import get_vector_store
from app.utils.logger import get_logger
from typing import Dict, Any, List
from pydantic import BaseModel
 
logger = get_logger()
router = APIRouter(prefix="/rag", tags=["rag"])
 
 
class SearchRequest(BaseModel):
    """Request for knowledge base search."""
    query: str
    top_k: int = 5
    category: str = None
 
 
class SearchResponse(BaseModel):
    """Response for knowledge base search."""
    query: str
    results: List[Dict[str, Any]]
    total_results: int
 
 
@router.post("/load-knowledge-base")
def load_knowledge_base():
    """
    Load knowledge base files and generate embeddings.
    This endpoint initializes the RAG system.
    """
    try:
        rag_service = RAGService()
       
        # Check if already loaded
        vector_store = get_vector_store()
        existing_count = vector_store.get_collection_count()
       
        if existing_count > 0:
            return {
                "success": True,
                "message": f"Knowledge base already loaded with {existing_count} documents",
                "documents_count": existing_count
            }
       
        # Load knowledge base
        counts = rag_service.load_knowledge_base()
       
        if "error" in counts:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error loading knowledge base: {counts['error']}"
            )
       
        total = sum(counts.values())
       
        logger.info(f"Knowledge base loaded: {counts}")
       
        return {
            "success": True,
            "message": f"Knowledge base loaded successfully with {total} documents",
            "counts": counts,
            "total_documents": total
        }
   
    except Exception as e:
        logger.error(f"Error loading knowledge base: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error loading knowledge base: {str(e)}"
        )
 
 
@router.get("/stats")
def get_rag_stats():
    """
    Get RAG system statistics.
    Returns information about the knowledge base and vector store.
    """
    try:
        rag_service = RAGService()
        stats = rag_service.get_knowledge_base_stats()
       
        return {
            "success": True,
            "stats": stats
        }
   
    except Exception as e:
        logger.error(f"Error getting RAG stats: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error retrieving RAG statistics"
        )
 
 
@router.post("/search", response_model=SearchResponse)
def search_knowledge_base(request: SearchRequest):
    """
    Search the knowledge base.
    Returns relevant documents for a query.
    """
    try:
        rag_service = RAGService()
       
        # Search
        results = rag_service.retrieve_context(
            query=request.query,
            top_k=request.top_k,
            category=request.category
        )
       
        return SearchResponse(
            query=request.query,
            results=results,
            total_results=len(results)
        )
   
    except Exception as e:
        logger.error(f"Error searching knowledge base: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error searching knowledge base"
        )
 
 
@router.delete("/clear")
def clear_knowledge_base():
    """
    Clear all embeddings from the vector store.
    Use with caution - this will delete all knowledge base data.
    """
    try:
        vector_store = get_vector_store()
        vector_store.clear_collection()
       
        logger.info("Knowledge base cleared")
       
        return {
            "success": True,
            "message": "Knowledge base cleared successfully"
        }
   
    except Exception as e:
        logger.error(f"Error clearing knowledge base: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error clearing knowledge base"
        )
 
 