"""
Orders API Routes
Endpoints for order-related operations
"""
 
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import Optional
from app.database.session import get_db
from app.models.order import Order, OrderListResponse
from app.services.order_service import OrderService
from app.utils.validators import validate_order_id, validate_user_id
from app.utils.logger import get_logger
 
logger = get_logger()
router = APIRouter(prefix="/orders", tags=["orders"])
 
 
@router.get("/{order_id}", response_model=Order)
def get_order(
    order_id: str,
    db: Session = Depends(get_db)
):
    """
    Get order details by order ID.
   
    - **order_id**: Order identifier
    """
    if not validate_order_id(order_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid order_id format."
        )
   
    try:
        order_service = OrderService(db)
        order = order_service.get_order(order_id)
       
        if not order:
            # Return mock order for demo purposes
            logger.info(f"Order {order_id} not found in DB, returning mock data")
            mock_order = OrderService.create_mock_order("demo_user", order_id)
            return mock_order
       
        return order
   
    except Exception as e:
        logger.error(f"Error fetching order {order_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error fetching order details."
        )
 
 
@router.get("/user/{user_id}", response_model=OrderListResponse)
def get_user_orders(
    user_id: str,
    status: Optional[str] = Query(None, description="Filter by order status"),
    limit: int = Query(10, ge=1, le=100, description="Number of orders to return"),
    db: Session = Depends(get_db)
):
    """
    Get all orders for a user.
   
    - **user_id**: User identifier
    - **status**: Optional status filter (pending, confirmed, preparing, out_for_delivery, delivered, cancelled)
    - **limit**: Maximum number of orders to return (1-100, default: 10)
    """
    if not validate_user_id(user_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid user_id format."
        )
   
    try:
        order_service = OrderService(db)
        orders = order_service.get_user_orders(user_id, status, limit)
       
        # If no orders found, return mock data for demo
        if orders.total == 0:
            logger.info(f"No orders found for user {user_id}, returning mock data")
            mock_order = OrderService.create_mock_order(user_id, "ORD" + user_id[:6].upper())
            return OrderListResponse(orders=[mock_order], total=1)
       
        return orders
   
    except Exception as e:
        logger.error(f"Error fetching orders for user {user_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error fetching user orders."
        )
 
 