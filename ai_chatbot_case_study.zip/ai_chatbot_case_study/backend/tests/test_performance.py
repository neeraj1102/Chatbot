"""
Performance Tests
Test system performance and response times
"""
 
import pytest
import requests
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
 
 
BASE_URL = "http://localhost:8000"
API_PREFIX = "/api/v1"
 
 
class TestPerformance:
    """Performance test suite."""
   
    def test_response_time_chat(self):
        """Test chat response time."""
        payload = {
            "session_id": str(uuid.uuid4()),
            "user_id": "perf_test_user",
            "message": "Where is my order?"
        }
       
        start_time = time.time()
        response = requests.post(
            f"{BASE_URL}{API_PREFIX}/chat/message",
            json=payload,
            timeout=10
        )
        duration = time.time() - start_time
       
        assert response.status_code == 200
        assert duration < 5.0, f"Response time {duration:.2f}s exceeds 5s threshold"
       
        print(f"\nChat response time: {duration:.2f}s")
   
    def test_response_time_order(self):
        """Test order retrieval response time."""
        start_time = time.time()
        response = requests.get(
            f"{BASE_URL}{API_PREFIX}/orders/ORD000001",
            timeout=5
        )
        duration = time.time() - start_time
       
        assert response.status_code == 200
        assert duration < 2.0, f"Response time {duration:.2f}s exceeds 2s threshold"
       
        print(f"\nOrder retrieval time: {duration:.2f}s")
   
    def test_response_time_rag_search(self):
        """Test RAG search response time."""
        payload = {
            "query": "What is your refund policy?",
            "top_k": 5
        }
       
        start_time = time.time()
        response = requests.post(
            f"{BASE_URL}{API_PREFIX}/rag/search",
            json=payload,
            timeout=5
        )
        duration = time.time() - start_time
       
        assert response.status_code == 200
        assert duration < 1.0, f"RAG search time {duration:.2f}s exceeds 1s threshold"
       
        print(f"\nRAG search time: {duration:.2f}s")
   
    def test_concurrent_requests(self):
        """Test handling concurrent requests."""
        num_requests = 10
       
        def send_request(i):
            payload = {
                "session_id": str(uuid.uuid4()),
                "user_id": f"concurrent_user_{i}",
                "message": f"Test message {i}"
            }
           
            start_time = time.time()
            response = requests.post(
                f"{BASE_URL}{API_PREFIX}/chat/message",
                json=payload,
                timeout=15
            )
            duration = time.time() - start_time
           
            return {
                "status": response.status_code,
                "duration": duration,
                "success": response.status_code == 200
            }
       
        start_time = time.time()
       
        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(send_request, i) for i in range(num_requests)]
            results = [future.result() for future in as_completed(futures)]
       
        total_duration = time.time() - start_time
       
        # Verify all requests succeeded
        success_count = sum(1 for r in results if r["success"])
        assert success_count == num_requests, f"Only {success_count}/{num_requests} requests succeeded"
       
        # Calculate average response time
        avg_duration = sum(r["duration"] for r in results) / len(results)
       
        print(f"\nConcurrent requests: {num_requests}")
        print(f"Total time: {total_duration:.2f}s")
        print(f"Average response time: {avg_duration:.2f}s")
        print(f"Success rate: {success_count}/{num_requests}")
   
    def test_memory_usage_chat_history(self):
        """Test memory usage with large conversation history."""
        session_id = str(uuid.uuid4())
        user_id = "memory_test_user"
       
        # Send 20 messages
        for i in range(20):
            payload = {
                "session_id": session_id,
                "user_id": user_id,
                "message": f"Test message number {i}"
            }
           
            response = requests.post(
                f"{BASE_URL}{API_PREFIX}/chat/message",
                json=payload,
                timeout=10
            )
           
            assert response.status_code == 200
       
        # Retrieve history
        start_time = time.time()
        response = requests.get(
            f"{BASE_URL}{API_PREFIX}/chat/history/{session_id}",
            timeout=5
        )
        duration = time.time() - start_time
       
        assert response.status_code == 200
        data = response.json()
       
        # Should retrieve messages efficiently
        assert duration < 1.0, f"History retrieval time {duration:.2f}s exceeds 1s"
        assert len(data["messages"]) <= 20
       
        print(f"\nHistory retrieval (20 messages): {duration:.2f}s")
   
    def test_database_query_performance(self):
        """Test database query performance."""
        user_id = "perf_test_user"
       
        # Test order queries
        start_time = time.time()
        response = requests.get(
            f"{BASE_URL}{API_PREFIX}/orders/user/{user_id}",
            params={"limit": 50},
            timeout=5
        )
        duration = time.time() - start_time
       
        assert response.status_code == 200
        assert duration < 2.0, f"Database query time {duration:.2f}s exceeds 2s"
       
        print(f"\nDatabase query (50 orders): {duration:.2f}s")
 
 
if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
 
 