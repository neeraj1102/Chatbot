"""
Integration Tests
End-to-end integration testing
"""
 
import pytest
import requests
import uuid
from datetime import datetime
 
 
BASE_URL = "http://localhost:8000"
API_PREFIX = "/api/v1"
 
 
class TestIntegration:
    """Integration test suite."""
   
    @pytest.fixture
    def session_id(self):
        """Generate unique session ID."""
        return str(uuid.uuid4())
   
    @pytest.fixture
    def user_id(self):
        """Test user ID."""
        return "test_user_integration"
   
    def test_health_check(self):
        """Test API health check."""
        response = requests.get(f"{BASE_URL}/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
   
    def test_api_info(self):
        """Test API info endpoint."""
        response = requests.get(f"{BASE_URL}{API_PREFIX}/info")
        assert response.status_code == 200
        data = response.json()
        assert "endpoints" in data
        assert "features" in data
   
    def test_chat_flow(self, session_id, user_id):
        """Test complete chat flow."""
        # Send message
        payload = {
            "session_id": session_id,
            "user_id": user_id,
            "message": "Where is my order?"
        }
       
        response = requests.post(
            f"{BASE_URL}{API_PREFIX}/chat/message",
            json=payload
        )
       
        assert response.status_code == 200
        data = response.json()
       
        # Verify response structure
        assert "message" in data
        assert "confidence" in data
        assert "intent" in data
        assert "requires_escalation" in data
       
        # Verify confidence is valid
        assert 0 <= data["confidence"] <= 1
       
        # Verify intent is classified
        assert data["intent"] in [
            "order_status", "payment_issue", "refund_request",
            "delivery_problem", "cancellation", "quality_complaint",
            "general_faq", "out_of_scope"
        ]
   
    def test_conversation_history(self, session_id, user_id):
        """Test conversation history retrieval."""
        # Send a message first
        payload = {
            "session_id": session_id,
            "user_id": user_id,
            "message": "Test message"
        }
        requests.post(f"{BASE_URL}{API_PREFIX}/chat/message", json=payload)
       
        # Get history
        response = requests.get(
            f"{BASE_URL}{API_PREFIX}/chat/history/{session_id}"
        )
       
        assert response.status_code == 200
        data = response.json()
       
        assert "messages" in data
        assert "total_messages" in data
        assert len(data["messages"]) > 0
   
    def test_order_retrieval(self):
        """Test order retrieval."""
        # Get order (will return mock data if not found)
        response = requests.get(
            f"{BASE_URL}{API_PREFIX}/orders/ORD000001"
        )
       
        assert response.status_code == 200
        data = response.json()
       
        assert "order_id" in data
        assert "status" in data
        assert "items" in data
   
    def test_user_orders(self, user_id):
        """Test user orders retrieval."""
        response = requests.get(
            f"{BASE_URL}{API_PREFIX}/orders/user/{user_id}"
        )
       
        assert response.status_code == 200
        data = response.json()
       
        assert "orders" in data
        assert "total" in data
   
    def test_ticket_creation(self, user_id):
        """Test ticket creation."""
        payload = {
            "user_id": user_id,
            "category": "delivery_issue",
            "priority": "high",
            "description": "Integration test ticket",
            "conversation_history": [
                {
                    "role": "user",
                    "message": "Test message",
                    "timestamp": datetime.utcnow().isoformat()
                }
            ]
        }
       
        response = requests.post(
            f"{BASE_URL}{API_PREFIX}/tickets/create",
            json=payload
        )
       
        assert response.status_code == 201
        data = response.json()
       
        assert "ticket_id" in data
        assert "status" in data
        assert data["status"] == "open"
   
    def test_rag_stats(self):
        """Test RAG statistics."""
        response = requests.get(
            f"{BASE_URL}{API_PREFIX}/rag/stats"
        )
       
        assert response.status_code == 200
        data = response.json()
       
        assert "success" in data
        assert "stats" in data
   
    def test_out_of_scope_detection(self, session_id, user_id):
        """Test out-of-scope query detection."""
        payload = {
            "session_id": session_id,
            "user_id": user_id,
            "message": "What's the weather today?"
        }
       
        response = requests.post(
            f"{BASE_URL}{API_PREFIX}/chat/message",
            json=payload
        )
       
        assert response.status_code == 200
        data = response.json()
       
        # Should detect as out of scope
        assert data["intent"] == "out_of_scope"
   
    def test_escalation_trigger(self, session_id, user_id):
        """Test escalation triggering."""
        payload = {
            "session_id": session_id,
            "user_id": user_id,
            "message": "I received a damaged product"
        }
       
        response = requests.post(
            f"{BASE_URL}{API_PREFIX}/chat/message",
            json=payload
        )
       
        assert response.status_code == 200
        data = response.json()
       
        # Quality complaints should trigger escalation
        assert data["intent"] == "quality_complaint"
        # May or may not require escalation based on confidence
   
    def test_session_clearing(self, session_id):
        """Test session clearing."""
        response = requests.delete(
            f"{BASE_URL}{API_PREFIX}/chat/session/{session_id}"
        )
       
        assert response.status_code == 200
        data = response.json()
       
        assert data["success"] == True
 
 
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
 
 