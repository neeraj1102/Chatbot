"""
Generate Embeddings Script
Creates vector embeddings for the knowledge base.
"""
 
import sys
from pathlib import Path
 
# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / "backend"))
 
from app.services.rag_service import RAGService
from app.core.vector_store import get_vector_store
 
 
def main():
    """Generate embeddings for knowledge base."""
    print("=" * 60)
    print("Generate Embeddings for Knowledge Base")
    print("=" * 60)
   
    try:
        # Initialize RAG service
        print("\nInitializing RAG service...")
        rag_service = RAGService()
       
        # Get vector store
        vector_store = get_vector_store()
       
        # Check if embeddings already exist
        existing_count = vector_store.get_collection_count()
        if existing_count > 0:
            print(f"\n⚠️  Found {existing_count} existing documents in vector store.")
            response = input("Do you want to clear and regenerate? (y/n): ")
            if response.lower() == 'y':
                print("Clearing existing embeddings...")
                vector_store.clear_collection()
            else:
                print("Keeping existing embeddings.")
                return
       
        # Load knowledge base
        print("\nLoading knowledge base files...")
        counts = rag_service.load_knowledge_base()
       
        if "error" in counts:
            print(f"\n✗ Error loading knowledge base: {counts['error']}")
            return
       
        # Print results
        print("\n" + "=" * 60)
        print("✓ Embeddings generated successfully!")
        print("=" * 60)
       
        print("\nDocuments loaded:")
        print(f"  FAQs: {counts['faqs']}")
        print(f"  Policies: {counts['policies']}")
        print(f"  Troubleshooting: {counts['troubleshooting']}")
        print(f"  Total: {sum(counts.values())}")
       
        # Get stats
        stats = rag_service.get_knowledge_base_stats()
        print("\nVector Store Stats:")
        print(f"  Collection: {stats['collection_name']}")
        print(f"  Total documents: {stats['total_documents']}")
        print(f"  Embedding model: {stats['embedding_model']}")
        print(f"  Top K: {stats['top_k']}")
        print(f"  Similarity threshold: {stats['similarity_threshold']}")
       
        print("\n" + "=" * 60)
        print("✓ Knowledge base is ready for RAG!")
        print("=" * 60)
   
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()
 
 
if __name__ == "__main__":
    main()
 
 