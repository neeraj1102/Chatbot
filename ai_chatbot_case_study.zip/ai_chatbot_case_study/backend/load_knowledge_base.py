#!/usr/bin/env python3
"""Fix quality complaint detection"""
 
# First, let's update the system prompt to better detect quality issues
import os
from pathlib import Path
 
# Read current system prompt
prompt_path = Path('prompts/system_prompt.txt')
if prompt_path.exists():
    with open(prompt_path, 'r', encoding='utf-8') as f:
        system_prompt = f.read()
   
    # Add quality detection guidance
    if 'quality_complaint' not in system_prompt:
        enhanced_prompt = system_prompt + """
 
IMPORTANT INTENT CLASSIFICATION RULES:
- If user mentions food being cold, wrong items, damaged, bad quality → classify as "quality_complaint"
- If user wants refund or money back → classify as "refund_request"  
- If user mentions delivery delay, late, or delivery partner issues → classify as "delivery_problem"
- Always escalate quality_complaint and refund_request intents
"""
       
        with open(prompt_path, 'w', encoding='utf-8') as f:
            f.write(enhanced_prompt)
       
        print("✓ Updated system prompt with quality detection rules")
    else:
        print("✓ System prompt already has quality detection")
else:
    print("⚠ System prompt file not found")
 
# Now update the chatbot service to force quality_complaint detection
with open('app/services/chatbot_service.py', 'r', encoding='utf-8') as f:
    content = f.read()
 
# Add quality keyword detection before LLM call
old_generate = """            # 10. Generate response using LLM
            response_text, confidence, intent = await self._generate_response(
                message=request.message,
                context=context,
                intent_hint=guardrail_results["intent"]
            )"""
 
new_generate = """            # 10. Generate response using LLM
            response_text, confidence, intent = await self._generate_response(
                message=request.message,
                context=context,
                intent_hint=guardrail_results["intent"]
            )
           
            # Force quality_complaint detection for quality keywords
            quality_keywords = ['cold', 'wrong', 'damaged', 'bad', 'quality', 'incorrect', 'missing']
            if any(kw in request.message.lower() for kw in quality_keywords):
                if 'food' in request.message.lower() or 'order' in request.message.lower() or 'item' in request.message.lower():
                    intent = "quality_complaint"
                    logger.info(f"Forced intent to quality_complaint based on keywords")"""
 
if old_generate in content:
    content = content.replace(old_generate, new_generate)
   
    with open('app/services/chatbot_service.py', 'w', encoding='utf-8') as f:
        f.write(content)
   
    print("✓ Added quality keyword detection to chatbot service")
else:
    print("⚠ Could not find generate response section")
 
print("\n" + "=" * 70)
print("Quality complaint detection enhanced!")
print("=" * 70)
print("\nNow test with: 'my food is cold'")
print("Expected: intent=quality_complaint, requires_escalation=true")
 
 