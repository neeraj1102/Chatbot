"""
Database Seeding Script
Seeds the database with sample data for testing
"""
 
import sys
from pathlib import Path
 
# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / "backend"))
 
from app.database.session import SessionLocal, init_db
from app.database.models import User, Order, Ticket, Conversation, ConversationSession
from datetime import datetime, timedelta
import random
 
 
def seed_users(db):
    """Seed sample users."""
    print("Seeding users...")
   
    users = [
        User(user_id="USER001", name="John Doe", email="john.doe@example.com", phone="+1234567890"),
        User(user_id="USER002", name="Jane Smith", email="jane.smith@example.com", phone="+1234567891"),
        User(user_id="USER003", name="Bob Johnson", email="bob.johnson@example.com", phone="+1234567892"),
        User(user_id="USER004", name="Alice Williams", email="alice.williams@example.com", phone="+1234567893"),
        User(user_id="USER005", name="Charlie Brown", email="charlie.brown@example.com", phone="+1234567894"),
    ]
   
    for user in users:
        existing = db.query(User).filter(User.user_id == user.user_id).first()
        if not existing:
            db.add(user)
   
    db.commit()
    print(f"✓ Seeded {len(users)} users")
 
 
def seed_orders(db):
    """Seed sample orders."""
    print("Seeding orders...")
   
    statuses = ["pending", "confirmed", "preparing", "out_for_delivery", "delivered", "cancelled"]
    user_ids = ["USER001", "USER002", "USER003", "USER004", "USER005"]
   
    orders = []
    for i in range(1, 21):  # 20 orders
        user_id = random.choice(user_ids)
        status = random.choice(statuses)
       
        # Create order items
        items = [
            {
                "item_id": f"ITEM{random.randint(1, 10):03d}",
                "name": random.choice(["Pizza", "Burger", "Pasta", "Salad", "Sandwich"]),
                "quantity": random.randint(1, 3),
                "price": round(random.uniform(5.99, 19.99), 2)
            }
            for _ in range(random.randint(1, 3))
        ]
       
        total_amount = sum(item["price"] * item["quantity"] for item in items)
       
        created_at = datetime.utcnow() - timedelta(days=random.randint(0, 30))
       
        if status in ["out_for_delivery", "preparing"]:
            estimated_delivery = datetime.utcnow() + timedelta(minutes=random.randint(15, 60))
        elif status in ["pending", "confirmed"]:
            estimated_delivery = datetime.utcnow() + timedelta(minutes=random.randint(30, 90))
        else:
            estimated_delivery = created_at + timedelta(minutes=45)
       
        order = Order(
            order_id=f"ORD{i:06d}",
            user_id=user_id,
            status=status,
            items=items,
            total_amount=total_amount,
            delivery_address=f"{random.randint(100, 999)} Main St, Apt {random.randint(1, 20)}, City, State",
            estimated_delivery=estimated_delivery,
            created_at=created_at,
            updated_at=created_at + timedelta(minutes=5)
        )
       
        existing = db.query(Order).filter(Order.order_id == order.order_id).first()
        if not existing:
            orders.append(order)
            db.add(order)
   
    db.commit()
    print(f"✓ Seeded {len(orders)} orders")
 
 
def seed_tickets(db):
    """Seed sample tickets."""
    print("Seeding tickets...")
   
    categories = ["delivery_issue", "payment_issue", "quality_issue", "refund_request", "other"]
    priorities = ["low", "medium", "high"]
    statuses = ["open", "in_progress", "resolved", "closed"]
    user_ids = ["USER001", "USER002", "USER003", "USER004", "USER005"]
   
    tickets = []
    for i in range(1, 11):  # 10 tickets
        user_id = random.choice(user_ids)
        category = random.choice(categories)
        priority = random.choice(priorities)
        status = random.choice(statuses)
       
        # Get a random order for this user
        user_orders = db.query(Order).filter(Order.user_id == user_id).all()
        order_id = user_orders[0].order_id if user_orders else None
       
        descriptions = {
            "delivery_issue": "My order is delayed and the delivery partner is not responding.",
            "payment_issue": "Payment was deducted but order was not placed.",
            "quality_issue": "Received wrong item in my order.",
            "refund_request": "I want to request a refund for my cancelled order.",
            "other": "I have a general query about my account."
        }
       
        created_at = datetime.utcnow() - timedelta(days=random.randint(0, 15))
        resolved_at = created_at + timedelta(hours=random.randint(1, 48)) if status in ["resolved", "closed"] else None
       
        ticket = Ticket(
            ticket_id=f"TKT{i:06d}",
            user_id=user_id,
            order_id=order_id,
            category=category,
            priority=priority,
            description=descriptions.get(category, "General issue"),
            conversation_history=[],
            status=status,
            created_at=created_at,
            resolved_at=resolved_at
        )
       
        existing = db.query(Ticket).filter(Ticket.ticket_id == ticket.ticket_id).first()
        if not existing:
            tickets.append(ticket)
            db.add(ticket)
   
    db.commit()
    print(f"✓ Seeded {len(tickets)} tickets")
 
 
def seed_conversations(db):
    """Seed sample conversations."""
    print("Seeding conversations...")
   
    user_ids = ["USER001", "USER002", "USER003"]
   
    conversations = []
    for i, user_id in enumerate(user_ids):
        session_id = f"session-{i+1:03d}-test"
       
        # Create session
        session = ConversationSession(
            session_id=session_id,
            user_id=user_id,
            clarification_count=0,
            current_intent="order_status",
            is_active=True,
            created_at=datetime.utcnow() - timedelta(minutes=10),
            updated_at=datetime.utcnow(),
            metadata={}
        )
       
        existing_session = db.query(ConversationSession).filter(
            ConversationSession.session_id == session_id
        ).first()
       
        if not existing_session:
            db.add(session)
       
        # Create conversation messages
        messages = [
            ("user", "Where is my order?"),
            ("assistant", "Let me check your order status for you."),
            ("user", "It's been delayed for 2 hours"),
            ("assistant", "I apologize for the delay. Your order is currently out for delivery and should arrive within 15 minutes."),
        ]
       
        for j, (role, message) in enumerate(messages):
            conv = Conversation(
                session_id=session_id,
                user_id=user_id,
                message=message,
                role=role,
                intent="order_status" if role == "user" else None,
                confidence=0.9 if role == "assistant" else None,
                metadata={},
                timestamp=datetime.utcnow() - timedelta(minutes=10-j)
            )
            conversations.append(conv)
            db.add(conv)
   
    db.commit()
    print(f"✓ Seeded {len(conversations)} conversation messages")
 
 
def main():
    """Main seeding function."""
    print("=" * 60)
    print("Database Seeding")
    print("=" * 60)
   
    # Initialize database
    print("\nInitializing database...")
    init_db()
    print("✓ Database initialized")
   
    # Create session
    db = SessionLocal()
   
    try:
        # Seed data
        seed_users(db)
        seed_orders(db)
        seed_tickets(db)
        seed_conversations(db)
       
        print("\n" + "=" * 60)
        print("✓ Database seeding completed successfully!")
        print("=" * 60)
       
        # Print summary
        print("\nSummary:")
        print(f"  Users: {db.query(User).count()}")
        print(f"  Orders: {db.query(Order).count()}")
        print(f"  Tickets: {db.query(Ticket).count()}")
        print(f"  Conversations: {db.query(Conversation).count()}")
        print(f"  Sessions: {db.query(ConversationSession).count()}")
       
    except Exception as e:
        print(f"\n✗ Error seeding database: {e}")
        db.rollback()
    finally:
        db.close()
 
 
if __name__ == "__main__":
    main()
 
 