"""
Frontend Configuration
"""
 
# API Configuration
BACKEND_URL = "http://localhost:8000"
API_PREFIX = "/api/v1"
 
# UI Configuration
APP_TITLE = "AI Support Chat"
APP_ICON = "🤖"
 
# Chat Configuration
MAX_MESSAGE_LENGTH = 1000
DEFAULT_USER_ID = "demo_user"
 
# Display Configuration
ORDERS_PER_PAGE = 10
TICKETS_PER_PAGE = 10
MESSAGES_TO_DISPLAY = 50
 
 