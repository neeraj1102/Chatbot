"""
Session Manager
Manages Streamlit session state
"""
 
import streamlit as st
import uuid
from datetime import datetime
 
 
class SessionManager:
    """Manages user session state."""
   
    @staticmethod
    def initialize():
        """Initialize session state variables."""
        # User info
        if 'user_id' not in st.session_state:
            st.session_state.user_id = "demo_user"
       
        # Chat session
        if 'session_id' not in st.session_state:
            st.session_state.session_id = str(uuid.uuid4())
       
        # Messages
        if 'messages' not in st.session_state:
            st.session_state.messages = []
       
        # Current order
        if 'current_order_id' not in st.session_state:
            st.session_state.current_order_id = None
       
        # Ticket form
        if 'show_ticket_form' not in st.session_state:
            st.session_state.show_ticket_form = False
       
        # API status
        if 'api_connected' not in st.session_state:
            st.session_state.api_connected = False
       
        # RAG status
        if 'rag_loaded' not in st.session_state:
            st.session_state.rag_loaded = False
   
    @staticmethod
    def get_user_id() -> str:
        """Get current user ID."""
        return st.session_state.get('user_id', 'demo_user')
   
    @staticmethod
    def set_user_id(user_id: str):
        """Set user ID."""
        st.session_state.user_id = user_id
   
    @staticmethod
    def get_session_id() -> str:
        """Get current session ID."""
        return st.session_state.get('session_id', str(uuid.uuid4()))
   
    @staticmethod
    def reset_session():
        """Reset chat session."""
        st.session_state.session_id = str(uuid.uuid4())
        st.session_state.messages = []
        st.session_state.current_order_id = None
        st.session_state.show_ticket_form = False
   
    @staticmethod
    def add_message(role: str, content: str, metadata: dict = None):
        """Add a message to chat history."""
        message = {
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "metadata": metadata or {}
        }
        st.session_state.messages.append(message)
   
    @staticmethod
    def get_messages() -> list:
        """Get all messages."""
        return st.session_state.get('messages', [])
   
    @staticmethod
    def clear_messages():
        """Clear all messages."""
        st.session_state.messages = []
   
    @staticmethod
    def set_current_order(order_id: str):
        """Set current order ID."""
        st.session_state.current_order_id = order_id
   
    @staticmethod
    def get_current_order() -> str:
        """Get current order ID."""
        return st.session_state.get('current_order_id')
   
    @staticmethod
    def show_ticket_form():
        """Show ticket creation form."""
        st.session_state.show_ticket_form = True
   
    @staticmethod
    def hide_ticket_form():
        """Hide ticket creation form."""
        st.session_state.show_ticket_form = False
   
    @staticmethod
    def is_ticket_form_visible() -> bool:
        """Check if ticket form is visible."""
        return st.session_state.get('show_ticket_form', False)
   
    @staticmethod
    def set_api_status(connected: bool):
        """Set API connection status."""
        st.session_state.api_connected = connected
   
    @staticmethod
    def is_api_connected() -> bool:
        """Check if API is connected."""
        return st.session_state.get('api_connected', False)
   
    @staticmethod
    def set_rag_status(loaded: bool):
        """Set RAG loaded status."""
        st.session_state.rag_loaded = loaded
   
    @staticmethod
    def is_rag_loaded() -> bool:
        """Check if RAG is loaded."""
        return st.session_state.get('rag_loaded', False)
 
 