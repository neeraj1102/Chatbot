"""
API Client
Handles all communication with the backend API
"""
 
import requests
from typing import Dict, Any, List, Optional
import streamlit as st
 
 
class APIClient:
    """Client for backend API communication."""
   
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.api_prefix = "/api/v1"
   
    def _get_url(self, endpoint: str) -> str:
        """Build full URL for endpoint."""
        return f"{self.base_url}{self.api_prefix}{endpoint}"
   
    def _handle_response(self, response: requests.Response) -> Dict[str, Any]:
        """Handle API response."""
        try:
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            st.error(f"API Error: {e}")
            return {"error": str(e)}
        except Exception as e:
            st.error(f"Error: {e}")
            return {"error": str(e)}
   
    # Chat endpoints
    def send_message(
        self,
        session_id: str,
        user_id: str,
        message: str,
        order_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Send a chat message."""
        try:
            payload = {
                "session_id": session_id,
                "user_id": user_id,
                "message": message
            }
            if order_id:
                payload["order_id"] = order_id
           
            response = requests.post(
                self._get_url("/chat/message"),
                json=payload,
                timeout=30
            )
            return self._handle_response(response)
        except Exception as e:
            return {"error": str(e)}
   
    def get_conversation_history(
        self,
        session_id: str,
        limit: int = 50
    ) -> Dict[str, Any]:
        """Get conversation history."""
        try:
            response = requests.get(
                self._get_url(f"/chat/history/{session_id}"),
                params={"limit": limit},
                timeout=10
            )
            return self._handle_response(response)
        except Exception as e:
            return {"error": str(e)}
   
    def clear_session(self, session_id: str) -> Dict[str, Any]:
        """Clear a chat session."""
        try:
            response = requests.delete(
                self._get_url(f"/chat/session/{session_id}"),
                timeout=10
            )
            return self._handle_response(response)
        except Exception as e:
            return {"error": str(e)}
   
    # Order endpoints
    def get_order(self, order_id: str) -> Dict[str, Any]:
        """Get order details."""
        try:
            response = requests.get(
                self._get_url(f"/orders/{order_id}"),
                timeout=10
            )
            return self._handle_response(response)
        except Exception as e:
            return {"error": str(e)}
   
    def get_user_orders(
        self,
        user_id: str,
        status: Optional[str] = None,
        limit: int = 10
    ) -> Dict[str, Any]:
        """Get user's orders."""
        try:
            params = {"limit": limit}
            if status:
                params["status"] = status
           
            response = requests.get(
                self._get_url(f"/orders/user/{user_id}"),
                params=params,
                timeout=10
            )
            return self._handle_response(response)
        except Exception as e:
            return {"error": str(e)}
   
    # Ticket endpoints
    def create_ticket(
        self,
        user_id: str,
        category: str,
        priority: str,
        description: str,
        order_id: Optional[str] = None,
        conversation_history: Optional[List[Dict]] = None
    ) -> Dict[str, Any]:
        """Create a support ticket."""
        try:
            payload = {
                "user_id": user_id,
                "category": category,
                "priority": priority,
                "description": description
            }
            if order_id:
                payload["order_id"] = order_id
            if conversation_history:
                payload["conversation_history"] = conversation_history
           
            response = requests.post(
                self._get_url("/tickets/create"),
                json=payload,
                timeout=10
            )
            return self._handle_response(response)
        except Exception as e:
            return {"error": str(e)}
   
    def get_ticket(self, ticket_id: str) -> Dict[str, Any]:
        """Get ticket details."""
        try:
            response = requests.get(
                self._get_url(f"/tickets/{ticket_id}"),
                timeout=10
            )
            return self._handle_response(response)
        except Exception as e:
            return {"error": str(e)}
   
    def get_user_tickets(
        self,
        user_id: str,
        limit: int = 10
    ) -> Dict[str, Any]:
        """Get user's tickets."""
        try:
            response = requests.get(
                self._get_url(f"/tickets/user/{user_id}"),
                params={"limit": limit},
                timeout=10
            )
            return self._handle_response(response)
        except Exception as e:
            return {"error": str(e)}
   
    # RAG endpoints
    def load_knowledge_base(self) -> Dict[str, Any]:
        """Load knowledge base embeddings."""
        try:
            response = requests.post(
                self._get_url("/rag/load-knowledge-base"),
                timeout=60
            )
            return self._handle_response(response)
        except Exception as e:
            return {"error": str(e)}
   
    def get_rag_stats(self) -> Dict[str, Any]:
        """Get RAG statistics."""
        try:
            response = requests.get(
                self._get_url("/rag/stats"),
                timeout=10
            )
            return self._handle_response(response)
        except Exception as e:
            return {"error": str(e)}
   
    # Health check
    def health_check(self) -> Dict[str, Any]:
        """Check API health."""
        try:
            response = requests.get(
                f"{self.base_url}/health",
                timeout=5
            )
            return self._handle_response(response)
        except Exception as e:
            return {"error": str(e), "status": "unhealthy"}
 
 
# Global API client instance
_api_client = None
 
 
def get_api_client(base_url: str = "http://localhost:8000") -> APIClient:
    """Get or create API client instance."""
    global _api_client
    if _api_client is None:
        _api_client = APIClient(base_url)
    return _api_client
 
 