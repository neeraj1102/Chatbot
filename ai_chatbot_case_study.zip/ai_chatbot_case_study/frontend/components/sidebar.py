"""
Sidebar Component
Common sidebar for all pages
"""
 
import streamlit as st
from services.api_client import get_api_client
from services.session_manager import SessionManager
 
 
def render_sidebar():
    """Render common sidebar."""
    with st.sidebar:
        st.title("🤖 AI Support")
        st.caption("Powered by GPT-4 & RAG")
       
        st.markdown("---")
       
        # User info
        st.subheader("👤 User Info")
        user_id = st.text_input(
            "User ID",
            value=SessionManager.get_user_id(),
            key="sidebar_user_id"
        )
        if user_id != SessionManager.get_user_id():
            SessionManager.set_user_id(user_id)
       
        st.markdown("---")
       
        # API Status
        st.subheader("🔌 Connection Status")
       
        api_client = get_api_client()
       
        if st.button("🔄 Check Connection", use_container_width=True):
            with st.spinner("Checking..."):
                health = api_client.health_check()
                if health.get('status') == 'healthy':
                    SessionManager.set_api_status(True)
                    st.success("✅ API Connected")
                else:
                    SessionManager.set_api_status(False)
                    st.error("❌ API Disconnected")
       
        if SessionManager.is_api_connected():
            st.success("✅ API Connected")
        else:
            st.warning("⚠️ API Status Unknown")
       
        st.markdown("---")
       
        # Quick Actions
        st.subheader("⚡ Quick Actions")
       
        if st.button("💬 New Chat", use_container_width=True):
            SessionManager.reset_session()
            st.switch_page("app.py")
       
        if st.button("📦 My Orders", use_container_width=True):
            st.switch_page("pages/2_Order_Tracking.py")
       
        if st.button("🎫 My Tickets", use_container_width=True):
            st.switch_page("pages/3_Ticket_History.py")
       
        st.markdown("---")
       
        # About
        with st.expander("ℹ️ About"):
            st.caption("""
            **AI Support Chatbot**
           
            This chatbot uses:
            - GPT-4 for natural language understanding
            - RAG for accurate, grounded responses
            - Advanced guardrails for safety
            - Confidence-based escalation
           
            **Features:**
            - Order status tracking
            - Payment & refund support
            - Delivery assistance
            - Quality complaints
            - 24/7 availability
            """)
 
 