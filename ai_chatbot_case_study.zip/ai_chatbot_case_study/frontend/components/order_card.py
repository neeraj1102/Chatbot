"""
Order Card Component
Displays order information
"""
 
import streamlit as st
from utils.formatters import (
    format_order_status,
    format_currency,
    format_datetime
)
 
 
def render_order_card(order: dict, show_details: bool = True):
    """Render an order card."""
    with st.container():
        # Header
        col1, col2, col3 = st.columns([2, 2, 1])
       
        with col1:
            st.subheader(f"📦 {order.get('order_id', 'N/A')}")
       
        with col2:
            st.markdown(f"**{format_order_status(order.get('status', 'unknown'))}**")
       
        with col3:
            st.markdown(f"**{format_currency(order.get('total_amount', 0))}**")
       
        # Details
        if show_details:
            with st.expander("📋 Order Details", expanded=False):
                # Items
                items = order.get('items', [])
                if items:
                    st.caption("**Items:**")
                    for item in items:
                        st.write(f"- {item.get('name')} x{item.get('quantity')} - {format_currency(item.get('price', 0))}")
               
                # Delivery info
                st.caption(f"**Delivery Address:** {order.get('delivery_address', 'N/A')}")
               
                if order.get('estimated_delivery'):
                    st.caption(f"**Estimated Delivery:** {format_datetime(order['estimated_delivery'])}")
               
                # Timestamps
                if order.get('created_at'):
                    st.caption(f"**Ordered:** {format_datetime(order['created_at'])}")
       
        st.markdown("---")
 
 
def render_order_list(orders: list):
    """Render a list of orders."""
    if not orders:
        st.info("No orders found.")
        return
   
    for order in orders:
        render_order_card(order, show_details=True)
 
 