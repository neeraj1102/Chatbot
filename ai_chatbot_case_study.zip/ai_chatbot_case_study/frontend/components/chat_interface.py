"""
Chat Interface Component
Main chat UI component
"""
 
import streamlit as st
from services.api_client import get_api_client
from services.session_manager import SessionManager
from utils.formatters import format_confidence, format_intent, format_datetime
 
 
def render_chat_message(message: dict):
    """Render a single chat message."""
    role = message.get('role', 'user')
    content = message.get('content', '')
    metadata = message.get('metadata', {})
   
    # User message
    if role == 'user':
        with st.chat_message("user", avatar="👤"):
            st.write(content)
   
    # Assistant message
    elif role == 'assistant':
        with st.chat_message("assistant", avatar="🤖"):
            st.write(content)
           
            # Show metadata if available
            if metadata:
                with st.expander("ℹ️ Response Details", expanded=False):
                    col1, col2 = st.columns(2)
                   
                    with col1:
                        if 'confidence' in metadata:
                            st.caption(f"**Confidence:** {format_confidence(metadata['confidence'])}")
                        if 'intent' in metadata:
                            st.caption(f"**Intent:** {format_intent(metadata['intent'])}")
                   
                    with col2:
                        if 'requires_escalation' in metadata:
                            if metadata['requires_escalation']:
                                st.caption("⚠️ **Escalation Suggested**")
                        if 'rag_enabled' in metadata and metadata['rag_enabled']:
                            st.caption("✅ **RAG Enabled**")
 
 
def render_suggested_actions(actions: list):
    """Render suggested action buttons."""
    if not actions:
        return
   
    st.caption("**Suggested Actions:**")
    cols = st.columns(len(actions))
   
    action_labels = {
        "track_order": "📦 Track Order",
        "cancel_order": "❌ Cancel Order",
        "raise_ticket": "🎫 Create Ticket",
        "create_ticket": "🎫 Create Ticket",
        "view_refund_policy": "💰 Refund Policy",
        "view_quality_policy": "⚠️ Quality Policy",
        "contact_delivery_partner": "📞 Contact Delivery"
    }
   
    for i, action in enumerate(actions):
        with cols[i]:
            label = action_labels.get(action, action.replace('_', ' ').title())
            if st.button(label, key=f"action_{action}_{i}", use_container_width=True):
                if action in ["raise_ticket", "create_ticket"]:
                    SessionManager.show_ticket_form()
                    st.rerun()
 
 
def render_order_context(order_context: dict):
    """Render order context card."""
    if not order_context:
        return
   
    with st.container():
        st.markdown("---")
        st.subheader("📦 Order Context")
       
        col1, col2, col3 = st.columns(3)
       
        with col1:
            st.metric("Order ID", order_context.get('order_id', 'N/A'))
       
        with col2:
            status = order_context.get('status', 'unknown')
            st.metric("Status", status.replace('_', ' ').title())
       
        with col3:
            amount = order_context.get('total_amount', 0)
            st.metric("Amount", f"${amount:.2f}")
       
        if order_context.get('estimated_delivery'):
            st.caption(f"**Estimated Delivery:** {format_datetime(order_context['estimated_delivery'])}")
 
 
def render_chat_interface():
    """Render the main chat interface."""
    st.title("💬 AI Support Chat")
    st.caption("Ask me anything about your orders, delivery, payments, or refunds!")
   
    # Initialize session
    SessionManager.initialize()
    api_client = get_api_client()
   
    # Check API connection
    if not SessionManager.is_api_connected():
        with st.spinner("Connecting to API..."):
            health = api_client.health_check()
            if health.get('status') == 'healthy':
                SessionManager.set_api_status(True)
                st.success("✅ Connected to API")
            else:
                st.error("❌ Cannot connect to API. Please ensure the backend is running.")
                st.stop()
   
    # Sidebar
    with st.sidebar:
        st.header("Chat Settings")
       
        # User ID
        user_id = st.text_input(
            "User ID",
            value=SessionManager.get_user_id(),
            help="Enter your user ID"
        )
        if user_id != SessionManager.get_user_id():
            SessionManager.set_user_id(user_id)
       
        # Session info
        st.caption(f"**Session ID:** {SessionManager.get_session_id()[:8]}...")
       
        # Clear chat button
        if st.button("🗑️ Clear Chat", use_container_width=True):
            SessionManager.reset_session()
            st.rerun()
       
        # RAG status
        st.markdown("---")
        st.subheader("RAG Status")
       
        if not SessionManager.is_rag_loaded():
            if st.button("📚 Load Knowledge Base", use_container_width=True):
                with st.spinner("Loading knowledge base..."):
                    result = api_client.load_knowledge_base()
                    if result.get('success'):
                        SessionManager.set_rag_status(True)
                        st.success("✅ Knowledge base loaded!")
                        st.rerun()
                    else:
                        st.error(f"❌ Error: {result.get('message', 'Unknown error')}")
        else:
            st.success("✅ Knowledge base loaded")
           
            # Show RAG stats
            with st.expander("📊 RAG Statistics"):
                stats = api_client.get_rag_stats()
                if stats.get('success'):
                    rag_stats = stats.get('stats', {})
                    st.metric("Total Documents", rag_stats.get('total_documents', 0))
                    st.caption(f"**Model:** {rag_stats.get('embedding_model', 'N/A')}")
                    st.caption(f"**Top K:** {rag_stats.get('top_k', 'N/A')}")
   
    # Display chat messages
    for message in SessionManager.get_messages():
        render_chat_message(message)
   
    # Chat input
    if prompt := st.chat_input("Type your message here..."):
        # Add user message
        SessionManager.add_message("user", prompt)
       
        # Display user message
        with st.chat_message("user", avatar="👤"):
            st.write(prompt)
       
        # Get AI response
        with st.chat_message("assistant", avatar="🤖"):
            with st.spinner("Thinking..."):
                response = api_client.send_message(
                    session_id=SessionManager.get_session_id(),
                    user_id=SessionManager.get_user_id(),
                    message=prompt,
                    order_id=SessionManager.get_current_order()
                )
               
                if 'error' in response:
                    st.error(f"Error: {response['error']}")
                else:
                    # Display response
                    ai_message = response.get('message', 'Sorry, I could not generate a response.')
                    st.write(ai_message)
                   
                    # Add to session
                    SessionManager.add_message("assistant", ai_message, {
                        'confidence': response.get('confidence'),
                        'intent': response.get('intent'),
                        'requires_escalation': response.get('requires_escalation'),
                        'rag_enabled': response.get('metadata', {}).get('rag_enabled', False)
                    })
                   
                    # Show metadata
                    with st.expander("ℹ️ Response Details", expanded=False):
                        col1, col2 = st.columns(2)
                       
                        with col1:
                            st.caption(f"**Confidence:** {format_confidence(response.get('confidence', 0))}")
                            st.caption(f"**Intent:** {format_intent(response.get('intent', 'unknown'))}")
                       
                        with col2:
                            if response.get('requires_escalation'):
                                st.caption("⚠️ **Escalation Suggested**")
                            if response.get('metadata', {}).get('rag_enabled'):
                                st.caption("✅ **RAG Enabled**")
                   
                    # Show suggested actions
                    suggested_actions = response.get('suggested_actions', [])
                    if suggested_actions:
                        render_suggested_actions(suggested_actions)
                   
                    # Show order context
                    order_context = response.get('order_context')
                    if order_context:
                        render_order_context(order_context)
       
        # Rerun to update chat
        st.rerun()
 
 