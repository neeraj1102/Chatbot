"""
Ticket Form Component
Form for creating support tickets
"""
 
import streamlit as st
from services.api_client import get_api_client
from services.session_manager import SessionManager
 
 
def render_ticket_form():
    """Render ticket creation form."""
    st.subheader("🎫 Create Support Ticket")
   
    api_client = get_api_client()
   
    with st.form("ticket_form"):
        # Category
        category = st.selectbox(
            "Category",
            options=[
                "delivery_issue",
                "payment_issue",
                "quality_issue",
                "refund_request",
                "other"
            ],
            format_func=lambda x: x.replace('_', ' ').title()
        )
       
        # Priority
        priority = st.selectbox(
            "Priority",
            options=["low", "medium", "high"],
            index=1,
            format_func=lambda x: x.title()
        )
       
        # Order ID (optional)
        order_id = st.text_input(
            "Order ID (optional)",
            value=SessionManager.get_current_order() or "",
            help="Enter the order ID related to this issue"
        )
       
        # Description
        description = st.text_area(
            "Description",
            placeholder="Please describe your issue in detail...",
            height=150,
            max_chars=2000
        )
       
        # Submit button
        col1, col2 = st.columns([1, 1])
       
        with col1:
            submitted = st.form_submit_button(
                "Submit Ticket",
                use_container_width=True,
                type="primary"
            )
       
        with col2:
            cancelled = st.form_submit_button(
                "Cancel",
                use_container_width=True
            )
       
        if cancelled:
            SessionManager.hide_ticket_form()
            st.rerun()
       
        if submitted:
            if not description or len(description.strip()) < 10:
                st.error("Please provide a detailed description (at least 10 characters)")
            else:
                with st.spinner("Creating ticket..."):
                    # Get conversation history
                    messages = SessionManager.get_messages()
                    conversation_history = [
                        {
                            "role": msg['role'],
                            "message": msg['content'],
                            "timestamp": msg['timestamp']
                        }
                        for msg in messages[-10:]  # Last 10 messages
                    ]
                   
                    # Create ticket
                    result = api_client.create_ticket(
                        user_id=SessionManager.get_user_id(),
                        category=category,
                        priority=priority,
                        description=description,
                        order_id=order_id if order_id else None,
                        conversation_history=conversation_history
                    )
                   
                    if 'error' in result:
                        st.error(f"Error creating ticket: {result['error']}")
                    else:
                        st.success(f"✅ Ticket created successfully! Ticket ID: {result.get('ticket_id')}")
                        st.info(f"Estimated response time: {result.get('estimated_response_time', 'Within 2 hours')}")
                       
                        # Hide form
                        SessionManager.hide_ticket_form()
                       
                        # Wait a bit before rerunning
                        import time
                        time.sleep(2)
                        st.rerun()
 
 