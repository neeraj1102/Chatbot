"""
Ticket History Page
View support tickets
"""
 
import streamlit as st
from components.sidebar import render_sidebar
from services.api_client import get_api_client
from services.session_manager import SessionManager
from utils.formatters import (
    format_ticket_status,
    format_priority,
    format_datetime,
    truncate_text
)
 
# Page config
st.set_page_config(
    page_title="Ticket History",
    page_icon="🎫",
    layout="wide"
)
 
# Initialize session
SessionManager.initialize()
 
# Render sidebar
render_sidebar()
 
# Main content
st.title("🎫 Support Tickets")
st.caption("View and manage your support tickets")
 
api_client = get_api_client()
 
# Filters
col1, col2 = st.columns([3, 1])
 
with col1:
    user_id = st.text_input(
        "User ID",
        value=SessionManager.get_user_id(),
        help="Enter user ID to view tickets"
    )
 
with col2:
    limit = st.number_input(
        "Limit",
        min_value=1,
        max_value=50,
        value=10,
        help="Number of tickets to display"
    )
 
# Fetch tickets button
if st.button("🔍 Fetch Tickets", type="primary", use_container_width=True):
    with st.spinner("Fetching tickets..."):
        result = api_client.get_user_tickets(
            user_id=user_id,
            limit=limit
        )
       
        if 'error' in result:
            st.error(f"Error: {result['error']}")
        else:
            tickets = result.get('tickets', [])
            total = result.get('total', 0)
           
            st.success(f"Found {total} ticket(s)")
           
            # Store in session
            st.session_state.tickets = tickets
 
# Display tickets
if 'tickets' in st.session_state:
    tickets = st.session_state.tickets
   
    if tickets:
        st.markdown("---")
       
        for ticket in tickets:
            with st.container():
                # Header
                col1, col2, col3, col4 = st.columns([2, 2, 2, 1])
               
                with col1:
                    st.subheader(f"🎫 {ticket.get('ticket_id', 'N/A')}")
               
                with col2:
                    st.markdown(f"**{format_ticket_status(ticket.get('status', 'unknown'))}**")
               
                with col3:
                    st.markdown(f"**{format_priority(ticket.get('priority', 'medium'))}**")
               
                with col4:
                    category = ticket.get('category', 'other')
                    st.caption(category.replace('_', ' ').title())
               
                # Description
                description = ticket.get('description', 'No description')
                st.write(truncate_text(description, 150))
               
                # Details expander
                with st.expander("📋 Ticket Details"):
                    st.write(f"**Full Description:**")
                    st.write(description)
                   
                    if ticket.get('order_id'):
                        st.caption(f"**Related Order:** {ticket['order_id']}")
                   
                    if ticket.get('assigned_to'):
                        st.caption(f"**Assigned To:** {ticket['assigned_to']}")
                   
                    st.caption(f"**Created:** {format_datetime(ticket.get('created_at', ''))}")
                   
                    if ticket.get('resolved_at'):
                        st.caption(f"**Resolved:** {format_datetime(ticket['resolved_at'])}")
                   
                    # Conversation history
                    conv_history = ticket.get('conversation_history', [])
                    if conv_history:
                        st.write("**Conversation History:**")
                        for msg in conv_history[:5]:  # Show first 5 messages
                            role = msg.get('role', 'user')
                            message = msg.get('message', '')
                            st.caption(f"**{role.title()}:** {truncate_text(message, 100)}")
               
                st.markdown("---")
    else:
        st.info("No tickets found.")
else:
    st.info("Click 'Fetch Tickets' to view your support tickets.")
 
# Create new ticket button
st.markdown("---")
if st.button("➕ Create New Ticket", type="primary", use_container_width=True):
    SessionManager.show_ticket_form()
    st.switch_page("app.py")
 
# Quick ticket lookup
st.markdown("---")
st.subheader("🔎 Quick Ticket Lookup")
 
col1, col2 = st.columns([3, 1])
 
with col1:
    ticket_id = st.text_input(
        "Ticket ID",
        placeholder="Enter ticket ID (e.g., TKT000001)",
        label_visibility="collapsed"
    )
 
with col2:
    if st.button("Search", use_container_width=True):
        if ticket_id:
            with st.spinner("Searching..."):
                result = api_client.get_ticket(ticket_id)
               
                if 'error' in result:
                    st.error(f"Ticket not found: {ticket_id}")
                else:
                    st.success(f"Found ticket: {ticket_id}")
                   
                    # Display ticket details
                    ticket = result
                   
                    col1, col2, col3 = st.columns(3)
                   
                    with col1:
                        st.metric("Status", format_ticket_status(ticket.get('status', 'unknown')))
                   
                    with col2:
                        st.metric("Priority", format_priority(ticket.get('priority', 'medium')))
                   
                    with col3:
                        category = ticket.get('category', 'other')
                        st.metric("Category", category.replace('_', ' ').title())
                   
                    st.write(f"**Description:**")
                    st.write(ticket.get('description', 'No description'))
                   
                    if ticket.get('order_id'):
                        st.caption(f"**Related Order:** {ticket['order_id']}")
                   
                    st.caption(f"**Created:** {format_datetime(ticket.get('created_at', ''))}")
        else:
            st.warning("Please enter a ticket ID")
 
 