"""
Order Tracking Page
View and track orders
"""
 
import streamlit as st
from components.order_card import render_order_list
from components.sidebar import render_sidebar
from services.api_client import get_api_client
from services.session_manager import SessionManager
 
# Page config
st.set_page_config(
    page_title="Order Tracking",
    page_icon="📦",
    layout="wide"
)
 
# Initialize session
SessionManager.initialize()
 
# Render sidebar
render_sidebar()
 
# Main content
st.title("📦 Order Tracking")
st.caption("View and track your orders")
 
api_client = get_api_client()
 
# Filters
col1, col2, col3 = st.columns([2, 2, 1])
 
with col1:
    user_id = st.text_input(
        "User ID",
        value=SessionManager.get_user_id(),
        help="Enter user ID to view orders"
    )
 
with col2:
    status_filter = st.selectbox(
        "Filter by Status",
        options=["all", "pending", "confirmed", "preparing", "out_for_delivery", "delivered", "cancelled"],
        format_func=lambda x: x.replace('_', ' ').title()
    )
 
with col3:
    limit = st.number_input(
        "Limit",
        min_value=1,
        max_value=50,
        value=10,
        help="Number of orders to display"
    )
 
# Fetch orders button
if st.button("🔍 Fetch Orders", type="primary", use_container_width=True):
    with st.spinner("Fetching orders..."):
        result = api_client.get_user_orders(
            user_id=user_id,
            status=None if status_filter == "all" else status_filter,
            limit=limit
        )
       
        if 'error' in result:
            st.error(f"Error: {result['error']}")
        else:
            orders = result.get('orders', [])
            total = result.get('total', 0)
           
            st.success(f"Found {total} order(s)")
           
            # Store in session
            st.session_state.orders = orders
 
# Display orders
if 'orders' in st.session_state:
    orders = st.session_state.orders
   
    if orders:
        st.markdown("---")
        render_order_list(orders)
    else:
        st.info("No orders found. Try adjusting the filters.")
else:
    st.info("Click 'Fetch Orders' to view your orders.")
 
# Quick order lookup
st.markdown("---")
st.subheader("🔎 Quick Order Lookup")
 
col1, col2 = st.columns([3, 1])
 
with col1:
    order_id = st.text_input(
        "Order ID",
        placeholder="Enter order ID (e.g., ORD000001)",
        label_visibility="collapsed"
    )
 
with col2:
    if st.button("Search", use_container_width=True):
        if order_id:
            with st.spinner("Searching..."):
                result = api_client.get_order(order_id)
               
                if 'error' in result:
                    st.error(f"Order not found: {order_id}")
                else:
                    st.success(f"Found order: {order_id}")
                    from components.order_card import render_order_card
                    render_order_card(result, show_details=True)
                   
                    # Set as current order for chat
                    SessionManager.set_current_order(order_id)
                    st.info("💡 This order is now set as context for chat. Go to Chat page to ask questions about it.")
        else:
            st.warning("Please enter an order ID")
 
 