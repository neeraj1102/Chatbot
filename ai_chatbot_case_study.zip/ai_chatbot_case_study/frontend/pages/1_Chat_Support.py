"""
Chat Support Page
Main chat interface page
"""
 
import streamlit as st
from components.chat_interface import render_chat_interface
from components.sidebar import render_sidebar
from services.session_manager import SessionManager
 
# Page config
st.set_page_config(
    page_title="Chat Support",
    page_icon="💬",
    layout="wide"
)
 
# Initialize session
SessionManager.initialize()
 
# Render sidebar
render_sidebar()
 
# Render chat interface
render_chat_interface()
 
 