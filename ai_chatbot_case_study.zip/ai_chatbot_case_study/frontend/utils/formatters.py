"""
Formatters
Utility functions for formatting data
"""
 
from datetime import datetime
from typing import Any, Dict
 
 
def format_datetime(dt_string: str) -> str:
    """Format datetime string to readable format."""
    try:
        dt = datetime.fromisoformat(dt_string.replace('Z', '+00:00'))
        return dt.strftime("%b %d, %Y %I:%M %p")
    except:
        return dt_string
 
 
def format_currency(amount: float) -> str:
    """Format amount as currency."""
    return f"${amount:.2f}"
 
 
def format_order_status(status: str) -> str:
    """Format order status with emoji."""
    status_map = {
        "pending": "⏳ Pending",
        "confirmed": "✅ Confirmed",
        "preparing": "👨‍🍳 Preparing",
        "out_for_delivery": "🚚 Out for Delivery",
        "delivered": "📦 Delivered",
        "cancelled": "❌ Cancelled"
    }
    return status_map.get(status, status.title())
 
 
def format_ticket_status(status: str) -> str:
    """Format ticket status with emoji."""
    status_map = {
        "open": "🔓 Open",
        "in_progress": "⚙️ In Progress",
        "resolved": "✅ Resolved",
        "closed": "🔒 Closed"
    }
    return status_map.get(status, status.title())
 
 
def format_priority(priority: str) -> str:
    """Format priority with emoji."""
    priority_map = {
        "low": "🟢 Low",
        "medium": "🟡 Medium",
        "high": "🔴 High"
    }
    return priority_map.get(priority, priority.title())
 
 
def format_confidence(confidence: float) -> str:
    """Format confidence score."""
    if confidence >= 0.9:
        return f"🟢 High ({confidence:.0%})"
    elif confidence >= 0.7:
        return f"🟡 Medium ({confidence:.0%})"
    else:
        return f"🔴 Low ({confidence:.0%})"
 
 
def format_intent(intent: str) -> str:
    """Format intent name."""
    intent_map = {
        "order_status": "📦 Order Status",
        "payment_issue": "💳 Payment Issue",
        "refund_request": "💰 Refund Request",
        "delivery_problem": "🚚 Delivery Problem",
        "cancellation": "❌ Cancellation",
        "quality_complaint": "⚠️ Quality Complaint",
        "general_faq": "❓ General Question",
        "out_of_scope": "🚫 Out of Scope",
        "escalation": "🆘 Escalation"
    }
    return intent_map.get(intent, intent.replace('_', ' ').title())
 
 
def truncate_text(text: str, max_length: int = 100) -> str:
    """Truncate text to max length."""
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + "..."
 
 
def format_message_metadata(metadata: Dict[str, Any]) -> str:
    """Format message metadata for display."""
    parts = []
   
    if 'confidence' in metadata:
        parts.append(f"Confidence: {metadata['confidence']:.0%}")
   
    if 'intent' in metadata:
        parts.append(f"Intent: {format_intent(metadata['intent'])}")
   
    if 'requires_escalation' in metadata and metadata['requires_escalation']:
        parts.append("⚠️ Escalation Suggested")
   
    return " | ".join(parts) if parts else ""
 
 