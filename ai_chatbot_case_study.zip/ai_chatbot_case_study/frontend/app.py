"""
Main Streamlit Application - Home Page
AI-Powered Help Chatbot
"""
 
import streamlit as st
from services.session_manager import SessionManager
 
# Page config
st.set_page_config(
    page_title="AI Support - Home",
    page_icon="🏠",
    layout="wide",
    initial_sidebar_state="expanded"
)
 
# Custom CSS
st.markdown("""
<style>
    .stChatMessage {
        padding: 1rem;
        border-radius: 0.5rem;
        margin-bottom: 1rem;
    }
   
    .stButton>button {
        border-radius: 0.5rem;
    }
   
    .stTextInput>div>div>input {
        border-radius: 0.5rem;
    }
   
    .stSelectbox>div>div>select {
        border-radius: 0.5rem;
    }
   
    .stTextArea>div>div>textarea {
        border-radius: 0.5rem;
    }
   
    /* Hide Streamlit branding */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
   
    /* Custom header */
    .main-header {
        padding: 1rem 0;
        border-bottom: 2px solid #f0f2f6;
        margin-bottom: 2rem;
    }
   
    /* Welcome card */
    .welcome-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 3rem;
        border-radius: 1rem;
        color: white;
        margin-bottom: 2rem;
        text-align: center;
    }
   
    .feature-card {
        background: white;
        padding: 2rem;
        border-radius: 0.5rem;
        border: 1px solid #e0e0e0;
        margin-bottom: 1rem;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
</style>
""", unsafe_allow_html=True)
 
# Initialize session
SessionManager.initialize()
 
# Main content
def main():
    """Home page."""
   
    # Welcome section
    st.markdown("""
    <div class="welcome-card">
        <h1>🤖 AI-Powered Support Chatbot</h1>
        <p style="font-size: 1.2rem; margin-top: 1rem;">
            Get instant help with your orders, track deliveries, and resolve issues 24/7
        </p>
    </div>
    """, unsafe_allow_html=True)
   
    # Features section
    st.markdown("## 🌟 Features")
   
    col1, col2, col3 = st.columns(3)
   
    with col1:
        st.markdown("""
        <div class="feature-card">
            <h3>💬 Chat Support</h3>
            <p>Get instant answers to your questions with our AI-powered chatbot</p>
            <ul style="text-align: left;">
                <li>Order status tracking</li>
                <li>Delivery updates</li>
                <li>Issue resolution</li>
                <li>24/7 availability</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
   
    with col2:
        st.markdown("""
        <div class="feature-card">
            <h3>📦 Order Tracking</h3>
            <p>Track all your orders in real-time</p>
            <ul style="text-align: left;">
                <li>Live order status</li>
                <li>Delivery estimates</li>
                <li>Order history</li>
                <li>Multiple orders</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
   
    with col3:
        st.markdown("""
        <div class="feature-card">
            <h3>🎫 Ticket System</h3>
            <p>Create and track support tickets</p>
            <ul style="text-align: left;">
                <li>Auto ticket creation</li>
                <li>Priority handling</li>
                <li>Ticket history</li>
                <li>Fast resolution</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
   
    # Quick start section
    st.markdown("## 🚀 Quick Start")
   
    st.info("""
    **Get started in 3 easy steps:**
   
    1. **💬 Chat Support** - Click on "Chat Support" in the sidebar to start chatting
    2. **📦 Order Tracking** - View and track all your orders
    3. **🎫 Ticket History** - Check your support tickets and their status
    """)
   
    # Stats section
    st.markdown("## 📊 System Status")
   
    col1, col2, col3, col4 = st.columns(4)
   
    with col1:
        st.metric("API Status", "🟢 Online", "Connected")
   
    with col2:
        st.metric("Response Time", "< 2s", "Fast")
   
    with col3:
        st.metric("Uptime", "99.9%", "Reliable")
   
    with col4:
        st.metric("User", SessionManager.get_user_id(), "Active")
   
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style="text-align: center; color: #666; padding: 2rem 0;">
        <p>AI-Powered Help Chatbot | GenAI POC Case Study</p>
        <p style="font-size: 0.9rem;">Built with FastAPI, Streamlit, PostgreSQL, and OpenRouter</p>
    </div>
    """, unsafe_allow_html=True)
 
 
if __name__ == "__main__":
    main()
 
 