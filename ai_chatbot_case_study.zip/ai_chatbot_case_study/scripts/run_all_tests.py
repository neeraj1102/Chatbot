"""
Test Runner
Runs all tests and generates report
"""
 
import subprocess
import sys
from pathlib import Path
from datetime import datetime
 
 
class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    END = '\033[0m'
 
 
def print_header(title):
    """Print section header."""
    print(f"\n{Colors.BLUE}{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}{Colors.END}\n")
 
 
def run_command(command, description):
    """Run a command and return success status."""
    print(f"{Colors.YELLOW}Running: {description}{Colors.END}")
    print(f"Command: {command}\n")
   
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=300  # 5 minute timeout
        )
       
        # Print output
        if result.stdout:
            print(result.stdout)
       
        if result.stderr and result.returncode != 0:
            print(f"{Colors.RED}{result.stderr}{Colors.END}")
       
        success = result.returncode == 0
       
        if success:
            print(f"{Colors.GREEN}✓ {description} - PASSED{Colors.END}\n")
        else:
            print(f"{Colors.RED}✗ {description} - FAILED{Colors.END}\n")
       
        return success
   
    except subprocess.TimeoutExpired:
        print(f"{Colors.RED}✗ {description} - TIMEOUT{Colors.END}\n")
        return False
    except Exception as e:
        print(f"{Colors.RED}✗ {description} - ERROR: {e}{Colors.END}\n")
        return False
 
 
def main():
    """Run all tests."""
    print_header("AI Chatbot Test Suite")
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
   
    # Change to project root
    project_root = Path(__file__).parent.parent
   
    results = []
   
    # 1. System Validation
    print_header("1. System Validation")
    success = run_command(
        f"python {project_root}/scripts/validate_system.py",
        "System Validation"
    )
    results.append(("System Validation", success))
   
    if not success:
        print(f"{Colors.YELLOW}⚠️  System validation failed. Fix issues before running other tests.{Colors.END}\n")
        # Continue anyway to see all failures
   
    # 2. Unit Tests (if pytest is available)
    print_header("2. Unit Tests")
    try:
        success = run_command(
            f"cd {project_root}/backend && pytest tests/test_integration.py -v",
            "Integration Tests"
        )
        results.append(("Integration Tests", success))
    except:
        print(f"{Colors.YELLOW}⚠️  Pytest not available or tests not found{Colors.END}\n")
        results.append(("Integration Tests", None))
   
    # 3. Performance Tests
    print_header("3. Performance Tests")
    try:
        success = run_command(
            f"cd {project_root}/backend && pytest tests/test_performance.py -v -s",
            "Performance Tests"
        )
        results.append(("Performance Tests", success))
    except:
        print(f"{Colors.YELLOW}⚠️  Performance tests not available{Colors.END}\n")
        results.append(("Performance Tests", None))
   
    # 4. End-to-End Scenarios
    print_header("4. End-to-End Scenarios")
    success = run_command(
        f"python {project_root}/scripts/test_e2e_scenarios.py",
        "E2E Test Scenarios"
    )
    results.append(("E2E Scenarios", success))
   
    # 5. API Health Check
    print_header("5. API Health Check")
    success = run_command(
        "curl -s http://localhost:8000/health",
        "API Health Check"
    )
    results.append(("API Health", success))
   
    # Generate Report
    print_header("Test Report")
   
    passed = sum(1 for _, status in results if status is True)
    failed = sum(1 for _, status in results if status is False)
    skipped = sum(1 for _, status in results if status is None)
    total = len(results)
   
    print(f"{'Test Suite':<30} {'Status':<15}")
    print("-" * 45)
   
    for name, status in results:
        if status is True:
            status_str = f"{Colors.GREEN}PASSED{Colors.END}"
        elif status is False:
            status_str = f"{Colors.RED}FAILED{Colors.END}"
        else:
            status_str = f"{Colors.YELLOW}SKIPPED{Colors.END}"
       
        print(f"{name:<30} {status_str}")
   
    print("-" * 45)
    print(f"\nTotal: {total}")
    print(f"{Colors.GREEN}Passed: {passed}{Colors.END}")
    print(f"{Colors.RED}Failed: {failed}{Colors.END}")
    print(f"{Colors.YELLOW}Skipped: {skipped}{Colors.END}")
   
    # Final verdict
    print()
    if failed == 0:
        print(f"{Colors.GREEN}{'='*70}")
        print(f"  ✓ ALL TESTS PASSED!")
        print(f"{'='*70}{Colors.END}\n")
        return 0
    else:
        print(f"{Colors.RED}{'='*70}")
        print(f"  ✗ {failed} TEST SUITE(S) FAILED")
        print(f"{'='*70}{Colors.END}\n")
        return 1
 
 
if __name__ == "__main__":
    try:
        exit_code = main()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}Tests interrupted by user{Colors.END}")
        sys.exit(1)
    except Exception as e:
        print(f"\n{Colors.RED}Fatal error: {e}{Colors.END}")
        sys.exit(1)
 
 