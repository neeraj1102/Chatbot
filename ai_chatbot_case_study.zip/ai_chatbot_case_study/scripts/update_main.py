import sys
from pathlib import Path
 
# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / "backend"))
 
# Read main.py
main_file = Path(__file__).parent.parent / "backend" / "app" / "main.py"
with open(main_file, 'r') as f:
    content = f.read()
 
# Update imports
content = content.replace(
    'from app.api.routes import chat, orders, tickets',
    'from app.api.routes import chat, orders, tickets, rag'
)
 
# Update routers
content = content.replace(
    'app.include_router(tickets.router, prefix=settings.API_PREFIX)',
    'app.include_router(tickets.router, prefix=settings.API_PREFIX)\napp.include_router(rag.router, prefix=settings.API_PREFIX)'
)
 
# Update endpoints in api_info
content = content.replace(
    '"tickets": f"{settings.API_PREFIX}/tickets"',
    '"tickets": f"{settings.API_PREFIX}/tickets",\n            "rag": f"{settings.API_PREFIX}/rag"'
)
 
# Write back
with open(main_file, 'w') as f:
    f.write(content)
 
print("✓ Updated main.py with RAG routes")
 
 