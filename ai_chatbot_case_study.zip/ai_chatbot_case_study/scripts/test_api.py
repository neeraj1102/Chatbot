"""
API Testing Script
Quick tests to verify the API is working correctly
"""
 
import requests
import json
from datetime import datetime
 
# API Base URL
BASE_URL = "http://localhost:8000"
API_PREFIX = "/api/v1"
 
 
def print_section(title):
    """Print section header."""
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)
 
 
def print_response(response):
    """Print formatted response."""
    print(f"Status Code: {response.status_code}")
    try:
        print(f"Response: {json.dumps(response.json(), indent=2)}")
    except:
        print(f"Response: {response.text}")
 
 
def test_health():
    """Test health endpoint."""
    print_section("1. Health Check")
   
    response = requests.get(f"{BASE_URL}/health")
    print_response(response)
   
    return response.status_code == 200
 
 
def test_api_info():
    """Test API info endpoint."""
    print_section("2. API Info")
   
    response = requests.get(f"{BASE_URL}{API_PREFIX}/info")
    print_response(response)
   
    return response.status_code == 200
 
 
def test_chat_message():
    """Test sending a chat message."""
    print_section("3. Send Chat Message")
   
    payload = {
        "session_id": "123e4567-e89b-12d3-a456-426614174000",
        "user_id": "USER001",
        "message": "Where is my order?"
    }
   
    response = requests.post(
        f"{BASE_URL}{API_PREFIX}/chat/message",
        json=payload
    )
    print_response(response)
   
    return response.status_code == 200
 
 
def test_conversation_history():
    """Test getting conversation history."""
    print_section("4. Get Conversation History")
   
    session_id = "123e4567-e89b-12d3-a456-426614174000"
    response = requests.get(
        f"{BASE_URL}{API_PREFIX}/chat/history/{session_id}"
    )
    print_response(response)
   
    return response.status_code == 200
 
 
def test_get_order():
    """Test getting order details."""
    print_section("5. Get Order Details")
   
    order_id = "ORD000001"
    response = requests.get(
        f"{BASE_URL}{API_PREFIX}/orders/{order_id}"
    )
    print_response(response)
   
    return response.status_code == 200
 
 
def test_get_user_orders():
    """Test getting user orders."""
    print_section("6. Get User Orders")
   
    user_id = "USER001"
    response = requests.get(
        f"{BASE_URL}{API_PREFIX}/orders/user/{user_id}"
    )
    print_response(response)
   
    return response.status_code == 200
 
 
def test_create_ticket():
    """Test creating a support ticket."""
    print_section("7. Create Support Ticket")
   
    payload = {
        "user_id": "USER001",
        "order_id": "ORD000001",
        "category": "delivery_issue",
        "priority": "high",
        "description": "My order is delayed by 2 hours and the delivery partner is not responding.",
        "conversation_history": [
            {
                "role": "user",
                "message": "Where is my order?",
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "role": "assistant",
                "message": "Your order is out for delivery...",
                "timestamp": datetime.utcnow().isoformat()
            }
        ]
    }
   
    response = requests.post(
        f"{BASE_URL}{API_PREFIX}/tickets/create",
        json=payload
    )
    print_response(response)
   
    return response.status_code == 201
 
 
def test_get_user_tickets():
    """Test getting user tickets."""
    print_section("8. Get User Tickets")
   
    user_id = "USER001"
    response = requests.get(
        f"{BASE_URL}{API_PREFIX}/tickets/user/{user_id}"
    )
    print_response(response)
   
    return response.status_code == 200
 
 
def main():
    """Run all tests."""
    print("\n" + "=" * 60)
    print("  AI Chatbot API Testing")
    print("  " + datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    print("=" * 60)
   
    print(f"\nTesting API at: {BASE_URL}")
    print("Make sure the server is running: uvicorn app.main:app --reload")
   
    input("\nPress Enter to start tests...")
   
    # Run tests
    tests = [
        ("Health Check", test_health),
        ("API Info", test_api_info),
        ("Send Chat Message", test_chat_message),
        ("Get Conversation History", test_conversation_history),
        ("Get Order Details", test_get_order),
        ("Get User Orders", test_get_user_orders),
        ("Create Support Ticket", test_create_ticket),
        ("Get User Tickets", test_get_user_tickets),
    ]
   
    results = []
    for name, test_func in tests:
        try:
            success = test_func()
            results.append((name, success))
        except Exception as e:
            print(f"\n✗ Error: {e}")
            results.append((name, False))
   
    # Print summary
    print_section("Test Summary")
   
    passed = sum(1 for _, success in results if success)
    total = len(results)
   
    for name, success in results:
        status = "✓ PASS" if success else "✗ FAIL"
        print(f"{status} - {name}")
   
    print(f"\nTotal: {passed}/{total} tests passed")
   
    if passed == total:
        print("\n🎉 All tests passed!")
    else:
        print(f"\n⚠️  {total - passed} test(s) failed")
   
    print("=" * 60)
 
 
if __name__ == "__main__":
    main()
 
 