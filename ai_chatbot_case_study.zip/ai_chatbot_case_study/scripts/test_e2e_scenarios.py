"""
End-to-End Test Scenarios
User acceptance test scenarios
"""
 
import requests
import uuid
from datetime import datetime
import time
 
 
BASE_URL = "http://localhost:8000"
API_PREFIX = "/api/v1"
 
 
class Colors:
    """Terminal colors."""
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    END = '\033[0m'
 
 
def print_success(message):
    """Print success message."""
    print(f"{Colors.GREEN}✓ {message}{Colors.END}")
 
 
def print_error(message):
    """Print error message."""
    print(f"{Colors.RED}✗ {message}{Colors.END}")
 
 
def print_info(message):
    """Print info message."""
    print(f"{Colors.BLUE}ℹ {message}{Colors.END}")
 
 
def print_section(title):
    """Print section header."""
    print(f"\n{Colors.YELLOW}{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}{Colors.END}\n")
 
 
def scenario_1_order_status_inquiry():
    """Scenario 1: User asks about order status."""
    print_section("Scenario 1: Order Status Inquiry")
   
    session_id = str(uuid.uuid4())
    user_id = "scenario_user_1"
   
    # Step 1: User asks about order
    print_info("Step 1: User asks 'Where is my order?'")
   
    payload = {
        "session_id": session_id,
        "user_id": user_id,
        "message": "Where is my order?"
    }
   
    response = requests.post(f"{BASE_URL}{API_PREFIX}/chat/message", json=payload)
   
    if response.status_code == 200:
        data = response.json()
        print_success(f"AI Response: {data['message'][:100]}...")
        print_info(f"Intent: {data['intent']}")
        print_info(f"Confidence: {data['confidence']:.2%}")
       
        if data.get('order_context'):
            print_success("Order context provided")
            print_info(f"Order ID: {data['order_context']['order_id']}")
            print_info(f"Status: {data['order_context']['status']}")
       
        return True
    else:
        print_error(f"Failed: {response.status_code}")
        return False
 
 
def scenario_2_refund_request():
    """Scenario 2: User requests refund information."""
    print_section("Scenario 2: Refund Request")
   
    session_id = str(uuid.uuid4())
    user_id = "scenario_user_2"
   
    # Step 1: User asks about refund
    print_info("Step 1: User asks 'How do I get a refund?'")
   
    payload = {
        "session_id": session_id,
        "user_id": user_id,
        "message": "How do I get a refund?"
    }
   
    response = requests.post(f"{BASE_URL}{API_PREFIX}/chat/message", json=payload)
   
    if response.status_code == 200:
        data = response.json()
        print_success(f"AI Response: {data['message'][:100]}...")
        print_info(f"Intent: {data['intent']}")
        print_info(f"Confidence: {data['confidence']:.2%}")
       
        # Should use RAG to retrieve refund policy
        if data.get('metadata', {}).get('rag_enabled'):
            print_success("RAG was used for response")
       
        # May suggest escalation
        if data.get('requires_escalation'):
            print_info("Escalation suggested")
       
        return True
    else:
        print_error(f"Failed: {response.status_code}")
        return False
 
 
def scenario_3_out_of_scope():
    """Scenario 3: User asks out-of-scope question."""
    print_section("Scenario 3: Out-of-Scope Query")
   
    session_id = str(uuid.uuid4())
    user_id = "scenario_user_3"
   
    # Step 1: User asks unrelated question
    print_info("Step 1: User asks 'What's the weather today?'")
   
    payload = {
        "session_id": session_id,
        "user_id": user_id,
        "message": "What's the weather today?"
    }
   
    response = requests.post(f"{BASE_URL}{API_PREFIX}/chat/message", json=payload)
   
    if response.status_code == 200:
        data = response.json()
        print_success(f"AI Response: {data['message'][:100]}...")
        print_info(f"Intent: {data['intent']}")
       
        # Should detect as out of scope
        if data['intent'] == 'out_of_scope':
            print_success("Correctly identified as out-of-scope")
            return True
        else:
            print_error(f"Incorrectly classified as: {data['intent']}")
            return False
    else:
        print_error(f"Failed: {response.status_code}")
        return False
 
 
def scenario_4_ticket_creation():
    """Scenario 4: User creates support ticket."""
    print_section("Scenario 4: Ticket Creation")
   
    user_id = "scenario_user_4"
   
    # Step 1: Create ticket
    print_info("Step 1: User creates ticket for delivery issue")
   
    payload = {
        "user_id": user_id,
        "category": "delivery_issue",
        "priority": "high",
        "description": "My order is delayed by 2 hours and the delivery partner is not responding.",
        "conversation_history": [
            {
                "role": "user",
                "message": "Where is my order?",
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "role": "assistant",
                "message": "Your order is out for delivery.",
                "timestamp": datetime.utcnow().isoformat()
            }
        ]
    }
   
    response = requests.post(f"{BASE_URL}{API_PREFIX}/tickets/create", json=payload)
   
    if response.status_code == 201:
        data = response.json()
        print_success(f"Ticket created: {data['ticket_id']}")
        print_info(f"Status: {data['status']}")
        print_info(f"ETA: {data['estimated_response_time']}")
       
        # Step 2: Verify ticket was created
        print_info("Step 2: Verify ticket exists")
       
        ticket_response = requests.get(
            f"{BASE_URL}{API_PREFIX}/tickets/{data['ticket_id']}"
        )
       
        if ticket_response.status_code == 200:
            print_success("Ticket verified")
            return True
        else:
            print_error("Ticket verification failed")
            return False
    else:
        print_error(f"Failed: {response.status_code}")
        return False
 
 
def scenario_5_multi_turn_conversation():
    """Scenario 5: Multi-turn conversation."""
    print_section("Scenario 5: Multi-Turn Conversation")
   
    session_id = str(uuid.uuid4())
    user_id = "scenario_user_5"
   
    conversation = [
        "I want to cancel my order",
        "Order number ORD000001",
        "Yes, please cancel it"
    ]
   
    for i, message in enumerate(conversation, 1):
        print_info(f"Turn {i}: User says '{message}'")
       
        payload = {
            "session_id": session_id,
            "user_id": user_id,
            "message": message
        }
       
        response = requests.post(f"{BASE_URL}{API_PREFIX}/chat/message", json=payload)
       
        if response.status_code == 200:
            data = response.json()
            print_success(f"AI: {data['message'][:80]}...")
            time.sleep(0.5)  # Small delay between messages
        else:
            print_error(f"Failed at turn {i}")
            return False
   
    # Verify conversation history
    print_info("Verifying conversation history...")
   
    history_response = requests.get(
        f"{BASE_URL}{API_PREFIX}/chat/history/{session_id}"
    )
   
    if history_response.status_code == 200:
        history = history_response.json()
        message_count = len(history['messages'])
        print_success(f"Conversation history contains {message_count} messages")
        return True
    else:
        print_error("Failed to retrieve history")
        return False
 
 
def scenario_6_order_tracking():
    """Scenario 6: Order tracking."""
    print_section("Scenario 6: Order Tracking")
   
    user_id = "USER001"
   
    # Step 1: Get user orders
    print_info("Step 1: Fetch user orders")
   
    response = requests.get(
        f"{BASE_URL}{API_PREFIX}/orders/user/{user_id}",
        params={"limit": 5}
    )
   
    if response.status_code == 200:
        data = response.json()
        print_success(f"Found {data['total']} order(s)")
       
        if data['orders']:
            order = data['orders'][0]
            print_info(f"Order ID: {order['order_id']}")
            print_info(f"Status: {order['status']}")
            print_info(f"Amount: ${order['total_amount']:.2f}")
           
            # Step 2: Get specific order
            print_info("Step 2: Get specific order details")
           
            order_response = requests.get(
                f"{BASE_URL}{API_PREFIX}/orders/{order['order_id']}"
            )
           
            if order_response.status_code == 200:
                print_success("Order details retrieved")
                return True
        else:
            print_info("No orders found (using mock data)")
            return True
    else:
        print_error(f"Failed: {response.status_code}")
        return False
 
 
def scenario_7_rag_knowledge_retrieval():
    """Scenario 7: RAG knowledge retrieval."""
    print_section("Scenario 7: RAG Knowledge Retrieval")
   
    # Step 1: Check RAG stats
    print_info("Step 1: Check RAG statistics")
   
    stats_response = requests.get(f"{BASE_URL}{API_PREFIX}/rag/stats")
   
    if stats_response.status_code == 200:
        stats = stats_response.json()
        if stats.get('success'):
            rag_stats = stats['stats']
            print_success(f"Knowledge base loaded: {rag_stats['total_documents']} documents")
            print_info(f"Embedding model: {rag_stats['embedding_model']}")
        else:
            print_info("RAG not loaded, loading now...")
            load_response = requests.post(f"{BASE_URL}{API_PREFIX}/rag/load-knowledge-base")
            if load_response.status_code == 200:
                print_success("Knowledge base loaded")
            else:
                print_error("Failed to load knowledge base")
                return False
   
    # Step 2: Search knowledge base
    print_info("Step 2: Search knowledge base")
   
    search_payload = {
        "query": "What is your refund policy?",
        "top_k": 3
    }
   
    search_response = requests.post(
        f"{BASE_URL}{API_PREFIX}/rag/search",
        json=search_payload
    )
   
    if search_response.status_code == 200:
        results = search_response.json()
        print_success(f"Found {results['total_results']} relevant documents")
       
        for i, doc in enumerate(results['results'][:2], 1):
            print_info(f"Document {i}: {doc['content'][:60]}...")
       
        return True
    else:
        print_error(f"Search failed: {search_response.status_code}")
        return False
 
 
def run_all_scenarios():
    """Run all test scenarios."""
    print_section("End-to-End Test Scenarios")
    print_info(f"Testing against: {BASE_URL}")
    print_info(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
   
    scenarios = [
        ("Order Status Inquiry", scenario_1_order_status_inquiry),
        ("Refund Request", scenario_2_refund_request),
        ("Out-of-Scope Query", scenario_3_out_of_scope),
        ("Ticket Creation", scenario_4_ticket_creation),
        ("Multi-Turn Conversation", scenario_5_multi_turn_conversation),
        ("Order Tracking", scenario_6_order_tracking),
        ("RAG Knowledge Retrieval", scenario_7_rag_knowledge_retrieval),
    ]
   
    results = []
   
    for name, scenario_func in scenarios:
        try:
            success = scenario_func()
            results.append((name, success))
        except Exception as e:
            print_error(f"Exception in {name}: {e}")
            results.append((name, False))
   
    # Print summary
    print_section("Test Summary")
   
    passed = sum(1 for _, success in results if success)
    total = len(results)
   
    for name, success in results:
        status = f"{Colors.GREEN}PASS{Colors.END}" if success else f"{Colors.RED}FAIL{Colors.END}"
        print(f"{status} - {name}")
   
    print(f"\n{Colors.BLUE}Total: {passed}/{total} scenarios passed{Colors.END}")
   
    if passed == total:
        print(f"\n{Colors.GREEN}🎉 All scenarios passed!{Colors.END}")
    else:
        print(f"\n{Colors.YELLOW}⚠️  {total - passed} scenario(s) failed{Colors.END}")
   
    return passed == total
 
 
if __name__ == "__main__":
    try:
        success = run_all_scenarios()
        exit(0 if success else 1)
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}Tests interrupted by user{Colors.END}")
        exit(1)
    except Exception as e:
        print(f"\n{Colors.RED}Fatal error: {e}{Colors.END}")
        exit(1)
 
 