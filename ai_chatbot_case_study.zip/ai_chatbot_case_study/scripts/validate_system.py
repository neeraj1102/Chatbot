"""
System Validation Script
Validates complete system setup and configuration
"""
 
import requests
import sys
from pathlib import Path
 
 
class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    END = '\033[0m'
 
 
def print_header(title):
    """Print section header."""
    print(f"\n{Colors.BLUE}{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}{Colors.END}\n")
 
 
def print_check(message, status):
    """Print check result."""
    symbol = f"{Colors.GREEN}✓{Colors.END}" if status else f"{Colors.RED}✗{Colors.END}"
    print(f"{symbol} {message}")
    return status
 
 
def check_backend_running():
    """Check if backend is running."""
    try:
        response = requests.get("http://localhost:8000/health", timeout=5)
        return response.status_code == 200
    except:
        return False
 
 
def check_database_connection():
    """Check database connection."""
    try:
        response = requests.get("http://localhost:8000/health", timeout=5)
        if response.status_code == 200:
            data = response.json()
            return data.get('services', {}).get('database') == 'up'
        return False
    except:
        return False
 
 
def check_rag_loaded():
    """Check if RAG is loaded."""
    try:
        response = requests.get("http://localhost:8000/api/v1/rag/stats", timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data.get('success'):
                return data['stats']['total_documents'] > 0
        return False
    except:
        return False
 
 
def check_knowledge_base_files():
    """Check if knowledge base files exist."""
    kb_path = Path(__file__).parent.parent / "backend" / "knowledge_base"
   
    required_files = ["faqs.json", "policies.json", "troubleshooting.json"]
   
    for file in required_files:
        if not (kb_path / file).exists():
            return False
   
    return True
 
 
def check_api_endpoints():
    """Check if all API endpoints are accessible."""
    endpoints = [
        "/health",
        "/api/v1/info",
    ]
   
    for endpoint in endpoints:
        try:
            response = requests.get(f"http://localhost:8000{endpoint}", timeout=5)
            if response.status_code != 200:
                return False
        except:
            return False
   
    return True
 
 
def check_chat_functionality():
    """Check if chat functionality works."""
    try:
        import uuid
        payload = {
            "session_id": str(uuid.uuid4()),
            "user_id": "validation_test",
            "message": "Test message"
        }
       
        response = requests.post(
            "http://localhost:8000/api/v1/chat/message",
            json=payload,
            timeout=15
        )
       
        if response.status_code == 200:
            data = response.json()
            return all(key in data for key in ['message', 'confidence', 'intent'])
       
        return False
    except:
        return False
 
 
def check_frontend_files():
    """Check if frontend files exist."""
    frontend_path = Path(__file__).parent.parent / "frontend"
   
    required_files = [
        "app.py",
        "requirements.txt",
        "services/api_client.py",
        "components/chat_interface.py"
    ]
   
    for file in required_files:
        if not (frontend_path / file).exists():
            return False
   
    return True
 
 
def check_environment_config():
    """Check if environment is configured."""
    env_file = Path(__file__).parent.parent / "backend" / ".env"
   
    if not env_file.exists():
        return False
   
    # Check if OPENAI_API_KEY is set
    with open(env_file, 'r') as f:
        content = f.read()
        if 'OPENAI_API_KEY=' in content and 'sk-' in content:
            return True
   
    return False
 
 
def validate_system():
    """Run complete system validation."""
    print_header("System Validation")
    print(f"{Colors.YELLOW}Validating AI Chatbot System...{Colors.END}\n")
   
    checks = []
   
    # File System Checks
    print_header("File System Checks")
    checks.append(print_check("Knowledge base files exist", check_knowledge_base_files()))
    checks.append(print_check("Frontend files exist", check_frontend_files()))
    checks.append(print_check("Environment configured", check_environment_config()))
   
    # Backend Checks
    print_header("Backend Checks")
    backend_running = check_backend_running()
    checks.append(print_check("Backend server running", backend_running))
   
    if backend_running:
        checks.append(print_check("Database connection", check_database_connection()))
        checks.append(print_check("API endpoints accessible", check_api_endpoints()))
        checks.append(print_check("Chat functionality working", check_chat_functionality()))
        checks.append(print_check("RAG knowledge base loaded", check_rag_loaded()))
    else:
        print(f"{Colors.YELLOW}⚠️  Backend not running - skipping dependent checks{Colors.END}")
        print(f"{Colors.YELLOW}   Start backend with: uvicorn app.main:app --reload{Colors.END}")
   
    # Summary
    print_header("Validation Summary")
   
    passed = sum(checks)
    total = len(checks)
    percentage = (passed / total * 100) if total > 0 else 0
   
    print(f"Passed: {passed}/{total} ({percentage:.0f}%)\n")
   
    if passed == total:
        print(f"{Colors.GREEN}✓ System validation passed!{Colors.END}")
        print(f"{Colors.GREEN}  All components are working correctly.{Colors.END}\n")
        return True
    else:
        print(f"{Colors.RED}✗ System validation failed!{Colors.END}")
        print(f"{Colors.RED}  {total - passed} check(s) failed.{Colors.END}\n")
       
        # Provide guidance
        print(f"{Colors.YELLOW}Troubleshooting:{Colors.END}")
       
        if not backend_running:
            print("  1. Start backend: cd backend && uvicorn app.main:app --reload")
            print("  2. Ensure PostgreSQL and Redis are running: docker-compose up -d")
       
        if not check_environment_config():
            print("  3. Configure .env file with your OPENAI_API_KEY")
       
        if backend_running and not check_rag_loaded():
            print("  4. Load knowledge base: python scripts/generate_embeddings.py")
       
        print()
        return False
 
 
if __name__ == "__main__":
    try:
        success = validate_system()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}Validation interrupted{Colors.END}")
        sys.exit(1)
    except Exception as e:
        print(f"\n{Colors.RED}Error: {e}{Colors.END}")
        sys.exit(1)
 
 