"""
Knowledge Base Setup Script
Prepares and validates the knowledge base files.
"""
 
import json
import os
from pathlib import Path
 
 
def validate_json_file(file_path: Path) -> bool:
    """Validate JSON file structure."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        print(f"✓ {file_path.name} is valid JSON")
        return True
    except json.JSONDecodeError as e:
        print(f"✗ {file_path.name} has invalid JSON: {e}")
        return False
    except Exception as e:
        print(f"✗ Error reading {file_path.name}: {e}")
        return False
 
 
def count_documents(file_path: Path) -> int:
    """Count documents in knowledge base file."""
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
   
    # Get the first key (faqs, policies, troubleshooting)
    key = list(data.keys())[0]
    return len(data[key])
 
 
def main():
    """Main setup function."""
    print("=" * 60)
    print("Knowledge Base Setup")
    print("=" * 60)
   
    # Get knowledge base directory
    kb_dir = Path(__file__).parent.parent / "backend" / "knowledge_base"
   
    if not kb_dir.exists():
        print(f"✗ Knowledge base directory not found: {kb_dir}")
        return
   
    print(f"\nKnowledge base directory: {kb_dir}")
   
    # Files to validate
    files = ["faqs.json", "policies.json", "troubleshooting.json"]
   
    print("\nValidating knowledge base files...")
    print("-" * 60)
   
    total_docs = 0
    all_valid = True
   
    for filename in files:
        file_path = kb_dir / filename
       
        if not file_path.exists():
            print(f"✗ {filename} not found")
            all_valid = False
            continue
       
        if validate_json_file(file_path):
            doc_count = count_documents(file_path)
            total_docs += doc_count
            print(f"  Documents: {doc_count}")
        else:
            all_valid = False
   
    print("-" * 60)
   
    if all_valid:
        print(f"\n✓ All knowledge base files are valid!")
        print(f"✓ Total documents: {total_docs}")
        print("\nNext steps:")
        print("1. Run: python scripts/generate_embeddings.py")
        print("2. Start the backend server")
    else:
        print("\n✗ Some files have errors. Please fix them before proceeding.")
   
    print("=" * 60)
 
 
if __name__ == "__main__":
    main()
 
 